-- MySQL dump 10.13  Distrib 8.0.43, for Linux (x86_64)
--
-- Host: localhost    Database: vtria_erp
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ai_alerts`
--

DROP TABLE IF EXISTS `ai_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_alerts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `model_id` int NOT NULL,
  `insight_id` int DEFAULT NULL,
  `case_id` int DEFAULT NULL,
  `milestone_id` int DEFAULT NULL,
  `alert_type` enum('deadline_risk','budget_overrun','quality_issue','resource_conflict','client_satisfaction','anomaly_detected') NOT NULL,
  `severity` enum('info','warning','error','critical') NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `trigger_condition` text NOT NULL,
  `threshold_value` decimal(15,4) DEFAULT NULL,
  `actual_value` decimal(15,4) DEFAULT NULL,
  `deviation_percentage` decimal(5,2) DEFAULT NULL,
  `confidence_score` decimal(5,4) NOT NULL,
  `predicted_outcome` text,
  `time_to_critical_hours` int DEFAULT NULL COMMENT 'Hours until situation becomes critical',
  `is_critical` tinyint(1) DEFAULT '0',
  `requires_immediate_action` tinyint(1) DEFAULT '0',
  `suggested_actions` json DEFAULT NULL,
  `escalation_rules` json DEFAULT NULL,
  `status` enum('active','acknowledged','resolved','dismissed','expired') DEFAULT 'active',
  `acknowledged_by` int DEFAULT NULL,
  `acknowledged_at` timestamp NULL DEFAULT NULL,
  `resolved_by` int DEFAULT NULL,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `resolution_notes` text,
  `notifications_sent` json DEFAULT NULL COMMENT 'Record of sent notifications',
  `last_escalated_at` timestamp NULL DEFAULT NULL,
  `escalation_level` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `expires_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `insight_id` (`insight_id`),
  KEY `milestone_id` (`milestone_id`),
  KEY `acknowledged_by` (`acknowledged_by`),
  KEY `resolved_by` (`resolved_by`),
  KEY `idx_model_id` (`model_id`),
  KEY `idx_case_id` (`case_id`),
  KEY `idx_alert_type` (`alert_type`),
  KEY `idx_severity` (`severity`),
  KEY `idx_status` (`status`),
  KEY `idx_is_critical` (`is_critical`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_expires_at` (`expires_at`),
  CONSTRAINT `ai_alerts_ibfk_1` FOREIGN KEY (`model_id`) REFERENCES `ai_models` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_alerts_ibfk_2` FOREIGN KEY (`insight_id`) REFERENCES `ai_insights` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ai_alerts_ibfk_3` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_alerts_ibfk_4` FOREIGN KEY (`milestone_id`) REFERENCES `case_milestones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_alerts_ibfk_5` FOREIGN KEY (`acknowledged_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ai_alerts_ibfk_6` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Smart alerts with AI-driven proactive notifications';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_alerts`
--

LOCK TABLES `ai_alerts` WRITE;
/*!40000 ALTER TABLE `ai_alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `ai_alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ai_insights`
--

DROP TABLE IF EXISTS `ai_insights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_insights` (
  `id` int NOT NULL AUTO_INCREMENT,
  `model_id` int NOT NULL,
  `case_id` int DEFAULT NULL,
  `milestone_id` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `insight_type` enum('prediction','recommendation','anomaly','optimization','warning','opportunity') NOT NULL,
  `insight_category` enum('schedule','budget','quality','resource','risk','client_satisfaction') NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `confidence_score` decimal(5,4) NOT NULL,
  `severity_level` enum('low','medium','high','critical') DEFAULT 'medium',
  `predicted_impact` enum('positive','negative','neutral') NOT NULL,
  `predicted_value` decimal(15,2) DEFAULT NULL COMMENT 'Quantified impact (cost, time, etc.)',
  `input_data` json NOT NULL COMMENT 'Data used to generate this insight',
  `model_output` json NOT NULL COMMENT 'Raw model output',
  `supporting_evidence` text,
  `is_actionable` tinyint(1) DEFAULT '1',
  `recommended_actions` json DEFAULT NULL COMMENT 'Suggested actions to take',
  `urgency_level` enum('immediate','within_week','within_month','long_term') DEFAULT 'within_week',
  `is_acknowledged` tinyint(1) DEFAULT '0',
  `acknowledged_by` int DEFAULT NULL,
  `acknowledged_at` timestamp NULL DEFAULT NULL,
  `is_acted_upon` tinyint(1) DEFAULT '0',
  `action_taken` text,
  `action_result` enum('successful','partially_successful','unsuccessful','pending') DEFAULT NULL,
  `user_rating` enum('very_helpful','helpful','neutral','not_helpful','incorrect') DEFAULT NULL,
  `user_feedback` text,
  `actual_outcome` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `milestone_id` (`milestone_id`),
  KEY `client_id` (`client_id`),
  KEY `acknowledged_by` (`acknowledged_by`),
  KEY `idx_model_id` (`model_id`),
  KEY `idx_case_id` (`case_id`),
  KEY `idx_insight_type` (`insight_type`),
  KEY `idx_insight_category` (`insight_category`),
  KEY `idx_confidence_score` (`confidence_score`),
  KEY `idx_severity_level` (`severity_level`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_actionable` (`is_actionable`),
  CONSTRAINT `ai_insights_ibfk_1` FOREIGN KEY (`model_id`) REFERENCES `ai_models` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_insights_ibfk_2` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_insights_ibfk_3` FOREIGN KEY (`milestone_id`) REFERENCES `case_milestones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_insights_ibfk_4` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_insights_ibfk_5` FOREIGN KEY (`acknowledged_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='AI-generated insights and predictions with tracking';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_insights`
--

LOCK TABLES `ai_insights` WRITE;
/*!40000 ALTER TABLE `ai_insights` DISABLE KEYS */;
INSERT INTO `ai_insights` (`id`, `model_id`, `case_id`, `milestone_id`, `client_id`, `insight_type`, `insight_category`, `title`, `description`, `confidence_score`, `severity_level`, `predicted_impact`, `predicted_value`, `input_data`, `model_output`, `supporting_evidence`, `is_actionable`, `recommended_actions`, `urgency_level`, `is_acknowledged`, `acknowledged_by`, `acknowledged_at`, `is_acted_upon`, `action_taken`, `action_result`, `user_rating`, `user_feedback`, `actual_outcome`, `created_at`, `updated_at`) VALUES (1,1,1,NULL,1,'prediction','schedule','Project Delay Risk Analysis','Based on current progress (0%) and NaN days remaining, there is a low risk of project delay.',0.0000,'low','neutral',NULL,'{\"progress_gap\": null, \"current_progress\": 0, \"days_to_deadline\": null}','{\"delay_probability\": null, \"critical_path_impact\": false, \"estimated_delay_days\": null}','Potential delay of NaN days with budget impact of $NaN',1,'[]','within_week',0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2025-09-13 02:58:34','2025-09-13 02:58:34'),(2,2,1,NULL,1,'prediction','schedule','Budget Variance Analysis','Current budget usage is below expected levels by 0.0%.',0.8000,'low','neutral',NULL,'{\"budget_used\": 0, \"total_budget\": 100000, \"variance_percentage\": 0}','{\"variance_amount\": 0, \"overrun_probability\": 0, \"projected_final_cost\": 100000}','Projected budget variance of $0',1,'[]','within_week',0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2025-09-13 02:58:34','2025-09-13 02:58:34'),(3,3,1,NULL,1,'optimization','resource','Resource Allocation Optimization','AI analysis suggests potential resource reallocation opportunities to improve efficiency.',0.7500,'medium','neutral',NULL,'{\"optimization_type\": \"resource_reallocation\"}','{\"cost_savings\": 5000, \"efficiency_gain\": 15, \"time_savings_days\": 3}','Potential 15% efficiency improvement with $5,000 cost savings',1,'[\"Reassign junior developer to testing tasks\", \"Implement parallel processing for data migration\", \"Cross-train team members on critical path activities\"]','within_week',0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2025-09-13 02:58:34','2025-09-13 02:58:34'),(4,4,1,NULL,1,'warning','risk','Quality Risk Assessment','Detected patterns suggesting potential quality issues based on historical data.',0.8200,'high','neutral',NULL,'{\"quality_metrics\": {\"test_cases\": 120, \"code_coverage\": 65, \"defects_found\": 8}}','{\"quality_score\": 75, \"testing_adequacy\": \"insufficient\", \"defect_probability\": 0.25}','Risk of quality issues that could delay delivery by 5-7 days',1,'[]','within_week',0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2025-09-13 02:58:34','2025-09-13 02:58:34'),(5,5,1,NULL,1,'prediction','schedule','Client Satisfaction Forecast','Predictive analysis of client satisfaction based on project metrics and communication patterns.',0.7800,'medium','neutral',NULL,'{\"communication_score\": 75, \"delivery_performance\": 82, \"responsiveness_rating\": 80}','{\"nps_prediction\": 7, \"satisfaction_score\": 78, \"retention_probability\": 0.85}','Good satisfaction expected with room for improvement in communication',1,'[]','within_week',0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2025-09-13 02:58:34','2025-09-13 02:58:34'),(6,6,1,NULL,1,'anomaly','risk','Process Anomaly Detected','Unusual patterns detected in project execution that deviate from normal workflow.',0.8800,'high','neutral',NULL,'{\"anomaly_score\": 0.88, \"baseline_deviation\": 35}','{\"anomaly_type\": \"workflow_deviation\", \"impact_level\": \"medium\", \"correction_needed\": true}','Process inefficiency that could impact timeline and quality',1,'[]','within_week',0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2025-09-13 02:58:34','2025-09-13 02:58:34');
/*!40000 ALTER TABLE `ai_insights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `ai_insights_summary`
--

DROP TABLE IF EXISTS `ai_insights_summary`;
/*!50001 DROP VIEW IF EXISTS `ai_insights_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `ai_insights_summary` AS SELECT 
 1 AS `insight_category`,
 1 AS `insight_type`,
 1 AS `severity_level`,
 1 AS `total_insights`,
 1 AS `avg_confidence`,
 1 AS `acknowledged_count`,
 1 AS `acted_upon_count`,
 1 AS `avg_user_rating`,
 1 AS `insight_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ai_model_performance`
--

DROP TABLE IF EXISTS `ai_model_performance`;
/*!50001 DROP VIEW IF EXISTS `ai_model_performance`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `ai_model_performance` AS SELECT 
 1 AS `model_name`,
 1 AS `model_type`,
 1 AS `model_category`,
 1 AS `accuracy_score`,
 1 AS `confidence_threshold`,
 1 AS `last_trained_at`,
 1 AS `insights_generated`,
 1 AS `avg_insight_confidence`,
 1 AS `positive_feedback_count`,
 1 AS `negative_feedback_count`,
 1 AS `predictions_made`,
 1 AS `avg_prediction_accuracy`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `ai_models`
--

DROP TABLE IF EXISTS `ai_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_models` (
  `id` int NOT NULL AUTO_INCREMENT,
  `model_name` varchar(100) NOT NULL,
  `model_type` enum('predictive','classification','clustering','recommendation','anomaly_detection') NOT NULL,
  `model_category` enum('project_delay','cost_estimation','resource_optimization','quality_prediction','client_satisfaction','risk_assessment') NOT NULL,
  `model_version` varchar(20) NOT NULL DEFAULT '1.0',
  `algorithm_type` varchar(50) NOT NULL,
  `training_data_source` text NOT NULL,
  `input_features` json NOT NULL COMMENT 'Features used by the model',
  `output_schema` json NOT NULL COMMENT 'Structure of model outputs',
  `accuracy_score` decimal(5,4) DEFAULT NULL,
  `precision_score` decimal(5,4) DEFAULT NULL,
  `recall_score` decimal(5,4) DEFAULT NULL,
  `f1_score` decimal(5,4) DEFAULT NULL,
  `last_trained_at` timestamp NULL DEFAULT NULL,
  `training_data_size` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `is_production_ready` tinyint(1) DEFAULT '0',
  `confidence_threshold` decimal(5,4) DEFAULT '0.7500',
  `description` text,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `model_name` (`model_name`),
  KEY `created_by` (`created_by`),
  KEY `idx_model_type` (`model_type`),
  KEY `idx_model_category` (`model_category`),
  KEY `idx_active` (`is_active`),
  CONSTRAINT `ai_models_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='AI model definitions and performance tracking';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_models`
--

LOCK TABLES `ai_models` WRITE;
/*!40000 ALTER TABLE `ai_models` DISABLE KEYS */;
INSERT INTO `ai_models` (`id`, `model_name`, `model_type`, `model_category`, `model_version`, `algorithm_type`, `training_data_source`, `input_features`, `output_schema`, `accuracy_score`, `precision_score`, `recall_score`, `f1_score`, `last_trained_at`, `training_data_size`, `is_active`, `is_production_ready`, `confidence_threshold`, `description`, `created_by`, `created_at`, `updated_at`) VALUES (1,'Project Delay Predictor','predictive','project_delay','1.0','Random Forest Regression','Historical case and milestone data','[\"milestone_count\", \"complexity_level\", \"team_size\", \"client_response_time\", \"requirements_changes\", \"critical_path_length\"]','{\"confidence\": \"number\", \"risk_factors\": \"array\", \"predicted_delay_days\": \"number\"}',NULL,NULL,NULL,NULL,NULL,NULL,1,1,0.7500,'Predicts likelihood and magnitude of project delays based on historical patterns',1,'2025-09-13 02:50:57','2025-09-13 02:50:57'),(2,'Cost Overrun Detector','predictive','cost_estimation','1.0','Gradient Boosting Regressor','Historical cost and budget data','[\"initial_estimate\", \"scope_changes\", \"team_experience\", \"project_complexity\", \"client_history\", \"market_conditions\"]','{\"confidence\": \"number\", \"cost_drivers\": \"array\", \"predicted_cost_overrun_percentage\": \"number\"}',NULL,NULL,NULL,NULL,NULL,NULL,1,1,0.7500,'Identifies potential cost overruns and their contributing factors',1,'2025-09-13 02:50:57','2025-09-13 02:50:57'),(3,'Resource Optimization Engine','recommendation','resource_optimization','1.0','Linear Programming with ML','Resource allocation and utilization data','[\"current_allocation\", \"skill_requirements\", \"availability\", \"project_priorities\", \"deadline_constraints\"]','{\"efficiency_gain\": \"number\", \"recommendations\": \"array\", \"optimal_allocation\": \"object\"}',NULL,NULL,NULL,NULL,NULL,NULL,1,1,0.7500,'Optimizes resource allocation across projects for maximum efficiency',1,'2025-09-13 02:50:57','2025-09-13 02:50:57'),(4,'Quality Risk Assessor','classification','quality_prediction','1.0','Support Vector Machine','Quality metrics and defect data','[\"code_complexity\", \"testing_coverage\", \"team_experience\", \"timeline_pressure\", \"requirements_clarity\"]','{\"risk_areas\": \"array\", \"probability\": \"number\", \"quality_risk_level\": \"string\"}',NULL,NULL,NULL,NULL,NULL,NULL,1,1,0.7500,'Assesses quality risks and suggests preventive measures',1,'2025-09-13 02:50:57','2025-09-13 02:50:57'),(5,'Client Satisfaction Predictor','predictive','client_satisfaction','1.0','Neural Network','Client feedback and project metrics','[\"communication_frequency\", \"milestone_adherence\", \"response_time\", \"issue_resolution_speed\", \"delivery_quality\"]','{\"confidence\": \"number\", \"improvement_areas\": \"array\", \"satisfaction_score\": \"number\"}',NULL,NULL,NULL,NULL,NULL,NULL,1,1,0.7500,'Predicts client satisfaction and identifies improvement opportunities',1,'2025-09-13 02:50:57','2025-09-13 02:50:57'),(6,'Anomaly Detection System','anomaly_detection','risk_assessment','1.0','Isolation Forest','All project metrics and activities','[\"activity_patterns\", \"performance_metrics\", \"resource_usage\", \"timeline_deviations\", \"communication_patterns\"]','{\"anomaly_type\": \"string\", \"anomaly_score\": \"number\", \"affected_areas\": \"array\"}',NULL,NULL,NULL,NULL,NULL,NULL,1,1,0.7500,'Detects unusual patterns that may indicate risks or opportunities',1,'2025-09-13 02:50:57','2025-09-13 02:50:57');
/*!40000 ALTER TABLE `ai_models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ai_predictions`
--

DROP TABLE IF EXISTS `ai_predictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_predictions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `model_id` int NOT NULL,
  `case_id` int DEFAULT NULL,
  `milestone_id` int DEFAULT NULL,
  `prediction_type` enum('completion_date','cost_estimate','resource_requirement','quality_score','risk_probability','client_satisfaction') NOT NULL,
  `predicted_value` decimal(15,4) NOT NULL,
  `confidence_interval_lower` decimal(15,4) DEFAULT NULL,
  `confidence_interval_upper` decimal(15,4) DEFAULT NULL,
  `confidence_score` decimal(5,4) NOT NULL,
  `prediction_horizon_days` int NOT NULL,
  `input_features` json NOT NULL,
  `model_version` varchar(20) NOT NULL,
  `actual_value` decimal(15,4) DEFAULT NULL,
  `accuracy_score` decimal(5,4) DEFAULT NULL,
  `absolute_error` decimal(15,4) DEFAULT NULL,
  `percentage_error` decimal(7,4) DEFAULT NULL,
  `is_validated` tinyint(1) DEFAULT '0',
  `prediction_date` timestamp NOT NULL,
  `target_date` timestamp NOT NULL,
  `validation_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `milestone_id` (`milestone_id`),
  KEY `idx_model_id` (`model_id`),
  KEY `idx_case_id` (`case_id`),
  KEY `idx_prediction_type` (`prediction_type`),
  KEY `idx_prediction_date` (`prediction_date`),
  KEY `idx_target_date` (`target_date`),
  KEY `idx_confidence_score` (`confidence_score`),
  CONSTRAINT `ai_predictions_ibfk_1` FOREIGN KEY (`model_id`) REFERENCES `ai_models` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_predictions_ibfk_2` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_predictions_ibfk_3` FOREIGN KEY (`milestone_id`) REFERENCES `case_milestones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Predictive analytics results with accuracy tracking';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_predictions`
--

LOCK TABLES `ai_predictions` WRITE;
/*!40000 ALTER TABLE `ai_predictions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ai_predictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ai_recommendations`
--

DROP TABLE IF EXISTS `ai_recommendations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_recommendations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `insight_id` int DEFAULT NULL,
  `case_id` int DEFAULT NULL,
  `milestone_id` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `recommendation_type` enum('process_improvement','resource_allocation','timeline_adjustment','cost_optimization','quality_enhancement','risk_mitigation') NOT NULL,
  `priority_level` enum('low','medium','high','critical') NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `effort_level` enum('minimal','low','medium','high','extensive') NOT NULL,
  `estimated_time_to_implement` varchar(50) DEFAULT NULL,
  `estimated_cost_impact` decimal(12,2) DEFAULT NULL,
  `estimated_time_savings_hours` int DEFAULT NULL,
  `confidence_score` decimal(5,4) NOT NULL,
  `reasoning` text NOT NULL,
  `success_probability` decimal(5,4) DEFAULT NULL,
  `risk_factors` json DEFAULT NULL COMMENT 'Potential risks of implementation',
  `implementation_steps` json DEFAULT NULL COMMENT 'Step-by-step implementation guide',
  `required_resources` json DEFAULT NULL COMMENT 'Resources needed for implementation',
  `dependencies` json DEFAULT NULL COMMENT 'Prerequisites and dependencies',
  `success_metrics` json DEFAULT NULL COMMENT 'How to measure success',
  `status` enum('generated','reviewed','approved','in_progress','implemented','rejected','expired') DEFAULT 'generated',
  `assigned_to` int DEFAULT NULL,
  `reviewed_by` int DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `implementation_started_at` timestamp NULL DEFAULT NULL,
  `implementation_completed_at` timestamp NULL DEFAULT NULL,
  `implementation_success` enum('successful','partially_successful','unsuccessful') DEFAULT NULL,
  `actual_impact_value` decimal(12,2) DEFAULT NULL,
  `lessons_learned` text,
  `user_satisfaction_rating` enum('excellent','good','fair','poor') DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_relevant` tinyint(1) DEFAULT '1',
  `relevance_score` decimal(5,4) DEFAULT '1.0000',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `milestone_id` (`milestone_id`),
  KEY `client_id` (`client_id`),
  KEY `reviewed_by` (`reviewed_by`),
  KEY `idx_insight_id` (`insight_id`),
  KEY `idx_case_id` (`case_id`),
  KEY `idx_recommendation_type` (`recommendation_type`),
  KEY `idx_priority_level` (`priority_level`),
  KEY `idx_status` (`status`),
  KEY `idx_confidence_score` (`confidence_score`),
  KEY `idx_assigned_to` (`assigned_to`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `ai_recommendations_ibfk_1` FOREIGN KEY (`insight_id`) REFERENCES `ai_insights` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ai_recommendations_ibfk_2` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_recommendations_ibfk_3` FOREIGN KEY (`milestone_id`) REFERENCES `case_milestones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_recommendations_ibfk_4` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_recommendations_ibfk_5` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ai_recommendations_ibfk_6` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='AI-generated recommendations with implementation tracking';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_recommendations`
--

LOCK TABLES `ai_recommendations` WRITE;
/*!40000 ALTER TABLE `ai_recommendations` DISABLE KEYS */;
/*!40000 ALTER TABLE `ai_recommendations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ai_training_data`
--

DROP TABLE IF EXISTS `ai_training_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ai_training_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `model_id` int NOT NULL,
  `case_id` int DEFAULT NULL,
  `milestone_id` int DEFAULT NULL,
  `feature_vector` json NOT NULL COMMENT 'Input features for training',
  `target_value` json NOT NULL COMMENT 'Expected output/label',
  `data_source` enum('historical_cases','milestone_activities','user_feedback','external_data','synthetic') NOT NULL,
  `data_quality_score` decimal(5,4) DEFAULT '1.0000',
  `is_validated` tinyint(1) DEFAULT '0',
  `validation_method` varchar(100) DEFAULT NULL,
  `data_completeness` decimal(5,4) DEFAULT '1.0000',
  `collection_timestamp` timestamp NOT NULL,
  `data_version` varchar(20) DEFAULT '1.0',
  `source_reference` varchar(500) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `milestone_id` (`milestone_id`),
  KEY `idx_model_id` (`model_id`),
  KEY `idx_case_id` (`case_id`),
  KEY `idx_data_source` (`data_source`),
  KEY `idx_collection_timestamp` (`collection_timestamp`),
  CONSTRAINT `ai_training_data_ibfk_1` FOREIGN KEY (`model_id`) REFERENCES `ai_models` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ai_training_data_ibfk_2` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE SET NULL,
  CONSTRAINT `ai_training_data_ibfk_3` FOREIGN KEY (`milestone_id`) REFERENCES `case_milestones` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Training data for machine learning models';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ai_training_data`
--

LOCK TABLES `ai_training_data` WRITE;
/*!40000 ALTER TABLE `ai_training_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `ai_training_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill_of_materials`
--

DROP TABLE IF EXISTS `bill_of_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill_of_materials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bom_id` varchar(50) NOT NULL,
  `quotation_id` int NOT NULL,
  `date` date NOT NULL,
  `status` enum('draft','final') DEFAULT 'draft',
  `notes` text,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bom_id` (`bom_id`),
  KEY `quotation_id` (`quotation_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `bill_of_materials_ibfk_1` FOREIGN KEY (`quotation_id`) REFERENCES `quotations` (`id`),
  CONSTRAINT `bill_of_materials_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_of_materials`
--

LOCK TABLES `bill_of_materials` WRITE;
/*!40000 ALTER TABLE `bill_of_materials` DISABLE KEYS */;
INSERT INTO `bill_of_materials` (`id`, `bom_id`, `quotation_id`, `date`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES (1,'VESPL/BOM/2526/000',1,'2025-09-09','draft',NULL,1,'2025-09-09 18:02:15','2025-09-09 18:02:15');
/*!40000 ALTER TABLE `bill_of_materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bom_components`
--

DROP TABLE IF EXISTS `bom_components`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bom_components` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bom_header_id` int NOT NULL,
  `line_number` int NOT NULL,
  `component_type` enum('raw_material','sub_assembly','purchased_part','service') NOT NULL,
  `component_id` int NOT NULL,
  `component_code` varchar(50) NOT NULL,
  `component_name` varchar(200) NOT NULL,
  `quantity_required` decimal(12,6) NOT NULL,
  `unit_of_measurement` varchar(20) DEFAULT NULL,
  `wastage_percentage` decimal(5,2) DEFAULT '0.00',
  `total_quantity` decimal(12,6) GENERATED ALWAYS AS ((`quantity_required` * (1 + (`wastage_percentage` / 100)))) STORED,
  `unit_cost` decimal(12,4) DEFAULT '0.0000',
  `total_cost` decimal(12,4) GENERATED ALWAYS AS ((`total_quantity` * `unit_cost`)) STORED,
  `operation_sequence` int DEFAULT NULL,
  `is_critical_component` tinyint(1) DEFAULT '0',
  `substitute_component_id` int DEFAULT NULL,
  `preferred_supplier_id` int DEFAULT NULL,
  `lead_time_days` int DEFAULT '0',
  `notes` text,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_bom_line` (`bom_header_id`,`line_number`),
  KEY `idx_component_type_id` (`component_type`,`component_id`),
  KEY `idx_component_code` (`component_code`),
  CONSTRAINT `bom_components_ibfk_1` FOREIGN KEY (`bom_header_id`) REFERENCES `bom_headers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bom_components`
--

LOCK TABLES `bom_components` WRITE;
/*!40000 ALTER TABLE `bom_components` DISABLE KEYS */;
/*!40000 ALTER TABLE `bom_components` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bom_headers`
--

DROP TABLE IF EXISTS `bom_headers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bom_headers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bom_number` varchar(50) NOT NULL,
  `production_item_id` int NOT NULL,
  `version` varchar(10) DEFAULT '1.0',
  `description` text,
  `quantity_per_unit` decimal(10,4) DEFAULT '1.0000',
  `material_cost` decimal(12,4) DEFAULT '0.0000',
  `labor_cost` decimal(12,4) DEFAULT '0.0000',
  `overhead_cost` decimal(12,4) DEFAULT '0.0000',
  `total_cost` decimal(12,4) GENERATED ALWAYS AS (((`material_cost` + `labor_cost`) + `overhead_cost`)) STORED,
  `status` enum('draft','active','inactive','superseded') DEFAULT 'draft',
  `effective_from` date DEFAULT NULL,
  `effective_to` date DEFAULT NULL,
  `is_current_version` tinyint(1) DEFAULT '1',
  `approved_by` int DEFAULT NULL,
  `approved_date` timestamp NULL DEFAULT NULL,
  `approval_comments` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bom_number` (`bom_number`),
  KEY `idx_bom_number` (`bom_number`),
  KEY `idx_production_item` (`production_item_id`),
  KEY `idx_version` (`production_item_id`,`version`),
  KEY `idx_current_version` (`production_item_id`,`is_current_version`),
  CONSTRAINT `bom_headers_ibfk_1` FOREIGN KEY (`production_item_id`) REFERENCES `production_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bom_headers`
--

LOCK TABLES `bom_headers` WRITE;
/*!40000 ALTER TABLE `bom_headers` DISABLE KEYS */;
/*!40000 ALTER TABLE `bom_headers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bom_items`
--

DROP TABLE IF EXISTS `bom_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bom_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bom_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `bom_id` (`bom_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `bom_items_ibfk_1` FOREIGN KEY (`bom_id`) REFERENCES `bill_of_materials` (`id`),
  CONSTRAINT `bom_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bom_items`
--

LOCK TABLES `bom_items` WRITE;
/*!40000 ALTER TABLE `bom_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `bom_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bom_operations`
--

DROP TABLE IF EXISTS `bom_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bom_operations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `bom_header_id` int NOT NULL,
  `operation_id` int NOT NULL,
  `sequence_number` int NOT NULL,
  `setup_time_hours` decimal(8,4) DEFAULT '0.0000',
  `run_time_per_unit_hours` decimal(8,4) DEFAULT '0.0000',
  `batch_quantity` int DEFAULT '1',
  `predecessor_operation_id` int DEFAULT NULL,
  `can_overlap` tinyint(1) DEFAULT '0',
  `overlap_percentage` decimal(5,2) DEFAULT '0.00',
  `inspection_required` tinyint(1) DEFAULT '0',
  `inspection_percentage` decimal(5,2) DEFAULT '0.00',
  `notes` text,
  `status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_bom_operation` (`bom_header_id`,`sequence_number`),
  KEY `operation_id` (`operation_id`),
  KEY `predecessor_operation_id` (`predecessor_operation_id`),
  KEY `idx_sequence` (`bom_header_id`,`sequence_number`),
  CONSTRAINT `bom_operations_ibfk_1` FOREIGN KEY (`bom_header_id`) REFERENCES `bom_headers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bom_operations_ibfk_2` FOREIGN KEY (`operation_id`) REFERENCES `production_operations` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `bom_operations_ibfk_3` FOREIGN KEY (`predecessor_operation_id`) REFERENCES `bom_operations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bom_operations`
--

LOCK TABLES `bom_operations` WRITE;
/*!40000 ALTER TABLE `bom_operations` DISABLE KEYS */;
/*!40000 ALTER TABLE `bom_operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case_documents`
--

DROP TABLE IF EXISTS `case_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int NOT NULL,
  `document_type` enum('enquiry','estimation','quotation','sales_order','purchase_order','delivery_challan','invoice') NOT NULL,
  `document_id` int NOT NULL,
  `document_number` varchar(50) NOT NULL,
  `is_current` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_current_doc` (`case_id`,`document_type`,`is_current`),
  KEY `idx_case_documents` (`case_id`,`document_type`),
  KEY `idx_document_reference` (`document_type`,`document_id`),
  CONSTRAINT `case_documents_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Links cases to their related documents across the workflow';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_documents`
--

LOCK TABLES `case_documents` WRITE;
/*!40000 ALTER TABLE `case_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `case_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case_history`
--

DROP TABLE IF EXISTS `case_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reference_type` varchar(50) NOT NULL,
  `reference_id` int NOT NULL,
  `status` varchar(50) NOT NULL,
  `notes` text,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `case_history_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_history`
--

LOCK TABLES `case_history` WRITE;
/*!40000 ALTER TABLE `case_history` DISABLE KEYS */;
INSERT INTO `case_history` (`id`, `reference_type`, `reference_id`, `status`, `notes`, `created_by`, `created_at`) VALUES (1,'estimation',1,'draft','Estimation created',1,'2025-09-09 17:48:28'),(2,'estimation',2,'draft','Estimation created',1,'2025-09-09 17:51:08'),(3,'quotation',1,'draft','Quotation created from estimation',1,'2025-09-09 18:02:15'),(4,'sales_order',1,'draft','Sales order created from quotation',1,'2025-09-09 18:15:45'),(5,'sales_order',1,'confirmed','Sales order confirmed for production',1,'2025-09-09 18:25:42'),(6,'work_order',1,'created','Work order created for production',1,'2025-09-09 18:25:53'),(7,'work_order',1,'assigned','Work order status updated to assigned',1,'2025-09-10 18:09:16'),(8,'work_order',1,'in_progress','Work order status updated to in_progress',1,'2025-09-10 18:09:19'),(9,'work_order',1,'paused','Work order status updated to paused',1,'2025-09-10 18:09:22'),(10,'estimation',2,'submitted','Submitted for approval',1,'2025-09-10 18:36:47'),(11,'estimation',2,'approved','Estimation approved',1,'2025-09-10 18:36:50'),(12,'estimation',1,'submitted','Submitted for approval',1,'2025-09-11 12:12:28'),(13,'estimation',1,'approved','Estimation approved',1,'2025-09-11 12:12:53'),(14,'estimation',3,'draft','Estimation created',1,'2025-09-11 13:55:02'),(15,'estimation',4,'draft','Estimation created',1,'2025-09-11 13:56:02'),(16,'estimation',5,'draft','Estimation created',1,'2025-09-11 15:03:25'),(17,'estimation',6,'draft','Estimation created',1,'2025-09-11 15:05:40'),(18,'estimation',7,'draft','Estimation created',1,'2025-09-12 10:37:49'),(19,'estimation',8,'draft','Estimation created',1,'2025-09-12 10:39:42'),(20,'estimation',9,'draft','Estimation created',1,'2025-09-12 11:03:08'),(21,'estimation',9,'submitted','Submitted for approval',1,'2025-09-12 16:43:08'),(22,'estimation',9,'approved','Estimation approved',1,'2025-09-12 16:43:13');
/*!40000 ALTER TABLE `case_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case_milestones`
--

DROP TABLE IF EXISTS `case_milestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_milestones` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int NOT NULL,
  `milestone_template_id` int DEFAULT NULL,
  `milestone_name` varchar(100) NOT NULL,
  `sequence_order` int NOT NULL,
  `milestone_type` enum('planning','approval','execution','review','delivery','payment') NOT NULL,
  `status` enum('not_started','in_progress','blocked','completed','cancelled','deferred') DEFAULT 'not_started',
  `progress_percentage` decimal(5,2) DEFAULT '0.00',
  `is_critical_path` tinyint(1) DEFAULT '0',
  `is_client_milestone` tinyint(1) DEFAULT '0',
  `requires_client_approval` tinyint(1) DEFAULT '0',
  `client_approval_received` tinyint(1) DEFAULT '0',
  `planned_start_date` date DEFAULT NULL,
  `planned_end_date` date DEFAULT NULL,
  `actual_start_date` date DEFAULT NULL,
  `actual_end_date` date DEFAULT NULL,
  `depends_on_milestones` json DEFAULT NULL,
  `blocking_conditions` json DEFAULT NULL,
  `deliverables` text,
  `success_criteria` text,
  `assigned_to` int DEFAULT NULL,
  `responsible_role` varchar(50) DEFAULT NULL,
  `estimated_hours` int DEFAULT '8',
  `actual_hours` int DEFAULT '0',
  `resource_requirements` json DEFAULT NULL,
  `estimated_cost` decimal(12,2) DEFAULT '0.00',
  `actual_cost` decimal(12,2) DEFAULT '0.00',
  `completion_notes` text,
  `quality_score` decimal(3,2) DEFAULT NULL,
  `client_satisfaction_score` decimal(3,2) DEFAULT NULL,
  `created_by` int DEFAULT '1',
  `updated_by` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_case_sequence` (`case_id`,`sequence_order`),
  KEY `milestone_template_id` (`milestone_template_id`),
  KEY `assigned_to` (`assigned_to`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `idx_case_id` (`case_id`),
  KEY `idx_status` (`status`),
  KEY `idx_milestone_type` (`milestone_type`),
  KEY `idx_sequence` (`sequence_order`),
  KEY `idx_critical_path` (`is_critical_path`),
  KEY `idx_dates` (`planned_start_date`,`planned_end_date`),
  CONSTRAINT `case_milestones_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `case_milestones_ibfk_2` FOREIGN KEY (`milestone_template_id`) REFERENCES `milestone_templates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `case_milestones_ibfk_3` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `case_milestones_ibfk_4` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `case_milestones_ibfk_5` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Actual milestones for specific cases';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_milestones`
--

LOCK TABLES `case_milestones` WRITE;
/*!40000 ALTER TABLE `case_milestones` DISABLE KEYS */;
INSERT INTO `case_milestones` (`id`, `case_id`, `milestone_template_id`, `milestone_name`, `sequence_order`, `milestone_type`, `status`, `progress_percentage`, `is_critical_path`, `is_client_milestone`, `requires_client_approval`, `client_approval_received`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `depends_on_milestones`, `blocking_conditions`, `deliverables`, `success_criteria`, `assigned_to`, `responsible_role`, `estimated_hours`, `actual_hours`, `resource_requirements`, `estimated_cost`, `actual_cost`, `completion_notes`, `quality_score`, `client_satisfaction_score`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES (1,5,1,'Project Planning & Requirements',1,'planning','not_started',25.00,1,1,1,0,'2025-09-13','2025-09-18',NULL,NULL,NULL,NULL,'Project plan, requirements document, resource allocation','Client approval of project scope and timeline',NULL,'project_manager',40,10,NULL,15000.00,0.00,NULL,NULL,NULL,1,1,'2025-09-13 02:05:28','2025-09-13 02:07:07'),(2,5,2,'Design Development',2,'execution','not_started',0.00,1,0,0,0,'2025-09-18','2025-10-03',NULL,NULL,NULL,NULL,'Technical drawings, design specifications, material list','Design review completion and approval',NULL,'engineer',120,0,NULL,45000.00,0.00,NULL,NULL,NULL,1,1,'2025-09-13 02:05:28','2025-09-13 02:05:28'),(3,5,3,'Client Design Review',3,'approval','not_started',0.00,1,1,1,0,'2025-10-03','2025-10-06',NULL,NULL,NULL,NULL,'Design presentation, client feedback incorporation','Client sign-off on design specifications',NULL,'client_manager',24,0,NULL,8000.00,0.00,NULL,NULL,NULL,1,1,'2025-09-13 02:05:28','2025-09-13 02:05:28'),(4,5,4,'Procurement & Manufacturing',4,'execution','not_started',0.00,1,0,0,0,'2025-10-06','2025-10-18',NULL,NULL,NULL,NULL,'Materials procurement, manufacturing completion','All components manufactured to specification',NULL,'manufacturing_engineer',96,0,NULL,80000.00,0.00,NULL,NULL,NULL,1,1,'2025-09-13 02:05:28','2025-09-13 02:05:28'),(5,5,5,'Quality Testing',5,'review','not_started',0.00,1,0,0,0,'2025-10-18','2025-10-23',NULL,NULL,NULL,NULL,'Test reports, quality certificates, performance validation','All quality tests passed',NULL,'quality_engineer',40,0,NULL,12000.00,0.00,NULL,NULL,NULL,1,1,'2025-09-13 02:05:28','2025-09-13 02:05:28'),(6,5,6,'Delivery & Installation',6,'delivery','not_started',0.00,1,1,0,0,'2025-10-23','2025-10-28',NULL,NULL,NULL,NULL,'Equipment delivery, installation, training documentation','Successful installation and client training',NULL,'installation_engineer',40,0,NULL,15000.00,0.00,NULL,NULL,NULL,1,1,'2025-09-13 02:05:28','2025-09-13 02:05:28');
/*!40000 ALTER TABLE `case_milestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case_state_transitions`
--

DROP TABLE IF EXISTS `case_state_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_state_transitions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int NOT NULL,
  `from_state` enum('enquiry','estimation','quotation','order','production','delivery','closed') DEFAULT NULL,
  `to_state` enum('enquiry','estimation','quotation','order','production','delivery','closed') NOT NULL,
  `transition_reason` varchar(255) DEFAULT NULL,
  `notes` text,
  `reference_type` enum('enquiry','estimation','quotation','sales_order','production_order','delivery') DEFAULT NULL,
  `reference_id` int DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_case_transitions` (`case_id`,`created_at`),
  KEY `idx_state_transition` (`from_state`,`to_state`),
  KEY `idx_reference` (`reference_type`,`reference_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_state_transitions`
--

LOCK TABLES `case_state_transitions` WRITE;
/*!40000 ALTER TABLE `case_state_transitions` DISABLE KEYS */;
INSERT INTO `case_state_transitions` (`id`, `case_id`, `from_state`, `to_state`, `transition_reason`, `notes`, `reference_type`, `reference_id`, `created_by`, `created_at`) VALUES (1,1,NULL,'enquiry','Migrated existing enquiry to case management system',NULL,'enquiry',1,1,'2025-09-09 17:30:31'),(2,2,NULL,'enquiry','Migrated existing enquiry to case management system',NULL,'enquiry',2,1,'2025-09-09 17:35:12'),(3,3,NULL,'enquiry','Migrated existing enquiry to case management system',NULL,'enquiry',4,1,'2025-09-12 09:32:12'),(4,4,NULL,'enquiry','Migrated existing enquiry to case management system',NULL,'enquiry',5,1,'2025-09-12 09:33:20');
/*!40000 ALTER TABLE `case_state_transitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `case_summary`
--

DROP TABLE IF EXISTS `case_summary`;
/*!50001 DROP VIEW IF EXISTS `case_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `case_summary` AS SELECT 
 1 AS `case_id`,
 1 AS `case_number`,
 1 AS `project_name`,
 1 AS `current_state`,
 1 AS `priority`,
 1 AS `status`,
 1 AS `estimated_value`,
 1 AS `final_value`,
 1 AS `expected_completion_date`,
 1 AS `case_created`,
 1 AS `last_updated`,
 1 AS `client_name`,
 1 AS `contact_person`,
 1 AS `client_city`,
 1 AS `client_state`,
 1 AS `assigned_to_name`,
 1 AS `created_by_name`,
 1 AS `enquiry_count`,
 1 AS `estimation_count`,
 1 AS `quotation_count`,
 1 AS `order_count`,
 1 AS `last_transition_reason`,
 1 AS `last_transition_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `case_timeline`
--

DROP TABLE IF EXISTS `case_timeline`;
/*!50001 DROP VIEW IF EXISTS `case_timeline`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `case_timeline` AS SELECT 
 1 AS `case_id`,
 1 AS `case_number`,
 1 AS `project_name`,
 1 AS `client_name`,
 1 AS `current_state`,
 1 AS `status`,
 1 AS `case_created`,
 1 AS `transition_id`,
 1 AS `from_state`,
 1 AS `to_state`,
 1 AS `transition_reason`,
 1 AS `transition_notes`,
 1 AS `reference_type`,
 1 AS `reference_id`,
 1 AS `transition_date`,
 1 AS `transition_by`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `case_workflow_definitions`
--

DROP TABLE IF EXISTS `case_workflow_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_workflow_definitions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state_name` enum('enquiry','estimation','quotation','order','production','delivery','closed') NOT NULL,
  `sub_state_name` varchar(50) NOT NULL,
  `step_order` int NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `description` text,
  `sla_hours` decimal(8,2) NOT NULL DEFAULT '24.00',
  `requires_approval` tinyint(1) DEFAULT '0',
  `approval_role` varchar(50) DEFAULT NULL,
  `is_client_visible` tinyint(1) DEFAULT '1',
  `notify_on_entry` tinyint(1) DEFAULT '1',
  `escalation_hours` decimal(8,2) DEFAULT NULL,
  `escalation_to` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_state_substate` (`state_name`,`sub_state_name`),
  KEY `idx_state_step` (`state_name`,`step_order`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_workflow_definitions`
--

LOCK TABLES `case_workflow_definitions` WRITE;
/*!40000 ALTER TABLE `case_workflow_definitions` DISABLE KEYS */;
INSERT INTO `case_workflow_definitions` (`id`, `state_name`, `sub_state_name`, `step_order`, `display_name`, `description`, `sla_hours`, `requires_approval`, `approval_role`, `is_client_visible`, `notify_on_entry`, `escalation_hours`, `escalation_to`, `created_at`, `updated_at`) VALUES (1,'enquiry','received',1,'Enquiry Received','New enquiry has been received and logged',2.00,0,NULL,1,1,NULL,NULL,'2025-09-12 18:55:54','2025-09-12 18:55:54'),(2,'enquiry','under_review',2,'Under Review','Technical team is reviewing the enquiry',4.00,0,NULL,1,1,NULL,NULL,'2025-09-12 18:55:54','2025-09-12 18:55:54'),(3,'enquiry','approved',3,'Approved for Estimation','Enquiry approved, ready for estimation',1.00,1,NULL,1,1,NULL,NULL,'2025-09-12 18:55:54','2025-09-12 18:55:54'),(4,'estimation','assigned',1,'Assigned to Engineer','Estimation assigned to technical engineer',2.00,0,NULL,1,1,NULL,NULL,'2025-09-12 18:55:54','2025-09-12 18:55:54'),(5,'estimation','in_progress',2,'Estimation in Progress','Engineer is working on the estimation',16.00,0,NULL,1,1,NULL,NULL,'2025-09-12 18:55:54','2025-09-12 18:55:54'),(6,'estimation','approved',3,'Approved','Estimation approved for quotation',1.00,0,NULL,1,1,NULL,NULL,'2025-09-12 18:55:54','2025-09-12 18:55:54');
/*!40000 ALTER TABLE `case_workflow_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cases`
--

DROP TABLE IF EXISTS `cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cases` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_number` varchar(50) NOT NULL,
  `enquiry_id` int DEFAULT NULL,
  `current_state` enum('enquiry','estimation','quotation','order','production','delivery','closed') DEFAULT 'enquiry',
  `priority` enum('low','medium','high') DEFAULT 'medium',
  `client_id` int NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `requirements` text,
  `estimated_value` decimal(15,2) DEFAULT NULL,
  `final_value` decimal(15,2) DEFAULT NULL,
  `assigned_to` int DEFAULT NULL,
  `created_by` int NOT NULL,
  `status` enum('active','on_hold','cancelled','completed') DEFAULT 'active',
  `expected_completion_date` date DEFAULT NULL,
  `actual_completion_date` date DEFAULT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sub_state` varchar(50) DEFAULT NULL COMMENT 'Current sub-state within the main state',
  `workflow_step` int DEFAULT '1',
  `state_entered_at` timestamp NULL DEFAULT NULL,
  `expected_state_completion` timestamp NULL DEFAULT NULL,
  `sla_hours_for_state` decimal(8,2) DEFAULT '24.00',
  `is_sla_breached` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `case_number` (`case_number`),
  KEY `enquiry_id` (`enquiry_id`),
  KEY `created_by` (`created_by`),
  KEY `idx_case_number` (`case_number`),
  KEY `idx_current_state` (`current_state`),
  KEY `idx_client_id` (`client_id`),
  KEY `idx_assigned_to` (`assigned_to`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `cases_ibfk_1` FOREIGN KEY (`enquiry_id`) REFERENCES `sales_enquiries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `cases_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `cases_ibfk_3` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `cases_ibfk_4` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Main cases table for tracking entire project lifecycle';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cases`
--

LOCK TABLES `cases` WRITE;
/*!40000 ALTER TABLE `cases` DISABLE KEYS */;
INSERT INTO `cases` (`id`, `case_number`, `enquiry_id`, `current_state`, `priority`, `client_id`, `project_name`, `requirements`, `estimated_value`, `final_value`, `assigned_to`, `created_by`, `status`, `expected_completion_date`, `actual_completion_date`, `notes`, `created_at`, `updated_at`, `sub_state`, `workflow_step`, `state_entered_at`, `expected_state_completion`, `sla_hours_for_state`, `is_sla_breached`) VALUES (1,'VESPL/C/2526/001',1,'enquiry','medium',1,'Test Project','Test description',NULL,NULL,NULL,1,'active',NULL,NULL,NULL,'2025-09-09 17:30:31','2025-09-12 17:50:31',NULL,1,NULL,NULL,24.00,0),(2,'VESPL/C/2526/002',2,'enquiry','medium',2,'Robotic Welding System','Industrial robotic welding system for automotive parts manufacturing',NULL,NULL,NULL,1,'active',NULL,NULL,NULL,'2025-09-09 17:35:12','2025-09-12 17:50:31',NULL,1,NULL,NULL,24.00,0),(3,'VESPL/C/2526/003',4,'enquiry','medium',1,'Test Project Fixed','Test Description Fixed',NULL,NULL,NULL,1,'active',NULL,NULL,NULL,'2025-09-12 09:32:12','2025-09-12 17:50:31',NULL,1,NULL,NULL,24.00,0),(4,'VESPL/C/2526/004',5,'enquiry','medium',6,'Updated Test Project','Updated test description',NULL,NULL,NULL,1,'active',NULL,NULL,NULL,'2025-09-12 09:33:20','2025-09-12 17:50:31',NULL,1,NULL,NULL,24.00,0),(5,'VESPL/C/2025/001',NULL,'enquiry','medium',1,'Test Enhanced Workflow Project',NULL,NULL,NULL,NULL,1,'active',NULL,NULL,NULL,'2025-09-12 18:56:17','2025-09-13 03:00:00','received',1,'2025-09-12 18:56:17','2025-09-12 20:56:17',2.00,1),(10,'TEST-CASE',13,'enquiry','medium',1,'Test Project',NULL,NULL,NULL,NULL,1,'active',NULL,NULL,NULL,'2025-09-13 03:23:14','2025-09-13 03:23:14',NULL,1,NULL,NULL,24.00,0),(14,'TEST-CASE-001',17,'estimation','medium',7,'Test Project','Test requirements',NULL,NULL,NULL,1,'active',NULL,NULL,NULL,'2025-09-13 03:59:03','2025-09-13 03:59:03',NULL,1,NULL,NULL,24.00,0);
/*!40000 ALTER TABLE `cases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parent_id` int DEFAULT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name`, `parent_id`, `description`, `created_at`, `updated_at`) VALUES (1,'Electrical',NULL,'Electrical components and equipment','2025-09-11 14:58:15','2025-09-11 14:58:15'),(2,'Control Panels',NULL,'Main electrical control panels','2025-09-11 14:58:15','2025-09-11 14:58:15'),(3,'UPS Systems',NULL,'Uninterruptible Power Supply systems','2025-09-11 14:58:15','2025-09-11 14:58:15'),(4,'Generators',NULL,'Power generation equipment','2025-09-11 14:58:15','2025-09-11 14:58:15'),(7,'Circuit Breakers',1,'MCBs, MCCBs, and other circuit protection devices','2025-09-11 15:49:09','2025-09-11 15:49:09'),(8,'Distribution Boards',2,'Distribution panels and electrical boards','2025-09-11 15:49:09','2025-09-11 15:49:09');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_communications`
--

DROP TABLE IF EXISTS `client_communications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client_communications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `case_id` int NOT NULL,
  `milestone_id` int DEFAULT NULL,
  `client_portal_user_id` int DEFAULT NULL,
  `internal_user_id` int DEFAULT NULL,
  `communication_type` enum('comment','query','approval_request','approval_response','file_upload','system_update','milestone_update') NOT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `message` text NOT NULL,
  `is_from_client` tinyint(1) DEFAULT '0',
  `requires_response` tinyint(1) DEFAULT '0',
  `response_deadline` timestamp NULL DEFAULT NULL,
  `parent_communication_id` int DEFAULT NULL,
  `attachment_path` varchar(500) DEFAULT NULL,
  `attachment_filename` varchar(255) DEFAULT NULL,
  `attachment_size` int DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `read_at` timestamp NULL DEFAULT NULL,
  `is_resolved` tinyint(1) DEFAULT '0',
  `resolved_at` timestamp NULL DEFAULT NULL,
  `resolved_by` int DEFAULT NULL,
  `visible_to_client` tinyint(1) DEFAULT '1',
  `client_priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `client_portal_user_id` (`client_portal_user_id`),
  KEY `internal_user_id` (`internal_user_id`),
  KEY `parent_communication_id` (`parent_communication_id`),
  KEY `resolved_by` (`resolved_by`),
  KEY `idx_case_id` (`case_id`),
  KEY `idx_milestone_id` (`milestone_id`),
  KEY `idx_communication_type` (`communication_type`),
  CONSTRAINT `client_communications_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE CASCADE,
  CONSTRAINT `client_communications_ibfk_2` FOREIGN KEY (`milestone_id`) REFERENCES `case_milestones` (`id`) ON DELETE SET NULL,
  CONSTRAINT `client_communications_ibfk_3` FOREIGN KEY (`client_portal_user_id`) REFERENCES `client_portal_access` (`id`) ON DELETE SET NULL,
  CONSTRAINT `client_communications_ibfk_4` FOREIGN KEY (`internal_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `client_communications_ibfk_5` FOREIGN KEY (`parent_communication_id`) REFERENCES `client_communications` (`id`) ON DELETE SET NULL,
  CONSTRAINT `client_communications_ibfk_6` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_communications`
--

LOCK TABLES `client_communications` WRITE;
/*!40000 ALTER TABLE `client_communications` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_communications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_portal_access`
--

DROP TABLE IF EXISTS `client_portal_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client_portal_access` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `portal_user_email` varchar(255) NOT NULL,
  `portal_user_name` varchar(100) NOT NULL,
  `access_token` varchar(255) NOT NULL,
  `access_level` enum('view_only','interactive','collaborative') DEFAULT 'view_only',
  `can_approve_milestones` tinyint(1) DEFAULT '0',
  `can_add_comments` tinyint(1) DEFAULT '1',
  `can_upload_files` tinyint(1) DEFAULT '0',
  `can_view_costs` tinyint(1) DEFAULT '0',
  `last_login_at` timestamp NULL DEFAULT NULL,
  `login_count` int DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `expires_at` timestamp NULL DEFAULT NULL,
  `portal_password_hash` varchar(255) DEFAULT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `password_reset_expires` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `access_token` (`access_token`),
  UNIQUE KEY `uk_client_email` (`client_id`,`portal_user_email`),
  KEY `idx_client_id` (`client_id`),
  KEY `idx_access_token` (`access_token`),
  KEY `idx_portal_email` (`portal_user_email`),
  CONSTRAINT `client_portal_access_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_portal_access`
--

LOCK TABLES `client_portal_access` WRITE;
/*!40000 ALTER TABLE `client_portal_access` DISABLE KEYS */;
INSERT INTO `client_portal_access` (`id`, `client_id`, `portal_user_email`, `portal_user_name`, `access_token`, `access_level`, `can_approve_milestones`, `can_add_comments`, `can_upload_files`, `can_view_costs`, `last_login_at`, `login_count`, `is_active`, `expires_at`, `portal_password_hash`, `password_reset_token`, `password_reset_expires`, `created_at`, `updated_at`) VALUES (1,1,'rajesh@tatamotors.com','Rajesh Kumar','26e2f1fa637c29f55c3f788b16dcdb2f','interactive',1,1,0,0,NULL,0,1,NULL,NULL,NULL,NULL,'2025-09-13 02:11:39','2025-09-13 02:11:39'),(2,2,'priya@mahindra.com','Priya Sharma','dc95b3d39c44c38ab4ce48bedc4b9df4','interactive',1,1,0,0,NULL,0,1,NULL,NULL,NULL,NULL,'2025-09-13 02:11:39','2025-09-13 02:11:39'),(3,3,'amit@bajaj.com','Amit Patel','701df5905ac3a2265abfd5a97bf56adb','interactive',1,1,0,0,NULL,0,1,NULL,NULL,NULL,NULL,'2025-09-13 02:11:39','2025-09-13 02:11:39'),(4,4,'client4@test.com','Test Person','7a52f8154fbb4d8ae211b18bea69bb86','interactive',1,1,0,0,NULL,0,1,NULL,NULL,NULL,NULL,'2025-09-13 02:11:39','2025-09-13 02:11:39'),(5,5,'john@test.com','John Doe','63cbfd1fd2cefe717ccc86788b9a05a3','interactive',1,1,0,0,NULL,0,1,NULL,NULL,NULL,NULL,'2025-09-13 02:11:39','2025-09-13 02:11:39');
/*!40000 ALTER TABLE `client_portal_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_portal_notifications`
--

DROP TABLE IF EXISTS `client_portal_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client_portal_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_portal_user_id` int NOT NULL,
  `case_id` int DEFAULT NULL,
  `milestone_id` int DEFAULT NULL,
  `communication_id` int DEFAULT NULL,
  `notification_type` enum('milestone_update','new_message','approval_request','document_shared','case_update','system_alert') NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `priority` enum('low','medium','high') DEFAULT 'medium',
  `is_read` tinyint(1) DEFAULT '0',
  `read_at` timestamp NULL DEFAULT NULL,
  `email_sent` tinyint(1) DEFAULT '0',
  `email_sent_at` timestamp NULL DEFAULT NULL,
  `action_url` varchar(500) DEFAULT NULL,
  `action_text` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `milestone_id` (`milestone_id`),
  KEY `communication_id` (`communication_id`),
  KEY `idx_client_portal_user_id` (`client_portal_user_id`),
  KEY `idx_case_id` (`case_id`),
  KEY `idx_notification_type` (`notification_type`),
  CONSTRAINT `client_portal_notifications_ibfk_1` FOREIGN KEY (`client_portal_user_id`) REFERENCES `client_portal_access` (`id`) ON DELETE CASCADE,
  CONSTRAINT `client_portal_notifications_ibfk_2` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`) ON DELETE SET NULL,
  CONSTRAINT `client_portal_notifications_ibfk_3` FOREIGN KEY (`milestone_id`) REFERENCES `case_milestones` (`id`) ON DELETE SET NULL,
  CONSTRAINT `client_portal_notifications_ibfk_4` FOREIGN KEY (`communication_id`) REFERENCES `client_communications` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_portal_notifications`
--

LOCK TABLES `client_portal_notifications` WRITE;
/*!40000 ALTER TABLE `client_portal_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_portal_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `pincode` varchar(20) DEFAULT NULL,
  `gstin` varchar(20) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` (`id`, `company_name`, `contact_person`, `email`, `phone`, `address`, `city`, `state`, `pincode`, `gstin`, `status`, `created_at`, `updated_at`) VALUES (1,'Tata Motors Ltd','Rajesh Kumar','rajesh@tatamotors.com','9876543210','Industrial Area, Sector 21','Pune','Maharashtra','411001','27AAACT1234C1Z5','active','2025-09-09 17:23:08','2025-09-09 17:23:08'),(2,'Mahindra & Mahindra','Priya Sharma','priya@mahindra.com','9876543211','Auto Cluster','Chennai','Tamil Nadu','600001','33AAACM5625R1ZZ','active','2025-09-09 17:23:08','2025-09-09 17:23:08'),(3,'Bajaj Auto Ltd','Amit Patel','amit@bajaj.com','9876543212','Akurdi Industrial Estate','Pune','Maharashtra','411001','27AAACB2384C1Z6','active','2025-09-09 17:23:08','2025-09-09 17:23:08'),(4,'Test Company','Test Person',NULL,'1234567890',NULL,NULL,NULL,NULL,NULL,'active','2025-09-12 09:05:03','2025-09-12 09:05:03'),(5,'Full Test Company','John Doe','john@test.com','9876543210',NULL,'Mumbai','Maharashtra',NULL,NULL,'active','2025-09-12 09:05:18','2025-09-12 09:05:18'),(6,'Elastos Acia LLP','S R Bhandary','srbhandary@gmail.com','9632594411','Mangalore','Mangalore','Karnataka','574144',NULL,'active','2025-09-12 09:07:19','2025-09-12 09:07:19'),(7,'Bytevantage Enterprise Solutions','S R Bhandary','srbhandary2001@yahoo.com','9632594422','Padavinangady','Mangalore','Karnataka','574008',NULL,'active','2025-09-13 03:14:45','2025-09-13 03:14:45');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company_config`
--

DROP TABLE IF EXISTS `company_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) NOT NULL DEFAULT 'VTRIA ENGINEERING SOLUTIONS PVT LTD',
  `motto` varchar(255) DEFAULT 'Engineering for a Better Tomorrow',
  `logo_url` varchar(255) DEFAULT 'vtria_logo.jpg',
  `address` text,
  `city` varchar(255) DEFAULT 'Mangalore',
  `state` varchar(255) DEFAULT 'Karnataka',
  `pincode` varchar(20) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gstin` varchar(20) DEFAULT NULL,
  `download_folder_path` varchar(500) DEFAULT '/downloads',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_config`
--

LOCK TABLES `company_config` WRITE;
/*!40000 ALTER TABLE `company_config` DISABLE KEYS */;
INSERT INTO `company_config` (`id`, `company_name`, `motto`, `logo_url`, `address`, `city`, `state`, `pincode`, `phone`, `email`, `gstin`, `download_folder_path`, `created_at`, `updated_at`) VALUES (1,'VTRIA ENGINEERING SOLUTIONS PVT LTD','Engineering for a Better Tomorrow','vtria_logo.jpg','Mangalore, Karnataka, India','Mangalore','Karnataka',NULL,'+91-XXXXXXXXXX','info@vtrai.com','29XXXXXXXXXXXXX','/downloads','2025-09-10 05:20:03','2025-09-13 10:20:29');
/*!40000 ALTER TABLE `company_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_credit_limits`
--

DROP TABLE IF EXISTS `customer_credit_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_credit_limits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `credit_limit` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `credit_days` int NOT NULL DEFAULT '30',
  `current_outstanding` decimal(15,4) DEFAULT '0.0000',
  `available_credit` decimal(15,4) GENERATED ALWAYS AS ((`credit_limit` - `current_outstanding`)) STORED,
  `risk_category` enum('low','medium','high','blocked') DEFAULT 'low',
  `payment_behavior` enum('excellent','good','average','poor') DEFAULT 'good',
  `is_active` tinyint(1) DEFAULT '1',
  `blocked_reason` text,
  `blocked_date` date DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_customer` (`customer_id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `idx_credit_limit` (`credit_limit`),
  KEY `idx_risk_category` (`risk_category`),
  CONSTRAINT `customer_credit_limits_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `customer_credit_limits_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `customer_credit_limits_ibfk_3` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_credit_limits`
--

LOCK TABLES `customer_credit_limits` WRITE;
/*!40000 ALTER TABLE `customer_credit_limits` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_credit_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_challan_items`
--

DROP TABLE IF EXISTS `delivery_challan_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_challan_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `delivery_challan_id` int NOT NULL,
  `sales_order_item_id` int DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_code` varchar(100) DEFAULT NULL,
  `description` text,
  `hsn_sac` varchar(20) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `total_amount` decimal(12,2) DEFAULT NULL,
  `serial_numbers` text,
  `warranty_period` varchar(50) DEFAULT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `delivery_challan_id` (`delivery_challan_id`),
  KEY `sales_order_item_id` (`sales_order_item_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `delivery_challan_items_ibfk_1` FOREIGN KEY (`delivery_challan_id`) REFERENCES `delivery_challans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `delivery_challan_items_ibfk_2` FOREIGN KEY (`sales_order_item_id`) REFERENCES `sales_order_items` (`id`),
  CONSTRAINT `delivery_challan_items_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_challan_items`
--

LOCK TABLES `delivery_challan_items` WRITE;
/*!40000 ALTER TABLE `delivery_challan_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_challan_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `delivery_challans`
--

DROP TABLE IF EXISTS `delivery_challans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_challans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dc_number` varchar(50) NOT NULL,
  `sales_order_id` int NOT NULL,
  `invoice_id` int DEFAULT NULL,
  `dc_date` date NOT NULL,
  `customer_id` int NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_address` text,
  `customer_gstin` varchar(15) DEFAULT NULL,
  `shipping_address` text,
  `delivery_date` date DEFAULT NULL,
  `vehicle_number` varchar(50) DEFAULT NULL,
  `driver_name` varchar(100) DEFAULT NULL,
  `driver_contact` varchar(20) DEFAULT NULL,
  `total_items` int DEFAULT '0',
  `total_quantity` decimal(10,2) DEFAULT '0.00',
  `status` enum('draft','prepared','dispatched','delivered','cancelled') DEFAULT 'draft',
  `notes` text,
  `prepared_by` int DEFAULT NULL,
  `approved_by` int DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dc_number` (`dc_number`),
  KEY `sales_order_id` (`sales_order_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `customer_id` (`customer_id`),
  KEY `prepared_by` (`prepared_by`),
  KEY `approved_by` (`approved_by`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `delivery_challans_ibfk_1` FOREIGN KEY (`sales_order_id`) REFERENCES `sales_orders` (`id`),
  CONSTRAINT `delivery_challans_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`),
  CONSTRAINT `delivery_challans_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `delivery_challans_ibfk_4` FOREIGN KEY (`prepared_by`) REFERENCES `users` (`id`),
  CONSTRAINT `delivery_challans_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`),
  CONSTRAINT `delivery_challans_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `delivery_challans`
--

LOCK TABLES `delivery_challans` WRITE;
/*!40000 ALTER TABLE `delivery_challans` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_challans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `department_name` varchar(100) NOT NULL,
  `department_code` varchar(10) DEFAULT NULL,
  `description` text,
  `head_of_department_id` int DEFAULT NULL,
  `parent_department_id` int DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `cost_center` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `department_name` (`department_name`),
  UNIQUE KEY `department_code` (`department_code`),
  KEY `idx_department_code` (`department_code`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` (`id`, `department_name`, `department_code`, `description`, `head_of_department_id`, `parent_department_id`, `status`, `cost_center`, `created_at`, `updated_at`) VALUES (1,'Human Resources','HR','Human Resources Department',NULL,NULL,'active',NULL,'2025-09-12 03:23:29','2025-09-12 03:23:29'),(2,'Information Technology','IT','Information Technology Department',NULL,NULL,'active',NULL,'2025-09-12 03:23:29','2025-09-12 03:23:29'),(3,'Finance & Accounts','FIN','Finance and Accounts Department',NULL,NULL,'active',NULL,'2025-09-12 03:23:29','2025-09-12 03:23:29'),(4,'Sales & Marketing','SALES','Sales and Marketing Department',NULL,NULL,'active',NULL,'2025-09-12 03:23:29','2025-09-12 03:23:29'),(5,'Operations','OPS','Operations Department',NULL,NULL,'active',NULL,'2025-09-12 03:23:29','2025-09-12 03:23:29');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_sequences`
--

DROP TABLE IF EXISTS `document_sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_sequences` (
  `id` int NOT NULL AUTO_INCREMENT,
  `document_type` varchar(10) NOT NULL,
  `financial_year` varchar(4) NOT NULL,
  `last_sequence` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_doc_fy` (`document_type`,`financial_year`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_sequences`
--

LOCK TABLES `document_sequences` WRITE;
/*!40000 ALTER TABLE `document_sequences` DISABLE KEYS */;
INSERT INTO `document_sequences` (`id`, `document_type`, `financial_year`, `last_sequence`, `created_at`, `updated_at`) VALUES (1,'EQ','2526',13,'2025-09-09 17:28:33','2025-09-13 03:28:32'),(2,'ES','2526',1,'2025-09-09 17:48:28','2025-09-09 17:51:08'),(4,'Q','2526',8,'2025-09-09 18:00:12','2025-09-12 16:58:46'),(6,'BOM','2526',0,'2025-09-09 18:02:15','2025-09-09 18:02:15'),(7,'SO','2526',2,'2025-09-09 18:13:47','2025-09-09 18:15:45'),(10,'WO','2526',1,'2025-09-09 18:23:00','2025-09-09 18:25:53'),(12,'ET','2526',23,'2025-09-11 13:55:02','2025-09-13 04:07:48'),(20,'C','2526',10,'2025-09-12 17:37:45','2025-09-13 04:07:41');
/*!40000 ALTER TABLE `document_sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(20) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `employee_type` enum('full_time','part_time','contract','intern','consultant') DEFAULT 'full_time',
  `status` enum('active','inactive','terminated','on_leave') DEFAULT 'active',
  `hire_date` date NOT NULL,
  `department_id` int DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `basic_salary` decimal(12,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employee_id` (`employee_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enquiry_status_history`
--

DROP TABLE IF EXISTS `enquiry_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enquiry_status_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `enquiry_id` int DEFAULT NULL,
  `previous_status` varchar(50) DEFAULT NULL,
  `new_status` varchar(50) DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `comments` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `enquiry_id` (`enquiry_id`),
  CONSTRAINT `enquiry_status_history_ibfk_1` FOREIGN KEY (`enquiry_id`) REFERENCES `sales_enquiries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enquiry_status_history`
--

LOCK TABLES `enquiry_status_history` WRITE;
/*!40000 ALTER TABLE `enquiry_status_history` DISABLE KEYS */;
INSERT INTO `enquiry_status_history` (`id`, `enquiry_id`, `previous_status`, `new_status`, `changed_by`, `comments`, `created_at`) VALUES (1,5,'assigned','estimated',NULL,'Status changed from assigned to estimated','2025-09-12 11:02:36'),(2,4,'new','assigned',NULL,'Status changed from new to assigned','2025-09-12 12:35:16'),(3,16,'new','assigned',NULL,'Status changed from new to assigned','2025-09-13 03:27:38'),(4,17,'new','assigned',NULL,'Status changed from new to assigned','2025-09-13 03:28:38');
/*!40000 ALTER TABLE `enquiry_status_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment_usage`
--

DROP TABLE IF EXISTS `equipment_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment_usage` (
  `id` int NOT NULL AUTO_INCREMENT,
  `work_order_id` int NOT NULL,
  `equipment_name` varchar(255) NOT NULL,
  `equipment_code` varchar(100) DEFAULT NULL,
  `start_time` timestamp NOT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `total_hours` decimal(8,2) DEFAULT NULL,
  `operator_id` int DEFAULT NULL,
  `status` enum('in_use','idle','maintenance','breakdown') DEFAULT 'in_use',
  `efficiency_percentage` decimal(5,2) DEFAULT '100.00',
  `maintenance_required` tinyint(1) DEFAULT '0',
  `maintenance_notes` text,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_work_order_id` (`work_order_id`),
  KEY `idx_equipment_code` (`equipment_code`),
  KEY `idx_operator_id` (`operator_id`),
  CONSTRAINT `equipment_usage_ibfk_1` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `equipment_usage_ibfk_2` FOREIGN KEY (`operator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment_usage`
--

LOCK TABLES `equipment_usage` WRITE;
/*!40000 ALTER TABLE `equipment_usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipment_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimation_items`
--

DROP TABLE IF EXISTS `estimation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimation_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `estimation_id` int DEFAULT NULL,
  `section_id` int DEFAULT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `mrp` decimal(12,2) NOT NULL,
  `discount_percentage` decimal(5,2) DEFAULT NULL,
  `discounted_price` decimal(12,2) DEFAULT NULL,
  `final_price` decimal(12,2) DEFAULT NULL,
  `allocation_type` enum('any_available','specific_serial','specific_batch','new_purchase') DEFAULT 'any_available',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `subsection_id` int DEFAULT NULL,
  `stock_available` int DEFAULT '0',
  `is_stock_available` tinyint(1) DEFAULT '0',
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `estimation_id` (`estimation_id`),
  KEY `section_id` (`section_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `estimation_items_ibfk_1` FOREIGN KEY (`estimation_id`) REFERENCES `estimations` (`id`),
  CONSTRAINT `estimation_items_ibfk_2` FOREIGN KEY (`section_id`) REFERENCES `estimation_sections` (`id`),
  CONSTRAINT `estimation_items_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimation_items`
--

LOCK TABLES `estimation_items` WRITE;
/*!40000 ALTER TABLE `estimation_items` DISABLE KEYS */;
INSERT INTO `estimation_items` (`id`, `estimation_id`, `section_id`, `product_id`, `quantity`, `mrp`, `discount_percentage`, `discounted_price`, `final_price`, `allocation_type`, `created_at`, `updated_at`, `subsection_id`, `stock_available`, `is_stock_available`, `notes`) VALUES (2,9,19,6,2,450.00,5.00,427.50,855.00,'any_available','2025-09-12 12:18:57','2025-09-12 12:18:57',18,0,0,NULL),(3,9,19,5,1,2500.00,2.00,2450.00,2450.00,'any_available','2025-09-12 12:21:50','2025-09-12 13:04:19',18,0,0,NULL),(4,9,19,7,10,280.00,3.00,271.60,2716.00,'any_available','2025-09-12 13:03:53','2025-09-12 13:04:12',18,0,0,NULL),(5,8,6,3,3,180000.00,5.00,171000.00,513000.00,'any_available','2025-09-12 13:32:48','2025-09-12 13:32:48',21,0,0,NULL);
/*!40000 ALTER TABLE `estimation_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimation_sections`
--

DROP TABLE IF EXISTS `estimation_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimation_sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `estimation_id` int NOT NULL,
  `heading` varchar(255) DEFAULT 'Main Panel',
  `parent_id` int DEFAULT NULL,
  `sort_order` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `section_name` varchar(255) DEFAULT 'Main Panel',
  `section_order` int DEFAULT '1',
  `is_editable` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `estimation_id` (`estimation_id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `estimation_sections_ibfk_1` FOREIGN KEY (`estimation_id`) REFERENCES `estimations` (`id`),
  CONSTRAINT `estimation_sections_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `estimation_sections` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimation_sections`
--

LOCK TABLES `estimation_sections` WRITE;
/*!40000 ALTER TABLE `estimation_sections` DISABLE KEYS */;
INSERT INTO `estimation_sections` (`id`, `estimation_id`, `heading`, `parent_id`, `sort_order`, `created_at`, `updated_at`, `section_name`, `section_order`, `is_editable`) VALUES (1,7,'Main Panel',NULL,NULL,'2025-09-12 10:37:49','2025-09-12 10:37:49','Main Panel',1,1),(2,7,'Main Panel',NULL,NULL,'2025-09-12 10:37:49','2025-09-12 10:37:49','Generator',2,1),(3,7,'Main Panel',NULL,NULL,'2025-09-12 10:37:49','2025-09-12 10:37:49','UPS',3,1),(4,7,'Main Panel',NULL,NULL,'2025-09-12 10:37:49','2025-09-12 10:37:49','Incoming',4,1),(5,7,'Main Panel',NULL,NULL,'2025-09-12 10:37:49','2025-09-12 10:37:49','Outgoing',5,1),(6,8,'Main Panel',NULL,NULL,'2025-09-12 10:39:42','2025-09-12 10:39:42','Main Panel',1,1),(19,9,'Incoming',NULL,NULL,'2025-09-12 12:12:22','2025-09-12 12:12:22','Incoming',1,1),(22,8,'Outgoing panel',NULL,NULL,'2025-09-12 13:32:06','2025-09-12 13:32:06','Outgoing panel',2,1),(58,17,'Main Panel',NULL,NULL,'2025-09-13 04:03:49','2025-09-13 04:03:49','Main Panel',1,1),(59,17,'Main Panel',NULL,NULL,'2025-09-13 04:03:49','2025-09-13 04:03:49','Generator',2,1),(60,17,'Main Panel',NULL,NULL,'2025-09-13 04:03:49','2025-09-13 04:03:49','UPS',3,1),(61,17,'Main Panel',NULL,NULL,'2025-09-13 04:03:49','2025-09-13 04:03:49','Incoming',4,1),(62,17,'Main Panel',NULL,NULL,'2025-09-13 04:03:49','2025-09-13 04:03:49','Outgoing',5,1),(63,18,'Main Panel',NULL,NULL,'2025-09-13 04:07:48','2025-09-13 04:07:48','Main Panel',1,1),(64,18,'Main Panel',NULL,NULL,'2025-09-13 04:07:48','2025-09-13 04:07:48','Generator',2,1),(65,18,'Main Panel',NULL,NULL,'2025-09-13 04:07:48','2025-09-13 04:07:48','UPS',3,1),(66,18,'Main Panel',NULL,NULL,'2025-09-13 04:07:48','2025-09-13 04:07:48','Incoming',4,1),(67,18,'Main Panel',NULL,NULL,'2025-09-13 04:07:48','2025-09-13 04:07:48','Outgoing',5,1);
/*!40000 ALTER TABLE `estimation_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimation_serial_allocations`
--

DROP TABLE IF EXISTS `estimation_serial_allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimation_serial_allocations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `estimation_id` int NOT NULL,
  `estimation_item_id` int NOT NULL,
  `product_id` int NOT NULL,
  `location_id` int DEFAULT NULL,
  `serial_number_id` int DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  `batch_id` int DEFAULT NULL,
  `unit_cost` decimal(12,4) DEFAULT NULL,
  `allocation_reason` enum('performance_requirement','warranty_requirement','client_specification','technical_compatibility','cost_optimization') NOT NULL,
  `technical_specification` text,
  `warranty_start_date` date DEFAULT NULL,
  `warranty_end_date` date DEFAULT NULL,
  `warranty_terms` text,
  `status` enum('tentative','reserved','confirmed','released') DEFAULT 'tentative',
  `allocated_by` int NOT NULL,
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `idx_estimation` (`estimation_id`),
  KEY `idx_estimation_item` (`estimation_item_id`),
  KEY `idx_serial_number` (`serial_number_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `estimation_serial_allocations_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimation_serial_allocations`
--

LOCK TABLES `estimation_serial_allocations` WRITE;
/*!40000 ALTER TABLE `estimation_serial_allocations` DISABLE KEYS */;
/*!40000 ALTER TABLE `estimation_serial_allocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimation_subsections`
--

DROP TABLE IF EXISTS `estimation_subsections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimation_subsections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `section_id` int NOT NULL,
  `subsection_name` varchar(255) NOT NULL DEFAULT 'General',
  `subsection_order` int DEFAULT '1',
  `is_editable` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `section_id` (`section_id`),
  CONSTRAINT `estimation_subsections_ibfk_1` FOREIGN KEY (`section_id`) REFERENCES `estimation_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimation_subsections`
--

LOCK TABLES `estimation_subsections` WRITE;
/*!40000 ALTER TABLE `estimation_subsections` DISABLE KEYS */;
INSERT INTO `estimation_subsections` (`id`, `section_id`, `subsection_name`, `subsection_order`, `is_editable`, `created_at`, `updated_at`) VALUES (13,1,'Updated Test Subsection',1,1,'2025-09-12 11:53:08','2025-09-12 11:53:22'),(18,19,'Panel-1',1,1,'2025-09-12 12:12:39','2025-09-12 12:12:39'),(21,6,'Panel -1',1,1,'2025-09-12 13:32:20','2025-09-12 13:32:20');
/*!40000 ALTER TABLE `estimation_subsections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estimations`
--

DROP TABLE IF EXISTS `estimations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estimations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `estimation_id` varchar(50) NOT NULL,
  `enquiry_id` int NOT NULL,
  `date` date NOT NULL,
  `status` enum('draft','submitted','approved','rejected') DEFAULT 'draft',
  `total_mrp` decimal(12,2) DEFAULT NULL,
  `total_discount` decimal(12,2) DEFAULT NULL,
  `total_final_price` decimal(12,2) DEFAULT NULL,
  `created_by` int NOT NULL,
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `case_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `estimation_id` (`estimation_id`),
  KEY `enquiry_id` (`enquiry_id`),
  KEY `created_by` (`created_by`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `estimations_ibfk_1` FOREIGN KEY (`enquiry_id`) REFERENCES `sales_enquiries` (`id`),
  CONSTRAINT `estimations_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `estimations_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estimations`
--

LOCK TABLES `estimations` WRITE;
/*!40000 ALTER TABLE `estimations` DISABLE KEYS */;
INSERT INTO `estimations` (`id`, `estimation_id`, `enquiry_id`, `date`, `status`, `total_mrp`, `total_discount`, `total_final_price`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `case_id`) VALUES (1,'VESPL/ES/2526/000',1,'2025-09-09','approved',NULL,NULL,NULL,1,1,'2025-09-11 12:12:53','2025-09-09 17:48:28','2025-09-11 12:12:53',NULL),(2,'VESPL/ES/2526/001',2,'2025-09-09','approved',NULL,NULL,NULL,1,1,'2025-09-10 18:36:50','2025-09-09 17:51:08','2025-09-10 18:36:50',NULL),(3,'VESPL/ET/2526/001',1,'2025-09-11','draft',NULL,NULL,NULL,1,NULL,NULL,'2025-09-11 13:55:02','2025-09-11 13:55:02',NULL),(4,'VESPL/ET/2526/002',2,'2025-09-11','draft',NULL,NULL,NULL,1,NULL,NULL,'2025-09-11 13:56:02','2025-09-11 13:56:02',NULL),(5,'VESPL/ET/2526/003',2,'2025-09-11','draft',NULL,NULL,NULL,1,NULL,NULL,'2025-09-11 15:03:25','2025-09-11 15:03:25',NULL),(6,'VESPL/ET/2526/004',2,'2025-09-11','draft',NULL,NULL,NULL,1,NULL,NULL,'2025-09-11 15:05:40','2025-09-11 15:05:40',NULL),(7,'VESPL/ET/2526/012',1,'2025-09-12','draft',NULL,NULL,NULL,1,NULL,NULL,'2025-09-12 10:37:49','2025-09-12 10:37:49',NULL),(8,'VESPL/ET/2526/013',1,'2025-09-12','draft',NULL,NULL,NULL,1,NULL,NULL,'2025-09-12 10:39:42','2025-09-12 10:39:42',NULL),(9,'VESPL/ET/2526/014',5,'2025-09-12','approved',NULL,NULL,NULL,1,1,'2025-09-12 16:43:13','2025-09-12 11:03:08','2025-09-12 16:43:13',NULL),(17,'VESPL/ET/2526/022',17,'2025-09-13','draft',NULL,NULL,NULL,1,NULL,NULL,'2025-09-13 04:03:49','2025-09-13 04:03:49',14),(18,'VESPL/ET/2526/023',17,'2025-09-13','draft',NULL,NULL,NULL,1,NULL,NULL,'2025-09-13 04:07:48','2025-09-13 04:07:48',14);
/*!40000 ALTER TABLE `estimations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goods_received_notes`
--

DROP TABLE IF EXISTS `goods_received_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `goods_received_notes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `grn_number` varchar(50) NOT NULL,
  `purchase_order_id` int NOT NULL,
  `supplier_id` int NOT NULL,
  `grn_date` date NOT NULL,
  `lr_number` varchar(100) DEFAULT NULL,
  `supplier_invoice_number` varchar(100) DEFAULT NULL,
  `supplier_invoice_date` date DEFAULT NULL,
  `total_amount` decimal(12,2) DEFAULT NULL,
  `status` enum('draft','verified','approved','rejected') DEFAULT 'draft',
  `notes` text,
  `received_by` int DEFAULT NULL,
  `verified_by` int DEFAULT NULL,
  `approved_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `grn_number` (`grn_number`),
  KEY `purchase_order_id` (`purchase_order_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `received_by` (`received_by`),
  KEY `verified_by` (`verified_by`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `goods_received_notes_ibfk_1` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`),
  CONSTRAINT `goods_received_notes_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `goods_received_notes_ibfk_3` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`),
  CONSTRAINT `goods_received_notes_ibfk_4` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`),
  CONSTRAINT `goods_received_notes_ibfk_5` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_received_notes`
--

LOCK TABLES `goods_received_notes` WRITE;
/*!40000 ALTER TABLE `goods_received_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `goods_received_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grn_items`
--

DROP TABLE IF EXISTS `grn_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grn_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `grn_id` int NOT NULL,
  `product_id` int NOT NULL,
  `ordered_quantity` int NOT NULL,
  `received_quantity` int NOT NULL,
  `accepted_quantity` int NOT NULL,
  `rejected_quantity` int DEFAULT '0',
  `unit_price` decimal(12,2) DEFAULT NULL,
  `serial_numbers` text,
  `warranty_start_date` date DEFAULT NULL,
  `warranty_end_date` date DEFAULT NULL,
  `location_id` int DEFAULT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `grn_id` (`grn_id`),
  KEY `product_id` (`product_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `grn_items_ibfk_1` FOREIGN KEY (`grn_id`) REFERENCES `goods_received_notes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `grn_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `grn_items_ibfk_3` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grn_items`
--

LOCK TABLES `grn_items` WRITE;
/*!40000 ALTER TABLE `grn_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `grn_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gst_rates`
--

DROP TABLE IF EXISTS `gst_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gst_rates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hsn_code` varchar(20) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `cgst_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `sgst_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `igst_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `cess_rate` decimal(5,2) DEFAULT '0.00',
  `total_gst_rate` decimal(5,2) GENERATED ALWAYS AS ((((`cgst_rate` + `sgst_rate`) + `igst_rate`) + `cess_rate`)) STORED,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_hsn_date` (`hsn_code`,`effective_from`),
  KEY `idx_hsn_code` (`hsn_code`),
  KEY `idx_effective_date` (`effective_from`,`effective_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gst_rates`
--

LOCK TABLES `gst_rates` WRITE;
/*!40000 ALTER TABLE `gst_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `gst_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gst_returns`
--

DROP TABLE IF EXISTS `gst_returns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gst_returns` (
  `id` int NOT NULL AUTO_INCREMENT,
  `return_type` enum('GSTR1','GSTR3B','GSTR2A','GSTR9') NOT NULL,
  `return_period` varchar(7) NOT NULL,
  `filing_frequency` enum('monthly','quarterly','annually') NOT NULL,
  `total_taxable_value` decimal(15,4) DEFAULT '0.0000',
  `total_cgst` decimal(15,4) DEFAULT '0.0000',
  `total_sgst` decimal(15,4) DEFAULT '0.0000',
  `total_igst` decimal(15,4) DEFAULT '0.0000',
  `total_cess` decimal(15,4) DEFAULT '0.0000',
  `total_tax_amount` decimal(15,4) GENERATED ALWAYS AS ((((`total_cgst` + `total_sgst`) + `total_igst`) + `total_cess`)) STORED,
  `status` enum('draft','prepared','filed','accepted','rejected') DEFAULT 'draft',
  `prepared_date` date DEFAULT NULL,
  `filed_date` date DEFAULT NULL,
  `accepted_date` date DEFAULT NULL,
  `arn` varchar(50) DEFAULT NULL,
  `json_data` json DEFAULT NULL,
  `prepared_by` int DEFAULT NULL,
  `filed_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_return_period` (`return_type`,`return_period`),
  KEY `prepared_by` (`prepared_by`),
  KEY `filed_by` (`filed_by`),
  KEY `idx_return_type` (`return_type`),
  KEY `idx_return_period` (`return_period`),
  KEY `idx_status` (`status`),
  CONSTRAINT `gst_returns_ibfk_1` FOREIGN KEY (`prepared_by`) REFERENCES `users` (`id`),
  CONSTRAINT `gst_returns_ibfk_2` FOREIGN KEY (`filed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gst_returns`
--

LOCK TABLES `gst_returns` WRITE;
/*!40000 ALTER TABLE `gst_returns` DISABLE KEYS */;
/*!40000 ALTER TABLE `gst_returns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inter_store_transfer_items`
--

DROP TABLE IF EXISTS `inter_store_transfer_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inter_store_transfer_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transfer_id` int NOT NULL,
  `product_id` int NOT NULL,
  `requested_quantity` decimal(15,3) NOT NULL,
  `approved_quantity` decimal(15,3) DEFAULT NULL,
  `shipped_quantity` decimal(15,3) DEFAULT NULL,
  `received_quantity` decimal(15,3) DEFAULT NULL,
  `unit_cost` decimal(12,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `transfer_id` (`transfer_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `inter_store_transfer_items_ibfk_1` FOREIGN KEY (`transfer_id`) REFERENCES `inter_store_transfers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inter_store_transfer_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inter_store_transfer_items`
--

LOCK TABLES `inter_store_transfer_items` WRITE;
/*!40000 ALTER TABLE `inter_store_transfer_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `inter_store_transfer_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inter_store_transfers`
--

DROP TABLE IF EXISTS `inter_store_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inter_store_transfers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transfer_number` varchar(50) NOT NULL,
  `from_location_id` int NOT NULL,
  `to_location_id` int NOT NULL,
  `status` enum('pending','approved','in_transit','received','cancelled') DEFAULT 'pending',
  `reason` text,
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `requested_by` int NOT NULL,
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `shipped_by` int DEFAULT NULL,
  `shipped_at` timestamp NULL DEFAULT NULL,
  `received_by` int DEFAULT NULL,
  `received_at` timestamp NULL DEFAULT NULL,
  `requested_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transfer_number` (`transfer_number`),
  KEY `from_location_id` (`from_location_id`),
  KEY `to_location_id` (`to_location_id`),
  KEY `requested_by` (`requested_by`),
  KEY `approved_by` (`approved_by`),
  KEY `shipped_by` (`shipped_by`),
  KEY `received_by` (`received_by`),
  CONSTRAINT `inter_store_transfers_ibfk_1` FOREIGN KEY (`from_location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `inter_store_transfers_ibfk_2` FOREIGN KEY (`to_location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `inter_store_transfers_ibfk_3` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`),
  CONSTRAINT `inter_store_transfers_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`),
  CONSTRAINT `inter_store_transfers_ibfk_5` FOREIGN KEY (`shipped_by`) REFERENCES `users` (`id`),
  CONSTRAINT `inter_store_transfers_ibfk_6` FOREIGN KEY (`received_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inter_store_transfers`
--

LOCK TABLES `inter_store_transfers` WRITE;
/*!40000 ALTER TABLE `inter_store_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `inter_store_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_allocations`
--

DROP TABLE IF EXISTS `inventory_allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_allocations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `allocation_type` enum('estimation','sales_order','manufacturing_order','manual') NOT NULL,
  `reference_id` int NOT NULL,
  `reference_line_id` int DEFAULT NULL,
  `product_id` int NOT NULL,
  `batch_id` int NOT NULL,
  `location_id` int NOT NULL,
  `allocated_quantity` decimal(10,4) NOT NULL,
  `unit_price` decimal(12,4) NOT NULL,
  `total_cost` decimal(15,4) GENERATED ALWAYS AS ((`allocated_quantity` * `unit_price`)) STORED,
  `serial_numbers` json DEFAULT NULL,
  `status` enum('reserved','consumed','released') DEFAULT 'reserved',
  `allocated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `consumed_at` timestamp NULL DEFAULT NULL,
  `released_at` timestamp NULL DEFAULT NULL,
  `allocated_by` int DEFAULT NULL,
  `consumed_by` int DEFAULT NULL,
  `released_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `batch_id` (`batch_id`),
  KEY `location_id` (`location_id`),
  KEY `allocated_by` (`allocated_by`),
  KEY `consumed_by` (`consumed_by`),
  KEY `released_by` (`released_by`),
  KEY `idx_allocation_type_ref` (`allocation_type`,`reference_id`),
  KEY `idx_product_batch` (`product_id`,`batch_id`),
  KEY `idx_status` (`status`),
  KEY `idx_allocated_at` (`allocated_at`),
  CONSTRAINT `inventory_allocations_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `inventory_allocations_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `inventory_batches` (`id`),
  CONSTRAINT `inventory_allocations_ibfk_3` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `inventory_allocations_ibfk_4` FOREIGN KEY (`allocated_by`) REFERENCES `users` (`id`),
  CONSTRAINT `inventory_allocations_ibfk_5` FOREIGN KEY (`consumed_by`) REFERENCES `users` (`id`),
  CONSTRAINT `inventory_allocations_ibfk_6` FOREIGN KEY (`released_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_allocations`
--

LOCK TABLES `inventory_allocations` WRITE;
/*!40000 ALTER TABLE `inventory_allocations` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_allocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_batches`
--

DROP TABLE IF EXISTS `inventory_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_batches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `batch_number` varchar(100) NOT NULL,
  `product_id` int NOT NULL,
  `location_id` int NOT NULL,
  `supplier_id` int DEFAULT NULL,
  `grn_id` int DEFAULT NULL,
  `purchase_date` date NOT NULL,
  `purchase_price` decimal(12,4) NOT NULL,
  `received_quantity` decimal(10,4) NOT NULL,
  `consumed_quantity` decimal(10,4) DEFAULT '0.0000',
  `damaged_quantity` decimal(10,4) DEFAULT '0.0000',
  `available_quantity` decimal(10,4) GENERATED ALWAYS AS (((`received_quantity` - `consumed_quantity`) - `damaged_quantity`)) STORED,
  `manufacturing_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `lot_number` varchar(100) DEFAULT NULL,
  `status` enum('active','consumed','expired','damaged') DEFAULT 'active',
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `grn_id` (`grn_id`),
  KEY `created_by` (`created_by`),
  KEY `idx_product_location` (`product_id`,`location_id`),
  KEY `idx_batch_number` (`batch_number`),
  KEY `idx_purchase_date` (`purchase_date`),
  KEY `idx_expiry_date` (`expiry_date`),
  KEY `idx_available_qty` (`available_quantity`),
  KEY `idx_status` (`status`),
  CONSTRAINT `inventory_batches_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `inventory_batches_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `inventory_batches_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `inventory_batches_ibfk_4` FOREIGN KEY (`grn_id`) REFERENCES `goods_received_notes` (`id`),
  CONSTRAINT `inventory_batches_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_batches`
--

LOCK TABLES `inventory_batches` WRITE;
/*!40000 ALTER TABLE `inventory_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_categories`
--

DROP TABLE IF EXISTS `inventory_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_code` varchar(20) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `description` text,
  `parent_category_id` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_code` (`category_code`),
  KEY `parent_category_id` (`parent_category_id`),
  CONSTRAINT `inventory_categories_ibfk_1` FOREIGN KEY (`parent_category_id`) REFERENCES `inventory_categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_categories`
--

LOCK TABLES `inventory_categories` WRITE;
/*!40000 ALTER TABLE `inventory_categories` DISABLE KEYS */;
INSERT INTO `inventory_categories` (`id`, `category_code`, `category_name`, `description`, `parent_category_id`, `is_active`, `created_at`, `updated_at`) VALUES (1,'RAW','Raw Materials','Basic materials used in manufacturing',NULL,1,'2025-09-09 18:31:38','2025-09-09 18:31:38'),(2,'COMP','Components','Manufactured or purchased components',NULL,1,'2025-09-09 18:31:38','2025-09-09 18:31:38'),(3,'ELEC','Electronics','Electronic components and devices',NULL,1,'2025-09-09 18:31:38','2025-09-09 18:31:38'),(4,'MECH','Mechanical','Mechanical parts and assemblies',NULL,1,'2025-09-09 18:31:38','2025-09-09 18:31:38'),(5,'TOOL','Tools & Equipment','Manufacturing tools and equipment',NULL,1,'2025-09-09 18:31:38','2025-09-09 18:31:38'),(6,'CONS','Consumables','Consumable items like welding rods, lubricants',NULL,1,'2025-09-09 18:31:38','2025-09-09 18:31:38'),(7,'PACK','Packaging','Packaging materials',NULL,1,'2025-09-09 18:31:38','2025-09-09 18:31:38'),(8,'FINI','Finished Products','Completed products ready for sale',NULL,1,'2025-09-09 18:31:38','2025-09-09 18:31:38');
/*!40000 ALTER TABLE `inventory_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_item_vendors`
--

DROP TABLE IF EXISTS `inventory_item_vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_item_vendors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `item_id` int NOT NULL,
  `vendor_id` int NOT NULL,
  `vendor_item_code` varchar(100) DEFAULT NULL,
  `vendor_item_name` varchar(200) DEFAULT NULL,
  `lead_time_days` int DEFAULT '0',
  `minimum_order_quantity` decimal(15,3) DEFAULT '0.000',
  `unit_cost` decimal(12,2) DEFAULT '0.00',
  `currency` varchar(3) DEFAULT 'INR',
  `is_preferred` tinyint(1) DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `effective_from` date DEFAULT NULL,
  `effective_to` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_item_vendor` (`item_id`,`vendor_id`),
  KEY `idx_vendor_items` (`vendor_id`,`is_active`),
  KEY `idx_preferred_vendor` (`item_id`,`is_preferred`),
  CONSTRAINT `inventory_item_vendors_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `inventory_items` (`id`),
  CONSTRAINT `inventory_item_vendors_ibfk_2` FOREIGN KEY (`vendor_id`) REFERENCES `inventory_vendors` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_item_vendors`
--

LOCK TABLES `inventory_item_vendors` WRITE;
/*!40000 ALTER TABLE `inventory_item_vendors` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_item_vendors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_items`
--

DROP TABLE IF EXISTS `inventory_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `item_code` varchar(50) NOT NULL,
  `item_name` varchar(200) NOT NULL,
  `description` text,
  `category_id` int DEFAULT NULL,
  `unit_id` int DEFAULT NULL,
  `item_type` enum('raw_material','component','finished_product','consumable','tool') NOT NULL,
  `current_stock` decimal(15,3) DEFAULT '0.000',
  `reserved_stock` decimal(15,3) DEFAULT '0.000',
  `available_stock` decimal(15,3) GENERATED ALWAYS AS ((`current_stock` - `reserved_stock`)) STORED,
  `minimum_stock` decimal(15,3) DEFAULT '0.000',
  `maximum_stock` decimal(15,3) DEFAULT NULL,
  `reorder_point` decimal(15,3) DEFAULT '0.000',
  `reorder_quantity` decimal(15,3) DEFAULT '0.000',
  `standard_cost` decimal(12,2) DEFAULT '0.00',
  `average_cost` decimal(12,2) DEFAULT '0.00',
  `last_purchase_cost` decimal(12,2) DEFAULT '0.00',
  `weight_per_unit` decimal(10,3) DEFAULT NULL,
  `dimensions_length` decimal(10,2) DEFAULT NULL,
  `dimensions_width` decimal(10,2) DEFAULT NULL,
  `dimensions_height` decimal(10,2) DEFAULT NULL,
  `track_serial_numbers` tinyint(1) DEFAULT '0',
  `track_batch_numbers` tinyint(1) DEFAULT '0',
  `track_expiry_dates` tinyint(1) DEFAULT '0',
  `storage_location` varchar(100) DEFAULT NULL,
  `storage_conditions` text,
  `shelf_life_days` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `is_discontinued` tinyint(1) DEFAULT '0',
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_code` (`item_code`),
  KEY `unit_id` (`unit_id`),
  KEY `created_by` (`created_by`),
  KEY `idx_item_code` (`item_code`),
  KEY `idx_item_type` (`item_type`),
  KEY `idx_category` (`category_id`),
  KEY `idx_reorder` (`reorder_point`,`current_stock`),
  CONSTRAINT `inventory_items_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `inventory_categories` (`id`),
  CONSTRAINT `inventory_items_ibfk_2` FOREIGN KEY (`unit_id`) REFERENCES `inventory_units` (`id`),
  CONSTRAINT `inventory_items_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_items`
--

LOCK TABLES `inventory_items` WRITE;
/*!40000 ALTER TABLE `inventory_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_reservations`
--

DROP TABLE IF EXISTS `inventory_reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_reservations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reservation_type` enum('estimation','quotation','sales_order') NOT NULL,
  `reference_id` int NOT NULL,
  `reference_line_id` int DEFAULT NULL,
  `product_id` int NOT NULL,
  `location_id` int NOT NULL,
  `reserved_quantity` decimal(10,4) NOT NULL,
  `pricing_method` enum('current_cost','average_cost','fifo','lifo','specific_batch') NOT NULL DEFAULT 'fifo',
  `specific_batch_id` int DEFAULT NULL,
  `estimated_unit_cost` decimal(12,4) DEFAULT NULL,
  `status` enum('active','allocated','expired','cancelled') DEFAULT 'active',
  `reserved_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` timestamp NULL DEFAULT NULL,
  `reserved_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`),
  KEY `specific_batch_id` (`specific_batch_id`),
  KEY `reserved_by` (`reserved_by`),
  KEY `idx_reservation_type_ref` (`reservation_type`,`reference_id`),
  KEY `idx_product_location` (`product_id`,`location_id`),
  KEY `idx_expires_at` (`expires_at`),
  KEY `idx_status` (`status`),
  CONSTRAINT `inventory_reservations_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `inventory_reservations_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `inventory_reservations_ibfk_3` FOREIGN KEY (`specific_batch_id`) REFERENCES `inventory_batches` (`id`),
  CONSTRAINT `inventory_reservations_ibfk_4` FOREIGN KEY (`reserved_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_reservations`
--

LOCK TABLES `inventory_reservations` WRITE;
/*!40000 ALTER TABLE `inventory_reservations` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_serial_numbers`
--

DROP TABLE IF EXISTS `inventory_serial_numbers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_serial_numbers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `serial_number` varchar(255) NOT NULL,
  `product_id` int NOT NULL,
  `location_id` int DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `warranty_start_date` date DEFAULT NULL,
  `warranty_end_date` date DEFAULT NULL,
  `warranty_status` enum('active','expired','void') DEFAULT 'active',
  `condition_status` enum('new','used','refurbished','damaged') DEFAULT 'new',
  `status` enum('available','reserved','allocated','sold','returned') DEFAULT 'available',
  `reserved_for` enum('estimation','quotation','sales_order') DEFAULT NULL,
  `reserved_for_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_serial_product` (`serial_number`,`product_id`),
  KEY `idx_serial_number` (`serial_number`),
  KEY `idx_product_status` (`product_id`,`status`),
  KEY `idx_warranty_status` (`warranty_status`),
  CONSTRAINT `inventory_serial_numbers_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_serial_numbers`
--

LOCK TABLES `inventory_serial_numbers` WRITE;
/*!40000 ALTER TABLE `inventory_serial_numbers` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_serial_numbers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_transactions`
--

DROP TABLE IF EXISTS `inventory_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaction_code` varchar(50) NOT NULL,
  `item_id` int NOT NULL,
  `transaction_type` enum('purchase_receipt','sales_issue','production_issue','production_receipt','stock_transfer','stock_adjustment','return_receipt','return_issue','opening_stock','physical_count') NOT NULL,
  `reference_type` enum('purchase_order','sales_order','work_order','stock_transfer','adjustment','manual') NOT NULL,
  `reference_id` int DEFAULT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `quantity` decimal(15,3) NOT NULL,
  `unit_cost` decimal(12,2) DEFAULT '0.00',
  `total_value` decimal(15,2) GENERATED ALWAYS AS ((`quantity` * `unit_cost`)) STORED,
  `stock_before` decimal(15,3) NOT NULL,
  `stock_after` decimal(15,3) NOT NULL,
  `batch_number` varchar(100) DEFAULT NULL,
  `serial_number` varchar(100) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `from_location` varchar(100) DEFAULT NULL,
  `to_location` varchar(100) DEFAULT NULL,
  `warehouse_location` varchar(100) DEFAULT NULL,
  `status` enum('pending','approved','rejected','cancelled') DEFAULT 'pending',
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `remarks` text,
  `created_by` int DEFAULT NULL,
  `transaction_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_code` (`transaction_code`),
  KEY `approved_by` (`approved_by`),
  KEY `created_by` (`created_by`),
  KEY `idx_transaction_code` (`transaction_code`),
  KEY `idx_item_date` (`item_id`,`transaction_date`),
  KEY `idx_transaction_type` (`transaction_type`),
  KEY `idx_reference` (`reference_type`,`reference_id`),
  KEY `idx_batch_serial` (`batch_number`,`serial_number`),
  CONSTRAINT `inventory_transactions_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `inventory_items` (`id`),
  CONSTRAINT `inventory_transactions_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`),
  CONSTRAINT `inventory_transactions_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_transactions`
--

LOCK TABLES `inventory_transactions` WRITE;
/*!40000 ALTER TABLE `inventory_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_units`
--

DROP TABLE IF EXISTS `inventory_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_units` (
  `id` int NOT NULL AUTO_INCREMENT,
  `unit_code` varchar(10) NOT NULL,
  `unit_name` varchar(50) NOT NULL,
  `unit_type` enum('weight','length','volume','quantity','area','time') NOT NULL,
  `base_unit_conversion` decimal(15,6) DEFAULT '1.000000',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unit_code` (`unit_code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_units`
--

LOCK TABLES `inventory_units` WRITE;
/*!40000 ALTER TABLE `inventory_units` DISABLE KEYS */;
INSERT INTO `inventory_units` (`id`, `unit_code`, `unit_name`, `unit_type`, `base_unit_conversion`, `is_active`, `created_at`) VALUES (1,'PCS','Pieces','quantity',1.000000,1,'2025-09-09 18:31:38'),(2,'KG','Kilograms','weight',1.000000,1,'2025-09-09 18:31:38'),(3,'LTR','Liters','volume',1.000000,1,'2025-09-09 18:31:38'),(4,'MTR','Meters','length',1.000000,1,'2025-09-09 18:31:38'),(5,'SQM','Square Meters','area',1.000000,1,'2025-09-09 18:31:38'),(6,'SET','Set','quantity',1.000000,1,'2025-09-09 18:31:38'),(7,'BOX','Box','quantity',1.000000,1,'2025-09-09 18:31:38'),(8,'ROLL','Roll','quantity',1.000000,1,'2025-09-09 18:31:38'),(9,'SHEET','Sheet','quantity',1.000000,1,'2025-09-09 18:31:38'),(10,'PAIR','Pair','quantity',1.000000,1,'2025-09-09 18:31:38');
/*!40000 ALTER TABLE `inventory_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_vendors`
--

DROP TABLE IF EXISTS `inventory_vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_vendors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `vendor_code` varchar(20) NOT NULL,
  `vendor_name` varchar(200) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text,
  `payment_terms` varchar(100) DEFAULT NULL,
  `credit_limit` decimal(15,2) DEFAULT '0.00',
  `rating` enum('A','B','C','D') DEFAULT 'B',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vendor_code` (`vendor_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_vendors`
--

LOCK TABLES `inventory_vendors` WRITE;
/*!40000 ALTER TABLE `inventory_vendors` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_vendors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_warehouse_stock`
--

DROP TABLE IF EXISTS `inventory_warehouse_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_warehouse_stock` (
  `id` int NOT NULL AUTO_INCREMENT,
  `item_id` int NOT NULL,
  `warehouse_id` int NOT NULL,
  `current_stock` decimal(15,3) DEFAULT '0.000',
  `reserved_stock` decimal(15,3) DEFAULT '0.000',
  `available_stock` decimal(15,3) GENERATED ALWAYS AS ((`current_stock` - `reserved_stock`)) STORED,
  `last_counted_date` date DEFAULT NULL,
  `last_counted_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_item_warehouse` (`item_id`,`warehouse_id`),
  KEY `warehouse_id` (`warehouse_id`),
  KEY `last_counted_by` (`last_counted_by`),
  KEY `idx_item_warehouse` (`item_id`,`warehouse_id`),
  CONSTRAINT `inventory_warehouse_stock_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `inventory_items` (`id`),
  CONSTRAINT `inventory_warehouse_stock_ibfk_2` FOREIGN KEY (`warehouse_id`) REFERENCES `inventory_warehouses` (`id`),
  CONSTRAINT `inventory_warehouse_stock_ibfk_3` FOREIGN KEY (`last_counted_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_warehouse_stock`
--

LOCK TABLES `inventory_warehouse_stock` WRITE;
/*!40000 ALTER TABLE `inventory_warehouse_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_warehouse_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_warehouses`
--

DROP TABLE IF EXISTS `inventory_warehouses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_warehouses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `warehouse_code` varchar(20) NOT NULL,
  `warehouse_name` varchar(100) NOT NULL,
  `location_id` int DEFAULT NULL,
  `address` text,
  `manager_name` varchar(100) DEFAULT NULL,
  `contact_phone` varchar(20) DEFAULT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `warehouse_code` (`warehouse_code`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `inventory_warehouses_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_warehouses`
--

LOCK TABLES `inventory_warehouses` WRITE;
/*!40000 ALTER TABLE `inventory_warehouses` DISABLE KEYS */;
INSERT INTO `inventory_warehouses` (`id`, `warehouse_code`, `warehouse_name`, `location_id`, `address`, `manager_name`, `contact_phone`, `contact_email`, `is_active`, `created_at`, `updated_at`) VALUES (1,'WH001','Main Warehouse',1,'VTRIA Industrial Complex, Bangalore','Warehouse Manager',NULL,NULL,1,'2025-09-09 18:31:38','2025-09-13 10:43:35');
/*!40000 ALTER TABLE `inventory_warehouses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_items`
--

DROP TABLE IF EXISTS `invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `product_id` int DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_code` varchar(100) DEFAULT NULL,
  `description` text,
  `hsn_code` varchar(20) DEFAULT NULL,
  `quantity` decimal(10,4) NOT NULL,
  `unit` varchar(50) DEFAULT 'Nos',
  `unit_price` decimal(12,4) NOT NULL,
  `total_price` decimal(15,4) GENERATED ALWAYS AS ((`quantity` * `unit_price`)) STORED,
  `item_discount_percentage` decimal(5,2) DEFAULT '0.00',
  `item_discount_amount` decimal(15,4) DEFAULT '0.0000',
  `discounted_amount` decimal(15,4) GENERATED ALWAYS AS ((`total_price` - `item_discount_amount`)) STORED,
  `gst_rate` decimal(5,2) DEFAULT '0.00',
  `cgst_rate` decimal(5,2) DEFAULT '0.00',
  `cgst_amount` decimal(15,4) DEFAULT '0.0000',
  `sgst_rate` decimal(5,2) DEFAULT '0.00',
  `sgst_amount` decimal(15,4) DEFAULT '0.0000',
  `igst_rate` decimal(5,2) DEFAULT '0.00',
  `igst_amount` decimal(15,4) DEFAULT '0.0000',
  `cess_rate` decimal(5,2) DEFAULT '0.00',
  `cess_amount` decimal(15,4) DEFAULT '0.0000',
  `serial_numbers` json DEFAULT NULL,
  `inventory_allocated` tinyint(1) DEFAULT '0',
  `batch_allocations` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_invoice_item` (`invoice_id`),
  KEY `idx_product` (`product_id`),
  KEY `idx_hsn_code` (`hsn_code`),
  CONSTRAINT `invoice_items_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoice_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_items`
--

LOCK TABLES `invoice_items` WRITE;
/*!40000 ALTER TABLE `invoice_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(100) NOT NULL,
  `invoice_type` enum('sales','proforma','credit_note','debit_note') DEFAULT 'sales',
  `invoice_date` date NOT NULL,
  `due_date` date NOT NULL,
  `customer_id` int NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_address` text,
  `customer_gstin` varchar(15) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `customer_email` varchar(255) DEFAULT NULL,
  `reference_type` enum('sales_order','quotation','manual') NOT NULL,
  `reference_id` int DEFAULT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `subtotal` decimal(15,4) NOT NULL DEFAULT '0.0000',
  `discount_amount` decimal(15,4) DEFAULT '0.0000',
  `discount_percentage` decimal(5,2) DEFAULT '0.00',
  `cgst_rate` decimal(5,2) DEFAULT '0.00',
  `cgst_amount` decimal(15,4) DEFAULT '0.0000',
  `sgst_rate` decimal(5,2) DEFAULT '0.00',
  `sgst_amount` decimal(15,4) DEFAULT '0.0000',
  `igst_rate` decimal(5,2) DEFAULT '0.00',
  `igst_amount` decimal(15,4) DEFAULT '0.0000',
  `cess_rate` decimal(5,2) DEFAULT '0.00',
  `cess_amount` decimal(15,4) DEFAULT '0.0000',
  `total_tax_amount` decimal(15,4) GENERATED ALWAYS AS ((((`cgst_amount` + `sgst_amount`) + `igst_amount`) + `cess_amount`)) STORED,
  `total_amount` decimal(15,4) GENERATED ALWAYS AS ((((((`subtotal` - `discount_amount`) + `cgst_amount`) + `sgst_amount`) + `igst_amount`) + `cess_amount`)) STORED,
  `payment_terms` varchar(255) DEFAULT 'Net 30',
  `payment_status` enum('unpaid','partial','paid','overdue','cancelled') DEFAULT 'unpaid',
  `paid_amount` decimal(15,4) DEFAULT '0.0000',
  `balance_amount` decimal(15,4) GENERATED ALWAYS AS (((((((`subtotal` - `discount_amount`) + `cgst_amount`) + `sgst_amount`) + `igst_amount`) + `cess_amount`) - `paid_amount`)) STORED,
  `notes` text,
  `terms_conditions` text,
  `bank_details` text,
  `irn` varchar(64) DEFAULT NULL,
  `ack_no` varchar(20) DEFAULT NULL,
  `ack_date` datetime DEFAULT NULL,
  `qr_code_image` text,
  `status` enum('draft','sent','viewed','paid','overdue','cancelled') DEFAULT 'draft',
  `sent_date` datetime DEFAULT NULL,
  `viewed_date` datetime DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `idx_invoice_number` (`invoice_number`),
  KEY `idx_customer` (`customer_id`),
  KEY `idx_invoice_date` (`invoice_date`),
  KEY `idx_due_date` (`due_date`),
  KEY `idx_payment_status` (`payment_status`),
  KEY `idx_status` (`status`),
  KEY `idx_reference` (`reference_type`,`reference_id`),
  CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `invoices_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `invoices_ibfk_3` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `contact_number` varchar(50) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` (`id`, `name`, `city`, `state`, `address`, `contact_person`, `contact_number`, `status`, `created_at`, `updated_at`) VALUES (1,'Main Warehouse','Mumbai','Maharashtra','123 Industrial Area',NULL,NULL,'active','2025-09-11 14:59:59','2025-09-11 14:59:59');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manufacturing_units`
--

DROP TABLE IF EXISTS `manufacturing_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `manufacturing_units` (
  `id` int NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(100) NOT NULL,
  `unit_code` varchar(10) NOT NULL,
  `location` varchar(200) DEFAULT NULL,
  `capacity_per_day` decimal(10,2) DEFAULT NULL,
  `unit_of_measurement` varchar(20) DEFAULT NULL,
  `status` enum('active','inactive','maintenance') DEFAULT 'active',
  `manager_employee_id` int DEFAULT NULL,
  `contact_phone` varchar(15) DEFAULT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unit_code` (`unit_code`),
  KEY `idx_unit_code` (`unit_code`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manufacturing_units`
--

LOCK TABLES `manufacturing_units` WRITE;
/*!40000 ALTER TABLE `manufacturing_units` DISABLE KEYS */;
INSERT INTO `manufacturing_units` (`id`, `unit_name`, `unit_code`, `location`, `capacity_per_day`, `unit_of_measurement`, `status`, `manager_employee_id`, `contact_phone`, `contact_email`, `created_at`, `updated_at`, `created_by`) VALUES (1,'Main Production Unit','MPU','Floor 1, Main Building',100.00,'PCS','active',NULL,NULL,NULL,'2025-09-12 06:08:22','2025-09-12 06:08:22',NULL),(2,'Assembly Unit','ASU','Floor 2, Main Building',50.00,'PCS','active',NULL,NULL,NULL,'2025-09-12 06:08:22','2025-09-12 06:08:22',NULL),(3,'Testing & QC Unit','QCU','Floor 1, Quality Building',200.00,'PCS','active',NULL,NULL,NULL,'2025-09-12 06:08:22','2025-09-12 06:08:22',NULL),(4,'Packaging Unit','PKU','Ground Floor, Warehouse',500.00,'PCS','active',NULL,NULL,NULL,'2025-09-12 06:08:22','2025-09-12 06:08:22',NULL);
/*!40000 ALTER TABLE `manufacturing_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `material_usage`
--

DROP TABLE IF EXISTS `material_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_usage` (
  `id` int NOT NULL AUTO_INCREMENT,
  `work_order_id` int NOT NULL,
  `product_id` int DEFAULT NULL,
  `material_name` varchar(255) NOT NULL,
  `required_quantity` decimal(10,2) NOT NULL,
  `used_quantity` decimal(10,2) DEFAULT '0.00',
  `unit` varchar(50) NOT NULL,
  `status` enum('required','issued','consumed','returned','shortage') DEFAULT 'required',
  `issue_date` date DEFAULT NULL,
  `consumed_date` date DEFAULT NULL,
  `issued_by` int DEFAULT NULL,
  `consumed_by` int DEFAULT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `issued_by` (`issued_by`),
  KEY `consumed_by` (`consumed_by`),
  KEY `idx_work_order_id` (`work_order_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `material_usage_ibfk_1` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `material_usage_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `material_usage_ibfk_3` FOREIGN KEY (`issued_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `material_usage_ibfk_4` FOREIGN KEY (`consumed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_usage`
--

LOCK TABLES `material_usage` WRITE;
/*!40000 ALTER TABLE `material_usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `material_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `milestone_activities`
--

DROP TABLE IF EXISTS `milestone_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `milestone_activities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `milestone_id` int NOT NULL,
  `activity_type` enum('status_change','progress_update','comment','file_upload','approval_request','approval_given','escalation','client_interaction') NOT NULL,
  `activity_description` text NOT NULL,
  `old_value` varchar(255) DEFAULT NULL,
  `new_value` varchar(255) DEFAULT NULL,
  `progress_percentage` decimal(5,2) DEFAULT NULL,
  `attachment_path` varchar(500) DEFAULT NULL,
  `client_visible` tinyint(1) DEFAULT '0',
  `performed_by` int NOT NULL,
  `client_notified` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `performed_by` (`performed_by`),
  KEY `idx_milestone_id` (`milestone_id`),
  KEY `idx_activity_type` (`activity_type`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_client_visible` (`client_visible`),
  CONSTRAINT `milestone_activities_ibfk_1` FOREIGN KEY (`milestone_id`) REFERENCES `case_milestones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `milestone_activities_ibfk_2` FOREIGN KEY (`performed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Activity log for milestone tracking and client visibility';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `milestone_activities`
--

LOCK TABLES `milestone_activities` WRITE;
/*!40000 ALTER TABLE `milestone_activities` DISABLE KEYS */;
INSERT INTO `milestone_activities` (`id`, `milestone_id`, `activity_type`, `activity_description`, `old_value`, `new_value`, `progress_percentage`, `attachment_path`, `client_visible`, `performed_by`, `client_notified`, `created_at`) VALUES (1,1,'progress_update','Project planning meeting completed with client. Requirements documented.',NULL,NULL,25.00,NULL,1,1,0,'2025-09-13 02:07:07');
/*!40000 ALTER TABLE `milestone_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `milestone_templates`
--

DROP TABLE IF EXISTS `milestone_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `milestone_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `template_id` int NOT NULL,
  `milestone_name` varchar(100) NOT NULL,
  `sequence_order` int NOT NULL,
  `milestone_type` enum('planning','approval','execution','review','delivery','payment') NOT NULL,
  `is_critical_path` tinyint(1) DEFAULT '0',
  `is_client_milestone` tinyint(1) DEFAULT '0',
  `requires_client_approval` tinyint(1) DEFAULT '0',
  `start_offset_days` int DEFAULT '0' COMMENT 'Days from project start',
  `duration_days` int NOT NULL DEFAULT '1',
  `buffer_days` int DEFAULT '0' COMMENT 'Buffer time for this milestone',
  `depends_on_milestones` json DEFAULT NULL COMMENT 'Array of prerequisite milestone IDs',
  `blocking_conditions` json DEFAULT NULL COMMENT 'Conditions that could block this milestone',
  `deliverables` text COMMENT 'Expected deliverables for this milestone',
  `success_criteria` text COMMENT 'Criteria for milestone completion',
  `responsible_role` varchar(50) DEFAULT NULL,
  `estimated_hours` int DEFAULT '8',
  `resource_requirements` json DEFAULT NULL,
  `cost_estimate` decimal(12,2) DEFAULT '0.00',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_template_sequence` (`template_id`,`sequence_order`),
  KEY `idx_template_id` (`template_id`),
  KEY `idx_sequence` (`sequence_order`),
  KEY `idx_critical_path` (`is_critical_path`),
  CONSTRAINT `milestone_templates_ibfk_1` FOREIGN KEY (`template_id`) REFERENCES `project_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Milestone definitions for project templates';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `milestone_templates`
--

LOCK TABLES `milestone_templates` WRITE;
/*!40000 ALTER TABLE `milestone_templates` DISABLE KEYS */;
INSERT INTO `milestone_templates` (`id`, `template_id`, `milestone_name`, `sequence_order`, `milestone_type`, `is_critical_path`, `is_client_milestone`, `requires_client_approval`, `start_offset_days`, `duration_days`, `buffer_days`, `depends_on_milestones`, `blocking_conditions`, `deliverables`, `success_criteria`, `responsible_role`, `estimated_hours`, `resource_requirements`, `cost_estimate`, `is_active`, `created_at`, `updated_at`) VALUES (1,1,'Project Planning & Requirements',1,'planning',1,1,1,0,5,0,NULL,NULL,'Project plan, requirements document, resource allocation','Client approval of project scope and timeline','project_manager',40,NULL,15000.00,1,'2025-09-13 01:58:23','2025-09-13 01:58:23'),(2,1,'Design Development',2,'execution',1,0,0,5,15,0,NULL,NULL,'Technical drawings, design specifications, material list','Design review completion and approval','engineer',120,NULL,45000.00,1,'2025-09-13 01:58:23','2025-09-13 01:58:23'),(3,1,'Client Design Review',3,'approval',1,1,1,20,3,0,NULL,NULL,'Design presentation, client feedback incorporation','Client sign-off on design specifications','client_manager',24,NULL,8000.00,1,'2025-09-13 01:58:23','2025-09-13 01:58:23'),(4,1,'Procurement & Manufacturing',4,'execution',1,0,0,23,12,0,NULL,NULL,'Materials procurement, manufacturing completion','All components manufactured to specification','manufacturing_engineer',96,NULL,80000.00,1,'2025-09-13 01:58:23','2025-09-13 01:58:23'),(5,1,'Quality Testing',5,'review',1,0,0,35,5,0,NULL,NULL,'Test reports, quality certificates, performance validation','All quality tests passed','quality_engineer',40,NULL,12000.00,1,'2025-09-13 01:58:23','2025-09-13 01:58:23'),(6,1,'Delivery & Installation',6,'delivery',1,1,0,40,5,0,NULL,NULL,'Equipment delivery, installation, training documentation','Successful installation and client training','installation_engineer',40,NULL,15000.00,1,'2025-09-13 01:58:23','2025-09-13 01:58:23');
/*!40000 ALTER TABLE `milestone_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobile_app_analytics`
--

DROP TABLE IF EXISTS `mobile_app_analytics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobile_app_analytics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `event_type` varchar(100) NOT NULL,
  `event_category` enum('user_action','app_lifecycle','performance','error','sync') NOT NULL,
  `event_data` json DEFAULT NULL,
  `screen_name` varchar(100) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_event_type` (`event_type`),
  KEY `idx_event_category` (`event_category`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_timestamp` (`timestamp`),
  KEY `idx_session_id` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Mobile app usage analytics and events';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobile_app_analytics`
--

LOCK TABLES `mobile_app_analytics` WRITE;
/*!40000 ALTER TABLE `mobile_app_analytics` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobile_app_analytics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobile_app_config`
--

DROP TABLE IF EXISTS `mobile_app_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobile_app_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `config_key` varchar(100) NOT NULL,
  `config_value` json NOT NULL,
  `description` text,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `config_key` (`config_key`),
  KEY `idx_config_key` (`config_key`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Mobile app configuration settings';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobile_app_config`
--

LOCK TABLES `mobile_app_config` WRITE;
/*!40000 ALTER TABLE `mobile_app_config` DISABLE KEYS */;
INSERT INTO `mobile_app_config` (`id`, `config_key`, `config_value`, `description`, `is_active`, `created_at`, `updated_at`) VALUES (1,'push_notifications','{\"alert\": true, \"badge\": true, \"sound\": true, \"enabled\": true}','Default push notification settings',1,'2025-09-13 09:49:09','2025-09-13 09:49:09'),(2,'offline_mode','{\"enabled\": true, \"max_offline_hours\": 72, \"sync_interval_seconds\": 300}','Offline mode configuration',1,'2025-09-13 09:49:09','2025-09-13 09:49:09'),(3,'security_settings','{\"biometric_auth\": true, \"auto_lock_minutes\": 15, \"max_login_attempts\": 5}','Security and authentication settings',1,'2025-09-13 09:49:09','2025-09-13 09:49:09'),(4,'feature_flags','{\"dark_mode\": true, \"voice_notes\": false, \"location_tracking\": false, \"real_time_updates\": true}','Feature availability flags',1,'2025-09-13 09:49:09','2025-09-13 09:49:09'),(5,'api_settings','{\"batch_size\": 100, \"retry_attempts\": 3, \"timeout_seconds\": 30}','API communication settings',1,'2025-09-13 09:49:09','2025-09-13 09:49:09');
/*!40000 ALTER TABLE `mobile_app_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobile_app_sessions`
--

DROP TABLE IF EXISTS `mobile_app_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobile_app_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `device_id` varchar(255) NOT NULL,
  `session_token` varchar(500) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `app_version` varchar(20) DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_activity` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ended_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_user_device` (`user_id`,`device_id`),
  KEY `idx_session_token` (`session_token`),
  KEY `idx_active_sessions` (`is_active`,`last_activity`),
  CONSTRAINT `mobile_app_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Mobile app session tracking for security and analytics';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobile_app_sessions`
--

LOCK TABLES `mobile_app_sessions` WRITE;
/*!40000 ALTER TABLE `mobile_app_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobile_app_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobile_devices`
--

DROP TABLE IF EXISTS `mobile_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobile_devices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `device_id` varchar(255) NOT NULL COMMENT 'Unique device identifier',
  `device_type` enum('ios','android','tablet') NOT NULL,
  `device_name` varchar(100) DEFAULT NULL COMMENT 'User-friendly device name',
  `os_version` varchar(50) DEFAULT NULL,
  `app_version` varchar(20) DEFAULT NULL,
  `push_token` text COMMENT 'Firebase/APNS push notification token',
  `is_active` tinyint(1) DEFAULT '1',
  `last_active` timestamp NULL DEFAULT NULL,
  `location_lat` decimal(10,8) DEFAULT NULL,
  `location_lng` decimal(11,8) DEFAULT NULL,
  `location_updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_device` (`user_id`,`device_id`),
  KEY `idx_user_active` (`user_id`,`is_active`),
  KEY `idx_push_token` (`push_token`(255)),
  KEY `idx_last_active` (`last_active`),
  CONSTRAINT `mobile_devices_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Mobile devices registered for push notifications and tracking';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobile_devices`
--

LOCK TABLES `mobile_devices` WRITE;
/*!40000 ALTER TABLE `mobile_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobile_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobile_offline_queue`
--

DROP TABLE IF EXISTS `mobile_offline_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobile_offline_queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `device_id` varchar(255) NOT NULL,
  `action_type` enum('update_milestone','add_note','status_change','upload_file','create_task') NOT NULL,
  `entity_type` enum('case','milestone','client','task') NOT NULL,
  `entity_id` int DEFAULT NULL,
  `action_data` json NOT NULL,
  `priority` int DEFAULT '5' COMMENT '1=highest, 10=lowest',
  `attempts` int DEFAULT '0',
  `max_attempts` int DEFAULT '3',
  `status` enum('pending','processing','completed','failed','cancelled') DEFAULT 'pending',
  `error_message` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `processed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_device` (`user_id`,`device_id`),
  KEY `idx_status_priority` (`status`,`priority`),
  KEY `idx_action_type` (`action_type`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `mobile_offline_queue_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Queue for actions performed offline on mobile devices';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobile_offline_queue`
--

LOCK TABLES `mobile_offline_queue` WRITE;
/*!40000 ALTER TABLE `mobile_offline_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobile_offline_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobile_push_notifications`
--

DROP TABLE IF EXISTS `mobile_push_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobile_push_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `device_id` varchar(255) DEFAULT NULL COMMENT 'Specific device or NULL for all devices',
  `notification_type` enum('task_reminder','deadline_alert','status_update','ai_insight','system_message') NOT NULL,
  `title` varchar(200) NOT NULL,
  `body` text NOT NULL,
  `data` json DEFAULT NULL COMMENT 'Additional data for the mobile app',
  `priority` enum('low','normal','high','critical') DEFAULT 'normal',
  `scheduled_for` timestamp NULL DEFAULT NULL COMMENT 'For scheduled notifications',
  `sent_at` timestamp NULL DEFAULT NULL,
  `delivery_status` enum('pending','sent','delivered','failed','cancelled') DEFAULT 'pending',
  `error_message` text,
  `opened_at` timestamp NULL DEFAULT NULL,
  `action_taken` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_device` (`user_id`,`device_id`),
  KEY `idx_delivery_status` (`delivery_status`),
  KEY `idx_scheduled_for` (`scheduled_for`),
  KEY `idx_sent_at` (`sent_at`),
  CONSTRAINT `mobile_push_notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Mobile push notifications with delivery tracking';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobile_push_notifications`
--

LOCK TABLES `mobile_push_notifications` WRITE;
/*!40000 ALTER TABLE `mobile_push_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobile_push_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobile_sync_status`
--

DROP TABLE IF EXISTS `mobile_sync_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mobile_sync_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `device_id` varchar(255) NOT NULL,
  `entity_type` enum('cases','milestones','notifications','clients','tasks') NOT NULL,
  `last_sync_timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `sync_version` bigint DEFAULT '1',
  `pending_uploads` int DEFAULT '0',
  `failed_syncs` int DEFAULT '0',
  `last_error` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_device_entity` (`user_id`,`device_id`,`entity_type`),
  KEY `idx_last_sync` (`last_sync_timestamp`),
  KEY `idx_pending_uploads` (`pending_uploads`),
  CONSTRAINT `mobile_sync_status_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Track sync status for offline mobile app functionality';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobile_sync_status`
--

LOCK TABLES `mobile_sync_status` WRITE;
/*!40000 ALTER TABLE `mobile_sync_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobile_sync_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_templates`
--

DROP TABLE IF EXISTS `notification_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `template_name` varchar(100) NOT NULL,
  `template_type` enum('sla_warning','sla_breach','escalation','reminder','approval_pending') NOT NULL,
  `subject_template` text NOT NULL,
  `body_template` text NOT NULL,
  `notification_channels` json NOT NULL,
  `trigger_hours_before` decimal(8,2) DEFAULT NULL,
  `max_frequency_hours` decimal(8,2) DEFAULT '24.00',
  `client_visible` tinyint(1) DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_name` (`template_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_templates`
--

LOCK TABLES `notification_templates` WRITE;
/*!40000 ALTER TABLE `notification_templates` DISABLE KEYS */;
INSERT INTO `notification_templates` (`id`, `template_name`, `template_type`, `subject_template`, `body_template`, `notification_channels`, `trigger_hours_before`, `max_frequency_hours`, `client_visible`, `is_active`, `created_at`, `updated_at`) VALUES (1,'SLA Warning - 2 Hours','sla_warning','SLA Warning: Case {{case_number}} - {{project_name}}','Your case {{case_number}} is approaching its SLA deadline in 2 hours.','[\"email\", \"in_app\"]',2.00,24.00,0,1,'2025-09-13 01:48:25','2025-09-13 01:48:25'),(2,'SLA Breach Alert','sla_breach','SLA BREACH: Case {{case_number}} - IMMEDIATE ACTION REQUIRED','Case {{case_number}} has breached its SLA and requires immediate attention.','[\"email\", \"sms\", \"in_app\"]',NULL,24.00,0,1,'2025-09-13 01:48:25','2025-09-13 01:48:25');
/*!40000 ALTER TABLE `notification_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `notification_type` enum('info','warning','error','success','mobile_push') DEFAULT 'info',
  `metadata` json DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_read` (`user_id`,`is_read`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_allocations`
--

DROP TABLE IF EXISTS `payment_allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_allocations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `payment_id` int NOT NULL,
  `invoice_id` int NOT NULL,
  `allocated_amount` decimal(15,4) NOT NULL,
  `allocation_date` date NOT NULL,
  `notes` text,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_payment_invoice` (`payment_id`,`invoice_id`),
  KEY `created_by` (`created_by`),
  KEY `idx_payment` (`payment_id`),
  KEY `idx_invoice` (`invoice_id`),
  CONSTRAINT `payment_allocations_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payment_allocations_ibfk_2` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`),
  CONSTRAINT `payment_allocations_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_allocations`
--

LOCK TABLES `payment_allocations` WRITE;
/*!40000 ALTER TABLE `payment_allocations` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_allocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `payment_number` varchar(100) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_type` enum('receipt','payment') NOT NULL,
  `party_type` enum('customer','supplier','employee','other') NOT NULL,
  `party_id` int DEFAULT NULL,
  `party_name` varchar(255) NOT NULL,
  `amount` decimal(15,4) NOT NULL,
  `payment_method` enum('cash','cheque','bank_transfer','upi','card','online') NOT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `cheque_number` varchar(50) DEFAULT NULL,
  `transaction_reference` varchar(255) DEFAULT NULL,
  `utr_number` varchar(50) DEFAULT NULL,
  `reference_type` enum('invoice','purchase_order','advance','refund','other') NOT NULL,
  `reference_id` int DEFAULT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `payment_status` enum('pending','cleared','bounced','cancelled') DEFAULT 'cleared',
  `clearance_date` date DEFAULT NULL,
  `notes` text,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payment_number` (`payment_number`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `idx_payment_number` (`payment_number`),
  KEY `idx_payment_date` (`payment_date`),
  KEY `idx_party` (`party_type`,`party_id`),
  KEY `idx_payment_type` (`payment_type`),
  KEY `idx_reference` (`reference_type`,`reference_id`),
  KEY `idx_payment_status` (`payment_status`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_categories`
--

DROP TABLE IF EXISTS `product_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_categories`
--

LOCK TABLES `product_categories` WRITE;
/*!40000 ALTER TABLE `product_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_categories`
--

DROP TABLE IF EXISTS `production_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `category_code` varchar(20) DEFAULT NULL,
  `description` text,
  `parent_category_id` int DEFAULT NULL,
  `default_lead_time_days` int DEFAULT '7',
  `default_batch_size` int DEFAULT '1',
  `requires_quality_check` tinyint(1) DEFAULT '1',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_code` (`category_code`),
  KEY `parent_category_id` (`parent_category_id`),
  KEY `idx_category_code` (`category_code`),
  CONSTRAINT `production_categories_ibfk_1` FOREIGN KEY (`parent_category_id`) REFERENCES `production_categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_categories`
--

LOCK TABLES `production_categories` WRITE;
/*!40000 ALTER TABLE `production_categories` DISABLE KEYS */;
INSERT INTO `production_categories` (`id`, `category_name`, `category_code`, `description`, `parent_category_id`, `default_lead_time_days`, `default_batch_size`, `requires_quality_check`, `status`, `created_at`) VALUES (1,'Electronics Components','ELEC','Electronic components and assemblies',NULL,7,1,1,'active','2025-09-12 06:11:31'),(2,'Mechanical Parts','MECH','Mechanical components and parts',NULL,5,1,1,'active','2025-09-12 06:11:31'),(3,'Software Products','SOFT','Software and digital products',NULL,3,1,1,'active','2025-09-12 06:11:31'),(4,'Assemblies','ASSY','Complete product assemblies',NULL,10,1,1,'active','2025-09-12 06:11:31'),(5,'Consumables','CONS','Consumable items and supplies',NULL,2,1,1,'active','2025-09-12 06:11:31');
/*!40000 ALTER TABLE `production_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_documents`
--

DROP TABLE IF EXISTS `production_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `work_order_id` int NOT NULL,
  `document_type` enum('drawing','specification','photo','video','report','certificate','other') NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `version` varchar(20) DEFAULT '1.0',
  `is_approved` tinyint(1) DEFAULT '0',
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `uploaded_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `approved_by` (`approved_by`),
  KEY `idx_work_order_id` (`work_order_id`),
  KEY `idx_document_type` (`document_type`),
  KEY `idx_uploaded_by` (`uploaded_by`),
  CONSTRAINT `production_documents_ibfk_1` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_documents_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `production_documents_ibfk_3` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_documents`
--

LOCK TABLES `production_documents` WRITE;
/*!40000 ALTER TABLE `production_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `production_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_items`
--

DROP TABLE IF EXISTS `production_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `item_code` varchar(50) NOT NULL,
  `item_name` varchar(200) NOT NULL,
  `description` text,
  `category_id` int DEFAULT NULL,
  `unit_of_measurement` varchar(20) DEFAULT 'PCS',
  `standard_cost` decimal(12,4) DEFAULT NULL,
  `standard_time_hours` decimal(8,2) DEFAULT NULL,
  `batch_size` int DEFAULT '1',
  `minimum_stock_level` decimal(10,2) DEFAULT '0.00',
  `has_bom` tinyint(1) DEFAULT '0',
  `bom_version` varchar(10) DEFAULT '1.0',
  `requires_inspection` tinyint(1) DEFAULT '1',
  `shelf_life_days` int DEFAULT NULL,
  `status` enum('active','inactive','discontinued') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_code` (`item_code`),
  KEY `idx_item_code` (`item_code`),
  KEY `idx_category` (`category_id`),
  KEY `idx_has_bom` (`has_bom`),
  CONSTRAINT `production_items_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `production_categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_items`
--

LOCK TABLES `production_items` WRITE;
/*!40000 ALTER TABLE `production_items` DISABLE KEYS */;
INSERT INTO `production_items` (`id`, `item_code`, `item_name`, `description`, `category_id`, `unit_of_measurement`, `standard_cost`, `standard_time_hours`, `batch_size`, `minimum_stock_level`, `has_bom`, `bom_version`, `requires_inspection`, `shelf_life_days`, `status`, `created_at`, `updated_at`, `created_by`) VALUES (1,'PI001','Test Production Item','Sample production item for testing',1,'PCS',100.0000,NULL,1,0.00,0,'1.0',1,NULL,'active','2025-09-12 06:18:34','2025-09-12 06:18:34',NULL);
/*!40000 ALTER TABLE `production_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_operations`
--

DROP TABLE IF EXISTS `production_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_operations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `operation_code` varchar(20) NOT NULL,
  `operation_name` varchar(100) NOT NULL,
  `description` text,
  `operation_type` enum('setup','production','inspection','packaging','testing') DEFAULT 'production',
  `work_center_code` varchar(20) DEFAULT NULL,
  `setup_time_hours` decimal(8,4) DEFAULT '0.0000',
  `run_time_per_unit_hours` decimal(8,4) DEFAULT '0.0000',
  `teardown_time_hours` decimal(8,4) DEFAULT '0.0000',
  `hourly_rate` decimal(10,2) DEFAULT '0.00',
  `setup_cost` decimal(10,2) DEFAULT '0.00',
  `requires_inspection` tinyint(1) DEFAULT '0',
  `inspection_percentage` decimal(5,2) DEFAULT '0.00',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `operation_code` (`operation_code`),
  KEY `idx_operation_code` (`operation_code`),
  KEY `idx_operation_type` (`operation_type`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_operations`
--

LOCK TABLES `production_operations` WRITE;
/*!40000 ALTER TABLE `production_operations` DISABLE KEYS */;
INSERT INTO `production_operations` (`id`, `operation_code`, `operation_name`, `description`, `operation_type`, `work_center_code`, `setup_time_hours`, `run_time_per_unit_hours`, `teardown_time_hours`, `hourly_rate`, `setup_cost`, `requires_inspection`, `inspection_percentage`, `status`, `created_at`) VALUES (1,'SETUP','Machine Setup',NULL,'setup',NULL,0.5000,0.0000,0.0000,25.00,0.00,0,0.00,'active','2025-09-12 06:11:31'),(2,'CUT','Cutting Operation',NULL,'production',NULL,0.2500,0.1000,0.0000,20.00,0.00,0,0.00,'active','2025-09-12 06:11:31'),(3,'DRILL','Drilling Operation',NULL,'production',NULL,0.1000,0.0500,0.0000,22.00,0.00,0,0.00,'active','2025-09-12 06:11:31'),(4,'ASSEMBLE','Assembly Operation',NULL,'production',NULL,0.2000,0.1500,0.0000,18.00,0.00,0,0.00,'active','2025-09-12 06:11:31'),(5,'TEST','Testing Operation',NULL,'inspection',NULL,0.1000,0.0800,0.0000,30.00,0.00,0,0.00,'active','2025-09-12 06:11:31'),(6,'PACK','Packaging Operation',NULL,'packaging',NULL,0.1000,0.0200,0.0000,15.00,0.00,0,0.00,'active','2025-09-12 06:11:31'),(7,'QC','Quality Control',NULL,'inspection',NULL,0.0500,0.1000,0.0000,35.00,0.00,0,0.00,'active','2025-09-12 06:11:31'),(8,'FINISH','Finishing Operation',NULL,'production',NULL,0.1500,0.1200,0.0000,25.00,0.00,0,0.00,'active','2025-09-12 06:11:31');
/*!40000 ALTER TABLE `production_operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_schedule`
--

DROP TABLE IF EXISTS `production_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_schedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sales_order_id` int NOT NULL,
  `sales_order_item_id` int DEFAULT NULL,
  `planned_start_date` date NOT NULL,
  `planned_end_date` date NOT NULL,
  `actual_start_date` date DEFAULT NULL,
  `actual_end_date` date DEFAULT NULL,
  `assigned_to` int DEFAULT NULL,
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `status` enum('scheduled','in_progress','completed','delayed','cancelled') DEFAULT 'scheduled',
  `notes` text,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `sales_order_item_id` (`sales_order_item_id`),
  KEY `created_by` (`created_by`),
  KEY `idx_sales_order_id` (`sales_order_id`),
  KEY `idx_dates` (`planned_start_date`,`planned_end_date`),
  KEY `idx_assigned_to` (`assigned_to`),
  KEY `idx_status` (`status`),
  CONSTRAINT `production_schedule_ibfk_1` FOREIGN KEY (`sales_order_id`) REFERENCES `sales_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_schedule_ibfk_2` FOREIGN KEY (`sales_order_item_id`) REFERENCES `sales_order_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_schedule_ibfk_3` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `production_schedule_ibfk_4` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_schedule`
--

LOCK TABLES `production_schedule` WRITE;
/*!40000 ALTER TABLE `production_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `production_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_schedule_items`
--

DROP TABLE IF EXISTS `production_schedule_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_schedule_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `production_schedule_id` int NOT NULL,
  `production_item_id` int NOT NULL,
  `week_number` int NOT NULL,
  `planned_quantity` decimal(12,4) NOT NULL,
  `committed_quantity` decimal(12,4) DEFAULT '0.0000',
  `forecast_quantity` decimal(12,4) DEFAULT '0.0000',
  `sales_order_quantity` decimal(12,4) DEFAULT '0.0000',
  `safety_stock_quantity` decimal(12,4) DEFAULT '0.0000',
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_schedule_item_week` (`production_schedule_id`,`production_item_id`,`week_number`),
  KEY `production_item_id` (`production_item_id`),
  KEY `idx_week_number` (`week_number`),
  CONSTRAINT `production_schedule_items_ibfk_1` FOREIGN KEY (`production_schedule_id`) REFERENCES `production_schedules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_schedule_items_ibfk_2` FOREIGN KEY (`production_item_id`) REFERENCES `production_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_schedule_items`
--

LOCK TABLES `production_schedule_items` WRITE;
/*!40000 ALTER TABLE `production_schedule_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `production_schedule_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_schedules`
--

DROP TABLE IF EXISTS `production_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_schedules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `schedule_name` varchar(100) NOT NULL,
  `schedule_period_start` date NOT NULL,
  `schedule_period_end` date NOT NULL,
  `planning_horizon_weeks` int DEFAULT '12',
  `freeze_period_weeks` int DEFAULT '2',
  `status` enum('draft','active','frozen','completed') DEFAULT 'draft',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_schedule_period` (`schedule_period_start`,`schedule_period_end`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_schedules`
--

LOCK TABLES `production_schedules` WRITE;
/*!40000 ALTER TABLE `production_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `production_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_tasks`
--

DROP TABLE IF EXISTS `production_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `work_order_id` int NOT NULL,
  `task_name` varchar(255) NOT NULL,
  `description` text,
  `sequence_order` int DEFAULT '1',
  `assigned_to` int DEFAULT NULL,
  `estimated_hours` decimal(8,2) DEFAULT NULL,
  `actual_hours` decimal(8,2) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('pending','in_progress','completed','skipped') DEFAULT 'pending',
  `completion_notes` text,
  `depends_on_task_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `depends_on_task_id` (`depends_on_task_id`),
  KEY `idx_work_order_id` (`work_order_id`),
  KEY `idx_assigned_to` (`assigned_to`),
  KEY `idx_status` (`status`),
  KEY `idx_sequence` (`sequence_order`),
  CONSTRAINT `production_tasks_ibfk_1` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_tasks_ibfk_2` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `production_tasks_ibfk_3` FOREIGN KEY (`depends_on_task_id`) REFERENCES `production_tasks` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_tasks`
--

LOCK TABLES `production_tasks` WRITE;
/*!40000 ALTER TABLE `production_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `production_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `production_time_logs`
--

DROP TABLE IF EXISTS `production_time_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `production_time_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `work_order_id` int NOT NULL,
  `task_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `start_time` timestamp NOT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `total_hours` decimal(8,2) DEFAULT NULL,
  `activity_description` text,
  `break_time_minutes` int DEFAULT '0',
  `efficiency_rating` enum('low','medium','high') DEFAULT 'medium',
  `is_billable` tinyint(1) DEFAULT '1',
  `is_approved` tinyint(1) DEFAULT '0',
  `approved_by` int DEFAULT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `approved_by` (`approved_by`),
  KEY `idx_work_order_id` (`work_order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_start_time` (`start_time`),
  CONSTRAINT `production_time_logs_ibfk_1` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_time_logs_ibfk_2` FOREIGN KEY (`task_id`) REFERENCES `production_tasks` (`id`) ON DELETE SET NULL,
  CONSTRAINT `production_time_logs_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `production_time_logs_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `production_time_logs`
--

LOCK TABLES `production_time_logs` WRITE;
/*!40000 ALTER TABLE `production_time_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `production_time_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `make` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `part_code` varchar(255) DEFAULT NULL,
  `product_code` varchar(100) DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `sub_category_id` int DEFAULT NULL,
  `description` text,
  `mrp` decimal(12,2) DEFAULT NULL,
  `vendor_discount` decimal(5,2) DEFAULT '0.00',
  `last_price` decimal(12,2) DEFAULT NULL,
  `last_purchase_price` decimal(12,2) DEFAULT NULL,
  `last_purchase_date` date DEFAULT NULL,
  `last_price_date` date DEFAULT NULL,
  `hsn_code` varchar(50) DEFAULT NULL,
  `gst_rate` decimal(5,2) DEFAULT '18.00',
  `unit` varchar(50) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `serial_number_required` tinyint(1) DEFAULT '0',
  `warranty_period` int DEFAULT '0',
  `warranty_period_type` enum('months','years') DEFAULT 'months',
  `warranty_upto` date DEFAULT NULL,
  `min_stock_level` int DEFAULT '0',
  `max_stock_level` int DEFAULT '0',
  `reorder_level` int DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code` (`product_code`),
  KEY `category_id` (`category_id`),
  KEY `sub_category_id` (`sub_category_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `products_ibfk_2` FOREIGN KEY (`sub_category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`id`, `name`, `make`, `model`, `part_code`, `product_code`, `category_id`, `sub_category_id`, `description`, `mrp`, `vendor_discount`, `last_price`, `last_purchase_price`, `last_purchase_date`, `last_price_date`, `hsn_code`, `gst_rate`, `unit`, `image_url`, `created_at`, `updated_at`, `serial_number_required`, `warranty_period`, `warranty_period_type`, `warranty_upto`, `min_stock_level`, `max_stock_level`, `reorder_level`, `is_active`) VALUES (1,'Main Control Panel','Schneider','Prisma P1','MCP-001','MCP-SCH-P1-001',2,NULL,'Main electrical control panel with IP55 rating',150000.00,7.50,140000.00,138000.00,'2025-08-15',NULL,NULL,18.00,'nos',NULL,'2025-09-11 14:58:15','2025-09-11 15:30:36',1,24,'months',NULL,2,0,6,1),(2,'UPS 10KVA','APC','Smart-UPS SRT','UPS-10K','UPS-APC-SRT-10K',3,NULL,'10KVA Online UPS system',85000.00,7.50,80000.00,78000.00,'2025-08-15',NULL,NULL,18.00,'nos',NULL,'2025-09-11 14:58:15','2025-09-11 15:20:07',1,36,'months',NULL,2,0,1,1),(3,'Diesel Generator 15KVA','Mahindra','Powerol','DG-15K','DG-MAH-POW-15K',4,NULL,'15KVA Diesel Generator with AMF panel',180000.00,7.50,175000.00,172000.00,'2025-08-15',NULL,NULL,18.00,'nos',NULL,'2025-09-11 14:58:15','2025-09-11 15:20:07',1,12,'months',NULL,2,0,1,1),(4,'MCCB 100A','L&T','NM8-100','MCCB-100','MCCB-LT-NM8-100',1,7,'100A 4-pole MCCB',3500.00,8.50,3200.00,3100.00,'2025-08-15',NULL,NULL,18.00,'nos',NULL,'2025-09-11 14:58:15','2025-09-11 15:50:00',0,24,'months',NULL,10,0,20,1),(5,'Contactor 40A','Schneider','LC1D40','CTR-40','CTR-SCH-LC1D-40',1,NULL,'40A 3-pole contactor',2500.00,8.50,2300.00,2250.00,'2025-08-15',NULL,NULL,18.00,'nos',NULL,'2025-09-11 14:58:15','2025-09-11 15:20:07',0,24,'months',NULL,10,0,5,1),(6,'MCB 32A','Legrand','DX3-32','MCB-32','MCB-LEG-DX3-32',1,7,'32A Single pole MCB',450.00,5.00,420.00,410.00,'2025-08-15',NULL,NULL,18.00,'nos',NULL,'2025-09-11 14:58:15','2025-09-11 15:50:00',0,24,'months',NULL,25,0,15,1),(7,'Power Cable 4 core 25 sq mm','Polycab','FR-LSH','CABLE-4C25','CBL-POL-FR-4C25',1,NULL,'4 core 25 sq mm power cable',280.00,5.00,260.00,255.00,'2025-08-15',NULL,NULL,12.00,'mtr',NULL,'2025-09-11 14:58:15','2025-09-11 15:20:07',0,12,'months',NULL,500,0,200,1),(8,'Distribution Panel','Schneider','Kaedra','DP-001','DP-SCH-KAE-001',2,8,'Distribution panel 24 way',8500.00,8.50,8000.00,7800.00,'2025-08-15',NULL,NULL,18.00,'nos',NULL,'2025-09-11 14:58:15','2025-09-11 15:50:00',1,18,'months',NULL,2,0,1,1);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proforma_invoices`
--

DROP TABLE IF EXISTS `proforma_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proforma_invoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pi_number` varchar(50) NOT NULL,
  `purchase_order_id` int DEFAULT NULL,
  `supplier_id` int DEFAULT NULL,
  `pi_date` date NOT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `status` enum('sent','acknowledged','paid','cancelled') DEFAULT 'sent',
  `payment_terms` text,
  `notes` text,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pi_number` (`pi_number`),
  KEY `purchase_order_id` (`purchase_order_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `proforma_invoices_ibfk_1` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`),
  CONSTRAINT `proforma_invoices_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `proforma_invoices_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proforma_invoices`
--

LOCK TABLES `proforma_invoices` WRITE;
/*!40000 ALTER TABLE `proforma_invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `proforma_invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_templates`
--

DROP TABLE IF EXISTS `project_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `template_name` varchar(100) NOT NULL,
  `template_type` enum('engineering','manufacturing','installation','service','custom') NOT NULL,
  `description` text,
  `default_duration_days` int NOT NULL DEFAULT '30',
  `complexity_level` enum('simple','medium','complex','critical') DEFAULT 'medium',
  `required_roles` json DEFAULT NULL COMMENT 'Roles needed for this project type',
  `estimated_cost_range` varchar(50) DEFAULT NULL,
  `auto_create_milestones` tinyint(1) DEFAULT '1',
  `milestone_count` int DEFAULT '5',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_name` (`template_name`),
  KEY `idx_template_type` (`template_type`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Reusable project templates with predefined milestones';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_templates`
--

LOCK TABLES `project_templates` WRITE;
/*!40000 ALTER TABLE `project_templates` DISABLE KEYS */;
INSERT INTO `project_templates` (`id`, `template_name`, `template_type`, `description`, `default_duration_days`, `complexity_level`, `required_roles`, `estimated_cost_range`, `auto_create_milestones`, `milestone_count`, `is_active`, `created_at`, `updated_at`) VALUES (1,'Standard Engineering Project','engineering','Standard engineering design and development project with client approvals',45,'medium','[\"engineer\", \"manager\", \"quality_engineer\"]','50000-200000',1,6,1,'2025-09-13 01:57:55','2025-09-13 01:57:55'),(2,'Manufacturing Setup','manufacturing','Manufacturing process setup with tooling and quality validation',30,'complex','[\"manufacturing_engineer\", \"quality_engineer\", \"production_manager\"]','100000-500000',1,5,1,'2025-09-13 01:57:55','2025-09-13 01:57:55'),(3,'Equipment Installation','installation','On-site equipment installation and commissioning',20,'medium','[\"technician\", \"installation_engineer\", \"quality_engineer\"]','25000-100000',1,4,1,'2025-09-13 01:57:55','2025-09-13 01:57:55'),(4,'Service & Maintenance','service','Routine service and maintenance work',10,'simple','[\"technician\", \"service_engineer\"]','5000-25000',1,3,1,'2025-09-13 01:57:55','2025-09-13 01:57:55'),(5,'Custom Solution Development','custom','Custom engineering solution development',60,'critical','[\"senior_engineer\", \"project_manager\", \"quality_engineer\", \"client_manager\"]','200000-1000000',1,8,1,'2025-09-13 01:57:55','2025-09-13 01:57:55');
/*!40000 ALTER TABLE `project_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_order_items`
--

DROP TABLE IF EXISTS `purchase_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `po_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `price` decimal(12,2) NOT NULL,
  `tax_percentage` decimal(5,2) DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `received_quantity` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `po_id` (`po_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `purchase_order_items_ibfk_1` FOREIGN KEY (`po_id`) REFERENCES `purchase_orders` (`id`),
  CONSTRAINT `purchase_order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_items`
--

LOCK TABLES `purchase_order_items` WRITE;
/*!40000 ALTER TABLE `purchase_order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_orders`
--

DROP TABLE IF EXISTS `purchase_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `po_id` varchar(50) NOT NULL,
  `purchase_request_id` int NOT NULL,
  `supplier_id` int NOT NULL,
  `date` date NOT NULL,
  `delivery_date` date DEFAULT NULL,
  `shipping_address` text,
  `billing_address` text,
  `payment_terms` text,
  `delivery_terms` text,
  `status` enum('draft','approved','sent','partially_received','fully_received','cancelled') DEFAULT 'draft',
  `total_amount` decimal(12,2) NOT NULL,
  `total_tax` decimal(12,2) NOT NULL,
  `grand_total` decimal(12,2) NOT NULL,
  `notes` text,
  `created_by` int NOT NULL,
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `po_id` (`po_id`),
  KEY `purchase_request_id` (`purchase_request_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `created_by` (`created_by`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `purchase_orders_ibfk_1` FOREIGN KEY (`purchase_request_id`) REFERENCES `purchase_requests` (`id`),
  CONSTRAINT `purchase_orders_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `purchase_orders_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `purchase_orders_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_orders`
--

LOCK TABLES `purchase_orders` WRITE;
/*!40000 ALTER TABLE `purchase_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_request_items`
--

DROP TABLE IF EXISTS `purchase_request_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_request_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `specifications` text,
  `supplier_id` int DEFAULT NULL,
  `quoted_price` decimal(12,2) DEFAULT NULL,
  `quoted_delivery_time` varchar(100) DEFAULT NULL,
  `response_notes` text,
  `response_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `request_id` (`request_id`),
  KEY `product_id` (`product_id`),
  KEY `supplier_id` (`supplier_id`),
  CONSTRAINT `purchase_request_items_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `purchase_requests` (`id`),
  CONSTRAINT `purchase_request_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  CONSTRAINT `purchase_request_items_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_request_items`
--

LOCK TABLES `purchase_request_items` WRITE;
/*!40000 ALTER TABLE `purchase_request_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_request_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_requests`
--

DROP TABLE IF EXISTS `purchase_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `request_id` varchar(50) NOT NULL,
  `quotation_id` int NOT NULL,
  `date` date NOT NULL,
  `required_by` date DEFAULT NULL,
  `status` enum('draft','sent','response_received','closed','cancelled') DEFAULT 'draft',
  `notes` text,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `request_id` (`request_id`),
  KEY `quotation_id` (`quotation_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `purchase_requests_ibfk_1` FOREIGN KEY (`quotation_id`) REFERENCES `quotations` (`id`),
  CONSTRAINT `purchase_requests_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_requests`
--

LOCK TABLES `purchase_requests` WRITE;
/*!40000 ALTER TABLE `purchase_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_requisition_items`
--

DROP TABLE IF EXISTS `purchase_requisition_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_requisition_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pr_id` int NOT NULL,
  `product_id` int NOT NULL,
  `quantity` int NOT NULL,
  `estimated_price` decimal(12,2) DEFAULT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `pr_id` (`pr_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `purchase_requisition_items_ibfk_1` FOREIGN KEY (`pr_id`) REFERENCES `purchase_requisitions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_requisition_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_requisition_items`
--

LOCK TABLES `purchase_requisition_items` WRITE;
/*!40000 ALTER TABLE `purchase_requisition_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_requisition_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_requisitions`
--

DROP TABLE IF EXISTS `purchase_requisitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_requisitions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pr_number` varchar(50) NOT NULL,
  `quotation_id` int DEFAULT NULL,
  `supplier_id` int DEFAULT NULL,
  `pr_date` date NOT NULL,
  `status` enum('draft','sent','responded','cancelled') DEFAULT 'draft',
  `notes` text,
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pr_number` (`pr_number`),
  KEY `quotation_id` (`quotation_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `purchase_requisitions_ibfk_1` FOREIGN KEY (`quotation_id`) REFERENCES `quotations` (`id`),
  CONSTRAINT `purchase_requisitions_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `purchase_requisitions_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_requisitions`
--

LOCK TABLES `purchase_requisitions` WRITE;
/*!40000 ALTER TABLE `purchase_requisitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_requisitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quality_checkpoints`
--

DROP TABLE IF EXISTS `quality_checkpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quality_checkpoints` (
  `id` int NOT NULL AUTO_INCREMENT,
  `work_order_id` int NOT NULL,
  `checkpoint_name` varchar(255) NOT NULL,
  `description` text,
  `sequence_order` int DEFAULT '1',
  `inspection_criteria` text,
  `measurement_required` tinyint(1) DEFAULT '0',
  `measurement_unit` varchar(50) DEFAULT NULL,
  `expected_value` varchar(100) DEFAULT NULL,
  `tolerance_range` varchar(100) DEFAULT NULL,
  `status` enum('pending','passed','failed','skipped','rework_required') DEFAULT 'pending',
  `actual_value` varchar(100) DEFAULT NULL,
  `inspector_notes` text,
  `inspected_by` int DEFAULT NULL,
  `inspection_date` date DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `inspected_by` (`inspected_by`),
  KEY `created_by` (`created_by`),
  KEY `idx_work_order_id` (`work_order_id`),
  KEY `idx_status` (`status`),
  KEY `idx_sequence` (`sequence_order`),
  CONSTRAINT `quality_checkpoints_ibfk_1` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `quality_checkpoints_ibfk_2` FOREIGN KEY (`inspected_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `quality_checkpoints_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quality_checkpoints`
--

LOCK TABLES `quality_checkpoints` WRITE;
/*!40000 ALTER TABLE `quality_checkpoints` DISABLE KEYS */;
/*!40000 ALTER TABLE `quality_checkpoints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quality_inspections`
--

DROP TABLE IF EXISTS `quality_inspections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quality_inspections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `inspection_number` varchar(50) NOT NULL,
  `inspection_type` enum('incoming','in_process','final','customer_return') NOT NULL,
  `work_order_id` int DEFAULT NULL,
  `work_order_operation_id` int DEFAULT NULL,
  `production_item_id` int DEFAULT NULL,
  `quantity_inspected` decimal(12,4) NOT NULL,
  `quantity_accepted` decimal(12,4) DEFAULT '0.0000',
  `quantity_rejected` decimal(12,4) DEFAULT '0.0000',
  `quantity_rework` decimal(12,4) DEFAULT '0.0000',
  `unit_of_measurement` varchar(20) DEFAULT NULL,
  `inspection_result` enum('pass','fail','conditional','pending') DEFAULT 'pending',
  `defect_category` varchar(100) DEFAULT NULL,
  `defect_description` text,
  `inspector_employee_id` int NOT NULL,
  `inspection_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `inspection_location` varchar(100) DEFAULT NULL,
  `test_certificate_path` varchar(500) DEFAULT NULL,
  `photos_path` varchar(500) DEFAULT NULL,
  `corrective_action_required` tinyint(1) DEFAULT '0',
  `corrective_action_description` text,
  `corrective_action_due_date` date DEFAULT NULL,
  `corrective_action_completed` tinyint(1) DEFAULT '0',
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inspection_number` (`inspection_number`),
  KEY `work_order_operation_id` (`work_order_operation_id`),
  KEY `production_item_id` (`production_item_id`),
  KEY `idx_inspection_number` (`inspection_number`),
  KEY `idx_work_order` (`work_order_id`),
  KEY `idx_inspection_type` (`inspection_type`),
  KEY `idx_result` (`inspection_result`),
  KEY `idx_inspection_date` (`inspection_date`),
  CONSTRAINT `quality_inspections_ibfk_1` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `quality_inspections_ibfk_2` FOREIGN KEY (`work_order_operation_id`) REFERENCES `work_order_operations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `quality_inspections_ibfk_3` FOREIGN KEY (`production_item_id`) REFERENCES `production_items` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quality_inspections`
--

LOCK TABLES `quality_inspections` WRITE;
/*!40000 ALTER TABLE `quality_inspections` DISABLE KEYS */;
/*!40000 ALTER TABLE `quality_inspections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotation_items`
--

DROP TABLE IF EXISTS `quotation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotation_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quotation_id` int NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `description` text,
  `hsn_code` varchar(50) DEFAULT NULL,
  `quantity` int NOT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `rate` decimal(12,2) NOT NULL,
  `discount_percentage` decimal(5,2) DEFAULT NULL,
  `tax_percentage` decimal(5,2) DEFAULT NULL,
  `cgst_percentage` decimal(5,2) DEFAULT NULL,
  `sgst_percentage` decimal(5,2) DEFAULT NULL,
  `igst_percentage` decimal(5,2) DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `lead_time` varchar(100) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `quotation_id` (`quotation_id`),
  CONSTRAINT `quotation_items_ibfk_1` FOREIGN KEY (`quotation_id`) REFERENCES `quotations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotation_items`
--

LOCK TABLES `quotation_items` WRITE;
/*!40000 ALTER TABLE `quotation_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotation_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotations`
--

DROP TABLE IF EXISTS `quotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quotation_id` varchar(50) NOT NULL,
  `estimation_id` int NOT NULL,
  `date` date NOT NULL,
  `valid_until` date NOT NULL,
  `status` enum('draft','pending_approval','approved','rejected','sent','accepted','expired') DEFAULT 'draft',
  `terms_conditions` text,
  `delivery_terms` text,
  `payment_terms` text,
  `warranty_terms` text,
  `total_amount` decimal(12,2) NOT NULL,
  `total_tax` decimal(12,2) NOT NULL,
  `grand_total` decimal(12,2) NOT NULL,
  `profit_percentage` decimal(5,2) DEFAULT NULL,
  `notes` text,
  `created_by` int NOT NULL,
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `case_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `quotation_id` (`quotation_id`),
  KEY `estimation_id` (`estimation_id`),
  KEY `created_by` (`created_by`),
  KEY `approved_by` (`approved_by`),
  CONSTRAINT `quotations_ibfk_1` FOREIGN KEY (`estimation_id`) REFERENCES `estimations` (`id`),
  CONSTRAINT `quotations_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `quotations_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotations`
--

LOCK TABLES `quotations` WRITE;
/*!40000 ALTER TABLE `quotations` DISABLE KEYS */;
INSERT INTO `quotations` (`id`, `quotation_id`, `estimation_id`, `date`, `valid_until`, `status`, `terms_conditions`, `delivery_terms`, `payment_terms`, `warranty_terms`, `total_amount`, `total_tax`, `grand_total`, `profit_percentage`, `notes`, `created_by`, `approved_by`, `approved_at`, `created_at`, `updated_at`, `case_id`) VALUES (1,'VESPL/Q/2526/001',1,'2025-09-09','2025-10-09','approved','Standard terms and conditions apply','4-6 weeks from approval','30% advance, 70% on delivery','12 months warranty',0.00,0.00,0.00,0.00,NULL,1,1,'2025-09-09 18:14:00','2025-09-09 18:02:15','2025-09-09 18:14:00',NULL);
/*!40000 ALTER TABLE `quotations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_enquiries`
--

DROP TABLE IF EXISTS `sales_enquiries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_enquiries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `enquiry_id` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `client_id` int NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `description` text,
  `enquiry_by` int NOT NULL,
  `status` enum('new','assigned','for_estimation','quoted','approved','rejected') DEFAULT 'new',
  `assigned_to` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `case_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `enquiry_id` (`enquiry_id`),
  KEY `client_id` (`client_id`),
  KEY `enquiry_by` (`enquiry_by`),
  KEY `assigned_to` (`assigned_to`),
  CONSTRAINT `sales_enquiries_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `sales_enquiries_ibfk_2` FOREIGN KEY (`enquiry_by`) REFERENCES `users` (`id`),
  CONSTRAINT `sales_enquiries_ibfk_3` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_enquiries`
--

LOCK TABLES `sales_enquiries` WRITE;
/*!40000 ALTER TABLE `sales_enquiries` DISABLE KEYS */;
INSERT INTO `sales_enquiries` (`id`, `enquiry_id`, `date`, `client_id`, `project_name`, `description`, `enquiry_by`, `status`, `assigned_to`, `created_at`, `updated_at`, `case_id`) VALUES (1,'VESPL/EQ/2526/002','2025-09-09',1,'Test Project','Test description',1,'new',NULL,'2025-09-09 17:30:31','2025-09-12 17:50:49',1),(2,'VESPL/EQ/2526/003','2025-09-09',2,'Robotic Welding System','Industrial robotic welding system for automotive parts manufacturing',1,'new',NULL,'2025-09-09 17:35:12','2025-09-12 17:50:49',2),(4,'VESPL/EQ/2526/004','2025-09-12',1,'Test Project Fixed','Test Description Fixed',1,'assigned',3,'2025-09-12 09:32:12','2025-09-12 17:50:49',3),(5,'VESPL/EQ/2526/005','2025-09-12',6,'Updated Test Project','Updated test description',1,'new',2,'2025-09-12 09:33:20','2025-09-12 17:50:49',4),(10,'VESPL/EQ/2526/006','2025-09-13',1,'Test Project',NULL,1,'new',NULL,'2025-09-13 03:21:17','2025-09-13 03:21:17',NULL),(11,'VESPL/EQ/2526/007','2025-09-13',1,'Test Project',NULL,1,'new',NULL,'2025-09-13 03:22:13','2025-09-13 03:22:13',NULL),(12,'VESPL/EQ/2526/008','2025-09-13',1,'Test Project',NULL,1,'new',NULL,'2025-09-13 03:22:44','2025-09-13 03:22:44',NULL),(13,'VESPL/EQ/2526/009','2025-09-13',1,'Test Project',NULL,1,'new',NULL,'2025-09-13 03:23:04','2025-09-13 03:23:04',NULL),(14,'VESPL/EQ/2526/010','2025-09-13',1,'Test Project',NULL,1,'new',NULL,'2025-09-13 03:23:38','2025-09-13 03:23:38',NULL),(15,'VESPL/EQ/2526/011','2025-09-13',1,'Test Project','Test enquiry description',1,'new',NULL,'2025-09-13 03:25:21','2025-09-13 03:25:21',NULL),(16,'VESPL/EQ/2526/012','2025-09-13',1,'Connection Test','Testing API connection',1,'assigned',1,'2025-09-13 03:26:39','2025-09-13 03:27:37',NULL),(17,'VESPL/EQ/2526/013','2025-09-13',7,'Datacenter','Setup a datacenter in Mangalore',1,'for_estimation',1,'2025-09-13 03:28:32','2025-09-13 04:03:49',NULL);
/*!40000 ALTER TABLE `sales_enquiries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_order_dispatch`
--

DROP TABLE IF EXISTS `sales_order_dispatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_order_dispatch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sales_order_id` int NOT NULL,
  `dispatch_date` date NOT NULL,
  `tracking_number` varchar(100) DEFAULT NULL,
  `courier_company` varchar(255) DEFAULT NULL,
  `dispatch_address` text NOT NULL,
  `dispatch_method` enum('courier','transport','self_pickup','direct_delivery') NOT NULL,
  `estimated_delivery_date` date DEFAULT NULL,
  `actual_delivery_date` date DEFAULT NULL,
  `status` enum('packed','dispatched','in_transit','delivered','returned') DEFAULT 'packed',
  `notes` text,
  `dispatched_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `dispatched_by` (`dispatched_by`),
  KEY `idx_sales_order_id` (`sales_order_id`),
  KEY `idx_dispatch_date` (`dispatch_date`),
  KEY `idx_status` (`status`),
  CONSTRAINT `sales_order_dispatch_ibfk_1` FOREIGN KEY (`sales_order_id`) REFERENCES `sales_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_order_dispatch_ibfk_2` FOREIGN KEY (`dispatched_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_order_dispatch`
--

LOCK TABLES `sales_order_dispatch` WRITE;
/*!40000 ALTER TABLE `sales_order_dispatch` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_order_dispatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_order_items`
--

DROP TABLE IF EXISTS `sales_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_order_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sales_order_id` int NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `description` text,
  `hsn_code` varchar(20) DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `cgst_percentage` decimal(5,2) DEFAULT '0.00',
  `sgst_percentage` decimal(5,2) DEFAULT '0.00',
  `igst_percentage` decimal(5,2) DEFAULT '0.00',
  `cgst_amount` decimal(15,2) DEFAULT '0.00',
  `sgst_amount` decimal(15,2) DEFAULT '0.00',
  `igst_amount` decimal(15,2) DEFAULT '0.00',
  `production_status` enum('pending','in_progress','completed','on_hold') DEFAULT 'pending',
  `estimated_production_time` int DEFAULT NULL,
  `actual_production_start_date` date DEFAULT NULL,
  `actual_production_end_date` date DEFAULT NULL,
  `quality_check_status` enum('pending','passed','failed','rework') DEFAULT 'pending',
  `ready_for_dispatch` tinyint(1) DEFAULT '0',
  `dispatched_quantity` decimal(10,2) DEFAULT '0.00',
  `dispatch_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_sales_order_id` (`sales_order_id`),
  KEY `idx_production_status` (`production_status`),
  KEY `idx_quality_status` (`quality_check_status`),
  CONSTRAINT `sales_order_items_ibfk_1` FOREIGN KEY (`sales_order_id`) REFERENCES `sales_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_order_items`
--

LOCK TABLES `sales_order_items` WRITE;
/*!40000 ALTER TABLE `sales_order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_order_payments`
--

DROP TABLE IF EXISTS `sales_order_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_order_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sales_order_id` int NOT NULL,
  `payment_type` enum('advance','milestone','final','other') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method` enum('cash','cheque','bank_transfer','upi','card','other') NOT NULL,
  `reference_number` varchar(100) DEFAULT NULL,
  `bank_details` text,
  `status` enum('pending','received','bounced','cancelled') DEFAULT 'received',
  `notes` text,
  `recorded_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `recorded_by` (`recorded_by`),
  KEY `idx_sales_order_id` (`sales_order_id`),
  KEY `idx_payment_date` (`payment_date`),
  KEY `idx_payment_type` (`payment_type`),
  CONSTRAINT `sales_order_payments_ibfk_1` FOREIGN KEY (`sales_order_id`) REFERENCES `sales_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sales_order_payments_ibfk_2` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_order_payments`
--

LOCK TABLES `sales_order_payments` WRITE;
/*!40000 ALTER TABLE `sales_order_payments` DISABLE KEYS */;
INSERT INTO `sales_order_payments` (`id`, `sales_order_id`, `payment_type`, `amount`, `payment_date`, `payment_method`, `reference_number`, `bank_details`, `status`, `notes`, `recorded_by`, `created_at`, `updated_at`) VALUES (1,1,'advance',15000.00,'2025-09-09','bank_transfer',NULL,NULL,'pending',NULL,1,'2025-09-09 18:15:45','2025-09-09 18:15:45');
/*!40000 ALTER TABLE `sales_order_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_orders`
--

DROP TABLE IF EXISTS `sales_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sales_order_id` varchar(50) NOT NULL,
  `quotation_id` int NOT NULL,
  `date` date NOT NULL,
  `expected_delivery_date` date DEFAULT NULL,
  `status` enum('draft','confirmed','in_production','ready_for_dispatch','dispatched','delivered','cancelled') DEFAULT 'draft',
  `customer_po_number` varchar(100) DEFAULT NULL,
  `customer_po_date` date DEFAULT NULL,
  `billing_address` text,
  `shipping_address` text,
  `total_amount` decimal(15,2) NOT NULL,
  `advance_amount` decimal(15,2) DEFAULT '0.00',
  `balance_amount` decimal(15,2) DEFAULT NULL,
  `payment_terms` text,
  `delivery_terms` text,
  `warranty_terms` text,
  `production_priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `special_instructions` text,
  `internal_notes` text,
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sales_order_id` (`sales_order_id`),
  KEY `approved_by` (`approved_by`),
  KEY `created_by` (`created_by`),
  KEY `idx_sales_order_id` (`sales_order_id`),
  KEY `idx_quotation_id` (`quotation_id`),
  KEY `idx_status` (`status`),
  KEY `idx_date` (`date`),
  KEY `idx_expected_delivery` (`expected_delivery_date`),
  CONSTRAINT `sales_orders_ibfk_1` FOREIGN KEY (`quotation_id`) REFERENCES `quotations` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `sales_orders_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `sales_orders_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_orders`
--

LOCK TABLES `sales_orders` WRITE;
/*!40000 ALTER TABLE `sales_orders` DISABLE KEYS */;
INSERT INTO `sales_orders` (`id`, `sales_order_id`, `quotation_id`, `date`, `expected_delivery_date`, `status`, `customer_po_number`, `customer_po_date`, `billing_address`, `shipping_address`, `total_amount`, `advance_amount`, `balance_amount`, `payment_terms`, `delivery_terms`, `warranty_terms`, `production_priority`, `special_instructions`, `internal_notes`, `approved_by`, `approved_at`, `created_by`, `created_at`, `updated_at`) VALUES (1,'VESPL/SO/2526/002',1,'2025-09-09','2025-11-15','in_production','PO-2025-001','2025-09-09','Industrial Area, Sector 21','Industrial Area, Sector 21',0.00,15000.00,-15000.00,'30% advance, 70% on delivery','4-6 weeks from approval','12 months warranty','high','Priority production required',NULL,1,'2025-09-09 18:25:42',1,'2025-09-09 18:15:45','2025-09-09 18:25:53');
/*!40000 ALTER TABLE `sales_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serial_number_performance`
--

DROP TABLE IF EXISTS `serial_number_performance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `serial_number_performance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `serial_number_id` int NOT NULL,
  `installation_date` date DEFAULT NULL,
  `last_service_date` date DEFAULT NULL,
  `performance_rating` enum('excellent','good','average','poor') DEFAULT 'good',
  `failure_count` int DEFAULT '0',
  `performance_data` json DEFAULT NULL,
  `service_history` json DEFAULT NULL,
  `customer_satisfaction` enum('very_satisfied','satisfied','neutral','dissatisfied') DEFAULT 'satisfied',
  `feedback_notes` text,
  `recorded_by` int DEFAULT NULL,
  `recorded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_serial_number` (`serial_number_id`),
  KEY `idx_performance_rating` (`performance_rating`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serial_number_performance`
--

LOCK TABLES `serial_number_performance` WRITE;
/*!40000 ALTER TABLE `serial_number_performance` DISABLE KEYS */;
/*!40000 ALTER TABLE `serial_number_performance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int DEFAULT NULL,
  `location_id` int DEFAULT NULL,
  `quantity` decimal(10,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_product_location` (`product_id`,`location_id`),
  CONSTRAINT `stock_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock`
--

LOCK TABLES `stock` WRITE;
/*!40000 ALTER TABLE `stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `pincode` varchar(20) DEFAULT NULL,
  `gstin` varchar(20) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(50) DEFAULT NULL,
  `ifsc_code` varchar(20) DEFAULT NULL,
  `credit_days` int DEFAULT '30',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_config`
--

DROP TABLE IF EXISTS `tax_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `state_code` varchar(10) NOT NULL,
  `state_name` varchar(100) NOT NULL,
  `cgst_rate` decimal(5,2) DEFAULT '9.00',
  `sgst_rate` decimal(5,2) DEFAULT '9.00',
  `igst_rate` decimal(5,2) DEFAULT '18.00',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_state_code` (`state_code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_config`
--

LOCK TABLES `tax_config` WRITE;
/*!40000 ALTER TABLE `tax_config` DISABLE KEYS */;
INSERT INTO `tax_config` (`id`, `state_code`, `state_name`, `cgst_rate`, `sgst_rate`, `igst_rate`, `is_active`, `created_at`, `updated_at`) VALUES (1,'KA','Karnataka',9.00,9.00,18.00,1,'2025-09-10 05:20:11','2025-09-10 05:20:11'),(2,'MH','Maharashtra',9.00,9.00,18.00,1,'2025-09-10 05:20:11','2025-09-10 05:20:11'),(3,'TN','Tamil Nadu',9.00,9.00,18.00,1,'2025-09-10 05:20:11','2025-09-10 05:20:11'),(4,'DL','Delhi',9.00,9.00,18.00,1,'2025-09-10 05:20:11','2025-09-10 05:20:11'),(5,'GJ','Gujarat',9.00,9.00,18.00,1,'2025-09-10 05:20:11','2025-09-10 05:20:11');
/*!40000 ALTER TABLE `tax_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `user_role` enum('director','admin','sales-admin','designer','accounts','technician') NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `email`, `password_hash`, `full_name`, `user_role`, `status`, `created_at`, `updated_at`) VALUES (1,'admin@vtria.com','dummy_hash_1','Admin User','admin','active','2025-09-09 17:25:04','2025-09-09 17:25:04'),(2,'designer1@vtria.com','dummy_hash_2','Ravi Desai','designer','active','2025-09-09 17:25:04','2025-09-09 17:25:04'),(3,'designer2@vtria.com','dummy_hash_3','Neha Joshi','designer','active','2025-09-09 17:25:04','2025-09-09 17:25:04'),(4,'sales@vtria.com','dummy_hash_4','Akash Patil','sales-admin','active','2025-09-09 17:25:04','2025-09-09 17:25:04');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `v_customer_outstanding`
--

DROP TABLE IF EXISTS `v_customer_outstanding`;
/*!50001 DROP VIEW IF EXISTS `v_customer_outstanding`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_customer_outstanding` AS SELECT 
 1 AS `customer_id`,
 1 AS `company_name`,
 1 AS `current_outstanding`,
 1 AS `credit_limit`,
 1 AS `available_credit`,
 1 AS `risk_category`,
 1 AS `current_amount`,
 1 AS `amount_1_30_days`,
 1 AS `amount_31_60_days`,
 1 AS `amount_61_90_days`,
 1 AS `amount_above_90_days`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_inventory_summary`
--

DROP TABLE IF EXISTS `v_inventory_summary`;
/*!50001 DROP VIEW IF EXISTS `v_inventory_summary`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_inventory_summary` AS SELECT 
 1 AS `id`,
 1 AS `item_code`,
 1 AS `item_name`,
 1 AS `item_type`,
 1 AS `category_name`,
 1 AS `unit_name`,
 1 AS `current_stock`,
 1 AS `reserved_stock`,
 1 AS `available_stock`,
 1 AS `minimum_stock`,
 1 AS `reorder_point`,
 1 AS `stock_status`,
 1 AS `standard_cost`,
 1 AS `average_cost`,
 1 AS `stock_value`,
 1 AS `is_active`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_reorder_report`
--

DROP TABLE IF EXISTS `v_reorder_report`;
/*!50001 DROP VIEW IF EXISTS `v_reorder_report`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_reorder_report` AS SELECT 
 1 AS `id`,
 1 AS `item_code`,
 1 AS `item_name`,
 1 AS `category_name`,
 1 AS `current_stock`,
 1 AS `reorder_point`,
 1 AS `reorder_quantity`,
 1 AS `shortage_quantity`,
 1 AS `preferred_vendor`,
 1 AS `lead_time_days`,
 1 AS `vendor_cost`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `vendor_prices`
--

DROP TABLE IF EXISTS `vendor_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vendor_prices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `vendor_name` varchar(255) NOT NULL,
  `vendor_price` decimal(12,2) NOT NULL,
  `vendor_discount` decimal(5,2) DEFAULT '0.00',
  `final_price` decimal(12,2) GENERATED ALWAYS AS ((`vendor_price` * (1 - (`vendor_discount` / 100)))) STORED,
  `valid_from` date NOT NULL,
  `valid_until` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_product_vendor` (`product_id`,`vendor_name`),
  KEY `idx_active_prices` (`product_id`,`is_active`,`valid_from`,`valid_until`),
  CONSTRAINT `vendor_prices_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendor_prices`
--

LOCK TABLES `vendor_prices` WRITE;
/*!40000 ALTER TABLE `vendor_prices` DISABLE KEYS */;
INSERT INTO `vendor_prices` (`id`, `product_id`, `vendor_name`, `vendor_price`, `vendor_discount`, `valid_from`, `valid_until`, `is_active`, `created_at`, `updated_at`) VALUES (1,1,'Schneider Direct',145000.00,8.50,'2025-09-01',NULL,1,'2025-09-11 15:36:53','2025-09-11 15:36:53'),(2,1,'Local Distributor A',148000.00,6.00,'2025-09-05',NULL,1,'2025-09-11 15:36:53','2025-09-11 15:36:53'),(3,1,'Online Supplier',142000.00,5.00,'2025-09-10',NULL,1,'2025-09-11 15:36:53','2025-09-11 15:36:53'),(4,2,'APC Authorized',85000.00,7.50,'2025-09-01',NULL,1,'2025-09-11 15:36:53','2025-09-11 15:36:53'),(5,2,'Electronics Mart',87000.00,8.00,'2025-09-08',NULL,1,'2025-09-11 15:36:53','2025-09-11 15:36:53'),(6,3,'Mahindra Dealer',125000.00,6.00,'2025-09-01',NULL,1,'2025-09-11 15:36:53','2025-09-11 15:36:53'),(7,3,'Generator Specialist',123000.00,7.50,'2025-09-07',NULL,1,'2025-09-11 15:36:53','2025-09-11 15:36:53');
/*!40000 ALTER TABLE `vendor_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_order_materials`
--

DROP TABLE IF EXISTS `work_order_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_order_materials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `work_order_id` int NOT NULL,
  `bom_component_id` int DEFAULT NULL,
  `component_type` enum('raw_material','sub_assembly','purchased_part') NOT NULL,
  `component_id` int NOT NULL,
  `component_code` varchar(50) NOT NULL,
  `component_name` varchar(200) NOT NULL,
  `required_quantity` decimal(12,6) NOT NULL,
  `reserved_quantity` decimal(12,6) DEFAULT '0.000000',
  `issued_quantity` decimal(12,6) DEFAULT '0.000000',
  `consumed_quantity` decimal(12,6) DEFAULT '0.000000',
  `returned_quantity` decimal(12,6) DEFAULT '0.000000',
  `unit_of_measurement` varchar(20) DEFAULT NULL,
  `unit_cost` decimal(12,4) DEFAULT '0.0000',
  `total_cost` decimal(12,4) GENERATED ALWAYS AS ((`issued_quantity` * `unit_cost`)) STORED,
  `status` enum('planned','reserved','issued','consumed','returned') DEFAULT 'planned',
  `operation_sequence` int DEFAULT NULL,
  `batch_number` varchar(50) DEFAULT NULL,
  `lot_number` varchar(50) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `bom_component_id` (`bom_component_id`),
  KEY `idx_work_order` (`work_order_id`),
  KEY `idx_component` (`component_type`,`component_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `work_order_materials_ibfk_1` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `work_order_materials_ibfk_2` FOREIGN KEY (`bom_component_id`) REFERENCES `bom_components` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_order_materials`
--

LOCK TABLES `work_order_materials` WRITE;
/*!40000 ALTER TABLE `work_order_materials` DISABLE KEYS */;
/*!40000 ALTER TABLE `work_order_materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_order_operations`
--

DROP TABLE IF EXISTS `work_order_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_order_operations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `work_order_id` int NOT NULL,
  `bom_operation_id` int DEFAULT NULL,
  `operation_id` int NOT NULL,
  `sequence_number` int NOT NULL,
  `planned_quantity` decimal(12,4) NOT NULL,
  `planned_setup_time` decimal(8,4) DEFAULT '0.0000',
  `planned_run_time` decimal(8,4) DEFAULT '0.0000',
  `planned_start_date` datetime DEFAULT NULL,
  `planned_end_date` datetime DEFAULT NULL,
  `actual_quantity` decimal(12,4) DEFAULT '0.0000',
  `actual_setup_time` decimal(8,4) DEFAULT '0.0000',
  `actual_run_time` decimal(8,4) DEFAULT '0.0000',
  `actual_start_date` datetime DEFAULT NULL,
  `actual_end_date` datetime DEFAULT NULL,
  `assigned_employee_id` int DEFAULT NULL,
  `work_center` varchar(50) DEFAULT NULL,
  `machine_id` varchar(50) DEFAULT NULL,
  `status` enum('pending','in_progress','completed','skipped','failed') DEFAULT 'pending',
  `completion_percentage` decimal(5,2) DEFAULT '0.00',
  `quantity_good` decimal(12,4) DEFAULT '0.0000',
  `quantity_rework` decimal(12,4) DEFAULT '0.0000',
  `quantity_scrap` decimal(12,4) DEFAULT '0.0000',
  `labor_cost` decimal(12,4) DEFAULT '0.0000',
  `machine_cost` decimal(12,4) DEFAULT '0.0000',
  `overhead_cost` decimal(12,4) DEFAULT '0.0000',
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_wo_operation` (`work_order_id`,`sequence_number`),
  KEY `bom_operation_id` (`bom_operation_id`),
  KEY `operation_id` (`operation_id`),
  KEY `idx_status` (`status`),
  KEY `idx_assigned_employee` (`assigned_employee_id`),
  CONSTRAINT `work_order_operations_ibfk_1` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `work_order_operations_ibfk_2` FOREIGN KEY (`bom_operation_id`) REFERENCES `bom_operations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `work_order_operations_ibfk_3` FOREIGN KEY (`operation_id`) REFERENCES `production_operations` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_order_operations`
--

LOCK TABLES `work_order_operations` WRITE;
/*!40000 ALTER TABLE `work_order_operations` DISABLE KEYS */;
/*!40000 ALTER TABLE `work_order_operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `work_orders`
--

DROP TABLE IF EXISTS `work_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `work_order_id` varchar(50) NOT NULL,
  `sales_order_id` int NOT NULL,
  `sales_order_item_id` int DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `assigned_to` int DEFAULT NULL,
  `assigned_date` date DEFAULT NULL,
  `priority` enum('low','medium','high','urgent') DEFAULT 'medium',
  `estimated_hours` decimal(8,2) DEFAULT NULL,
  `planned_start_date` date DEFAULT NULL,
  `planned_end_date` date DEFAULT NULL,
  `actual_start_date` date DEFAULT NULL,
  `actual_end_date` date DEFAULT NULL,
  `status` enum('pending','assigned','in_progress','paused','completed','cancelled') DEFAULT 'pending',
  `progress_percentage` decimal(5,2) DEFAULT '0.00',
  `technical_specifications` text,
  `quality_requirements` text,
  `safety_notes` text,
  `approved_by` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_by` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `work_order_id` (`work_order_id`),
  KEY `sales_order_item_id` (`sales_order_item_id`),
  KEY `approved_by` (`approved_by`),
  KEY `created_by` (`created_by`),
  KEY `idx_work_order_id` (`work_order_id`),
  KEY `idx_sales_order_id` (`sales_order_id`),
  KEY `idx_assigned_to` (`assigned_to`),
  KEY `idx_status` (`status`),
  KEY `idx_priority` (`priority`),
  CONSTRAINT `work_orders_ibfk_1` FOREIGN KEY (`sales_order_id`) REFERENCES `sales_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `work_orders_ibfk_2` FOREIGN KEY (`sales_order_item_id`) REFERENCES `sales_order_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `work_orders_ibfk_3` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `work_orders_ibfk_4` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `work_orders_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `work_orders`
--

LOCK TABLES `work_orders` WRITE;
/*!40000 ALTER TABLE `work_orders` DISABLE KEYS */;
INSERT INTO `work_orders` (`id`, `work_order_id`, `sales_order_id`, `sales_order_item_id`, `title`, `description`, `assigned_to`, `assigned_date`, `priority`, `estimated_hours`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `status`, `progress_percentage`, `technical_specifications`, `quality_requirements`, `safety_notes`, `approved_by`, `approved_at`, `created_by`, `created_at`, `updated_at`) VALUES (1,'VESPL/WO/2526/001',1,NULL,'Assembly Line Automation - Robot Welding System','Manufacturing of robotic welding system for Tata Motors assembly line',NULL,NULL,'high',120.00,'2025-09-15','2025-10-15','2025-09-10',NULL,'paused',NULL,'Precision welding with 0.1mm tolerance, stainless steel construction','ISO 9001 standards, pressure testing required','High voltage equipment - certified technician required',NULL,NULL,1,'2025-09-09 18:25:53','2025-09-10 18:09:22');
/*!40000 ALTER TABLE `work_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'vtria_erp'
--

--
-- Dumping routines for database 'vtria_erp'
--
/*!50003 DROP PROCEDURE IF EXISTS `CreateMilestonesFromTemplate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`vtria_user`@`%` PROCEDURE `CreateMilestonesFromTemplate`(
    IN p_case_id INT,
    IN p_template_id INT,
    IN p_project_start_date DATE,
    IN p_created_by INT
)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_milestone_id INT;
    DECLARE v_milestone_name VARCHAR(100);
    DECLARE v_sequence_order INT;
    DECLARE v_milestone_type VARCHAR(20);
    DECLARE v_is_critical_path BOOLEAN;
    DECLARE v_is_client_milestone BOOLEAN;
    DECLARE v_requires_client_approval BOOLEAN;
    DECLARE v_start_offset_days INT;
    DECLARE v_duration_days INT;
    DECLARE v_deliverables TEXT;
    DECLARE v_success_criteria TEXT;
    DECLARE v_responsible_role VARCHAR(50);
    DECLARE v_estimated_hours INT;
    DECLARE v_cost_estimate DECIMAL(12,2);
    DECLARE v_planned_start_date DATE;
    DECLARE v_planned_end_date DATE;
    
    DECLARE milestone_cursor CURSOR FOR
        SELECT id, milestone_name, sequence_order, milestone_type, is_critical_path,
               is_client_milestone, requires_client_approval, start_offset_days, 
               duration_days, deliverables, success_criteria, responsible_role,
               estimated_hours, cost_estimate
        FROM milestone_templates
        WHERE template_id = p_template_id
        ORDER BY sequence_order;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN milestone_cursor;
    
    milestone_loop: LOOP
        FETCH milestone_cursor INTO v_milestone_id, v_milestone_name, v_sequence_order,
              v_milestone_type, v_is_critical_path, v_is_client_milestone,
              v_requires_client_approval, v_start_offset_days, v_duration_days,
              v_deliverables, v_success_criteria, v_responsible_role,
              v_estimated_hours, v_cost_estimate;
        
        IF done THEN
            LEAVE milestone_loop;
        END IF;
        
        SET v_planned_start_date = DATE_ADD(p_project_start_date, INTERVAL v_start_offset_days DAY);
        SET v_planned_end_date = DATE_ADD(v_planned_start_date, INTERVAL v_duration_days DAY);
        
        INSERT INTO case_milestones (
            case_id, milestone_template_id, milestone_name, sequence_order,
            milestone_type, is_critical_path, is_client_milestone,
            requires_client_approval, planned_start_date, planned_end_date,
            deliverables, success_criteria, responsible_role,
            estimated_hours, estimated_cost, created_by, updated_by
        ) VALUES (
            p_case_id, v_milestone_id, v_milestone_name, v_sequence_order,
            v_milestone_type, v_is_critical_path, v_is_client_milestone,
            v_requires_client_approval, v_planned_start_date, v_planned_end_date,
            v_deliverables, v_success_criteria, v_responsible_role,
            v_estimated_hours, v_cost_estimate, p_created_by, p_created_by
        );
    END LOOP;
    
    CLOSE milestone_cursor;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GenerateAIInsights` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`vtria_user`@`%` PROCEDURE `GenerateAIInsights`(
    IN p_case_id INT,
    IN p_model_types TEXT 
)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_model_id INT;
    DECLARE v_model_name VARCHAR(100);
    DECLARE v_model_type VARCHAR(50);
    
    DECLARE model_cursor CURSOR FOR
        SELECT id, model_name, model_type
        FROM ai_models
        WHERE is_active = TRUE 
        AND is_production_ready = TRUE
        AND (p_model_types IS NULL OR FIND_IN_SET(model_type, p_model_types) > 0);
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN model_cursor;
    
    model_loop: LOOP
        FETCH model_cursor INTO v_model_id, v_model_name, v_model_type;
        
        IF done THEN
            LEAVE model_loop;
        END IF;
        
        
        CASE v_model_type
            WHEN 'predictive' THEN
                CALL RunPredictiveModel(v_model_id, p_case_id);
            WHEN 'recommendation' THEN
                CALL RunRecommendationModel(v_model_id, p_case_id);
            WHEN 'anomaly_detection' THEN
                CALL RunAnomalyDetection(v_model_id, p_case_id);
        END CASE;
        
    END LOOP;
    
    CLOSE model_cursor;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RunPredictiveModel` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`vtria_user`@`%` PROCEDURE `RunPredictiveModel`(
    IN p_model_id INT,
    IN p_case_id INT
)
BEGIN
    DECLARE v_case_complexity VARCHAR(20);
    DECLARE v_milestone_count INT;
    DECLARE v_team_size INT;
    DECLARE v_predicted_delay DECIMAL(10,2);
    DECLARE v_confidence DECIMAL(5,4);
    
    
    SELECT 
        COALESCE(c.priority, 'medium'),
        COUNT(cm.id),
        COUNT(DISTINCT cm.assigned_to)
    INTO v_case_complexity, v_milestone_count, v_team_size
    FROM cases c
    LEFT JOIN case_milestones cm ON c.id = cm.case_id
    WHERE c.id = p_case_id
    GROUP BY c.id;
    
    
    SET v_predicted_delay = CASE 
        WHEN v_case_complexity = 'high' AND v_milestone_count > 5 THEN 
            RAND() * 10 + 5  
        WHEN v_case_complexity = 'medium' THEN 
            RAND() * 5 + 2   
        ELSE 
            RAND() * 3       
    END;
    
    SET v_confidence = 0.7500 + (RAND() * 0.2000); 
    
    
    INSERT INTO ai_predictions (
        model_id, case_id, prediction_type, predicted_value,
        confidence_score, prediction_horizon_days, input_features,
        model_version, prediction_date, target_date
    ) VALUES (
        p_model_id, p_case_id, 'completion_date', v_predicted_delay,
        v_confidence, 30, 
        JSON_OBJECT(
            'case_complexity', v_case_complexity,
            'milestone_count', v_milestone_count,
            'team_size', v_team_size
        ),
        '1.0', NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY)
    );
    
    
    IF v_predicted_delay > 3 AND v_confidence > 0.8000 THEN
        INSERT INTO ai_insights (
            model_id, case_id, insight_type, insight_category,
            title, description, confidence_score, severity_level,
            predicted_impact, input_data, model_output,
            recommended_actions
        ) VALUES (
            p_model_id, p_case_id, 'warning', 'schedule',
            'Potential Project Delay Detected',
            CONCAT('AI analysis indicates a potential delay of ', ROUND(v_predicted_delay, 1), ' days based on current project parameters.'),
            v_confidence, 
            CASE WHEN v_predicted_delay > 7 THEN 'high' ELSE 'medium' END,
            'negative',
            JSON_OBJECT(
                'complexity', v_case_complexity,
                'milestone_count', v_milestone_count,
                'team_size', v_team_size
            ),
            JSON_OBJECT(
                'predicted_delay_days', v_predicted_delay,
                'confidence', v_confidence
            ),
            JSON_ARRAY(
                'Review project timeline and milestones',
                'Consider additional resources if needed',
                'Communicate potential delay to stakeholders',
                'Identify and mitigate bottlenecks'
            )
        );
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateCustomerOutstanding` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`vtria_user`@`%` PROCEDURE `UpdateCustomerOutstanding`(IN p_customer_id INT)
BEGIN
    DECLARE v_total_outstanding DECIMAL(15,4);
    
    
    SELECT COALESCE(SUM(balance_amount), 0)
    INTO v_total_outstanding
    FROM invoices
    WHERE customer_id = p_customer_id 
    AND payment_status IN ('unpaid', 'partial', 'overdue');
    
    
    INSERT INTO customer_credit_limits (customer_id, current_outstanding, created_by)
    VALUES (p_customer_id, v_total_outstanding, 1)
    ON DUPLICATE KEY UPDATE 
        current_outstanding = v_total_outstanding,
        updated_at = CURRENT_TIMESTAMP;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateInvoicePaymentStatus` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`vtria_user`@`%` PROCEDURE `UpdateInvoicePaymentStatus`(IN p_invoice_id INT)
BEGIN
    DECLARE v_total_amount DECIMAL(15,4);
    DECLARE v_paid_amount DECIMAL(15,4);
    DECLARE v_balance_amount DECIMAL(15,4);
    DECLARE v_new_status ENUM('unpaid', 'partial', 'paid', 'overdue', 'cancelled');
    
    
    SELECT 
        total_amount,
        COALESCE((
            SELECT SUM(pa.allocated_amount)
            FROM payment_allocations pa 
            JOIN payments p ON pa.payment_id = p.id
            WHERE pa.invoice_id = p_invoice_id 
            AND p.payment_status = 'cleared'
        ), 0)
    INTO v_total_amount, v_paid_amount
    FROM invoices 
    WHERE id = p_invoice_id;
    
    SET v_balance_amount = v_total_amount - v_paid_amount;
    
    
    IF v_paid_amount = 0 THEN
        SET v_new_status = 'unpaid';
    ELSEIF v_balance_amount <= 0 THEN
        SET v_new_status = 'paid';
    ELSE
        SET v_new_status = 'partial';
    END IF;
    
    
    UPDATE invoices 
    SET 
        paid_amount = v_paid_amount,
        payment_status = v_new_status
    WHERE id = p_invoice_id;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `ai_insights_summary`
--

/*!50001 DROP VIEW IF EXISTS `ai_insights_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`vtria_user`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `ai_insights_summary` AS select `ai`.`insight_category` AS `insight_category`,`ai`.`insight_type` AS `insight_type`,`ai`.`severity_level` AS `severity_level`,count(0) AS `total_insights`,avg(`ai`.`confidence_score`) AS `avg_confidence`,sum((case when (`ai`.`is_acknowledged` = true) then 1 else 0 end)) AS `acknowledged_count`,sum((case when (`ai`.`is_acted_upon` = true) then 1 else 0 end)) AS `acted_upon_count`,avg((case when (`ai`.`user_rating` = 'very_helpful') then 5 when (`ai`.`user_rating` = 'helpful') then 4 when (`ai`.`user_rating` = 'neutral') then 3 when (`ai`.`user_rating` = 'not_helpful') then 2 when (`ai`.`user_rating` = 'incorrect') then 1 else NULL end)) AS `avg_user_rating`,cast(`ai`.`created_at` as date) AS `insight_date` from `ai_insights` `ai` where (`ai`.`created_at` >= (now() - interval 30 day)) group by `ai`.`insight_category`,`ai`.`insight_type`,`ai`.`severity_level`,cast(`ai`.`created_at` as date) order by `insight_date` desc,`total_insights` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ai_model_performance`
--

/*!50001 DROP VIEW IF EXISTS `ai_model_performance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`vtria_user`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `ai_model_performance` AS select `am`.`model_name` AS `model_name`,`am`.`model_type` AS `model_type`,`am`.`model_category` AS `model_category`,`am`.`accuracy_score` AS `accuracy_score`,`am`.`confidence_threshold` AS `confidence_threshold`,`am`.`last_trained_at` AS `last_trained_at`,count(`ai`.`id`) AS `insights_generated`,avg(`ai`.`confidence_score`) AS `avg_insight_confidence`,sum((case when (`ai`.`user_rating` in ('very_helpful','helpful')) then 1 else 0 end)) AS `positive_feedback_count`,sum((case when (`ai`.`user_rating` in ('not_helpful','incorrect')) then 1 else 0 end)) AS `negative_feedback_count`,count(`ap`.`id`) AS `predictions_made`,avg(`ap`.`accuracy_score`) AS `avg_prediction_accuracy` from ((`ai_models` `am` left join `ai_insights` `ai` on((`am`.`id` = `ai`.`model_id`))) left join `ai_predictions` `ap` on((`am`.`id` = `ap`.`model_id`))) where (`am`.`is_active` = true) group by `am`.`id`,`am`.`model_name`,`am`.`model_type`,`am`.`model_category`,`am`.`accuracy_score`,`am`.`confidence_threshold`,`am`.`last_trained_at` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `case_summary`
--

/*!50001 DROP VIEW IF EXISTS `case_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`vtria_user`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `case_summary` AS select `c`.`id` AS `case_id`,`c`.`case_number` AS `case_number`,`c`.`project_name` AS `project_name`,`c`.`current_state` AS `current_state`,`c`.`priority` AS `priority`,`c`.`status` AS `status`,`c`.`estimated_value` AS `estimated_value`,`c`.`final_value` AS `final_value`,`c`.`expected_completion_date` AS `expected_completion_date`,`c`.`created_at` AS `case_created`,`c`.`updated_at` AS `last_updated`,`cl`.`company_name` AS `client_name`,`cl`.`contact_person` AS `contact_person`,`cl`.`city` AS `client_city`,`cl`.`state` AS `client_state`,`u_assigned`.`full_name` AS `assigned_to_name`,`u_created`.`full_name` AS `created_by_name`,(select count(0) from `case_documents` `cd` where ((`cd`.`case_id` = `c`.`id`) and (`cd`.`document_type` = 'enquiry'))) AS `enquiry_count`,(select count(0) from `case_documents` `cd` where ((`cd`.`case_id` = `c`.`id`) and (`cd`.`document_type` = 'estimation'))) AS `estimation_count`,(select count(0) from `case_documents` `cd` where ((`cd`.`case_id` = `c`.`id`) and (`cd`.`document_type` = 'quotation'))) AS `quotation_count`,(select count(0) from `case_documents` `cd` where ((`cd`.`case_id` = `c`.`id`) and (`cd`.`document_type` = 'sales_order'))) AS `order_count`,(select `cst`.`transition_reason` from `case_state_transitions` `cst` where (`cst`.`case_id` = `c`.`id`) order by `cst`.`created_at` desc limit 1) AS `last_transition_reason`,(select `cst`.`created_at` from `case_state_transitions` `cst` where (`cst`.`case_id` = `c`.`id`) order by `cst`.`created_at` desc limit 1) AS `last_transition_date` from (((`cases` `c` left join `clients` `cl` on((`c`.`client_id` = `cl`.`id`))) left join `users` `u_assigned` on((`c`.`assigned_to` = `u_assigned`.`id`))) left join `users` `u_created` on((`c`.`created_by` = `u_created`.`id`))) where (`c`.`status` <> 'cancelled') order by `c`.`updated_at` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `case_timeline`
--

/*!50001 DROP VIEW IF EXISTS `case_timeline`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`vtria_user`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `case_timeline` AS select `c`.`id` AS `case_id`,`c`.`case_number` AS `case_number`,`c`.`project_name` AS `project_name`,`cl`.`company_name` AS `client_name`,`c`.`current_state` AS `current_state`,`c`.`status` AS `status`,`c`.`created_at` AS `case_created`,`cst`.`id` AS `transition_id`,`cst`.`from_state` AS `from_state`,`cst`.`to_state` AS `to_state`,`cst`.`transition_reason` AS `transition_reason`,`cst`.`notes` AS `transition_notes`,`cst`.`reference_type` AS `reference_type`,`cst`.`reference_id` AS `reference_id`,`cst`.`created_at` AS `transition_date`,`u`.`full_name` AS `transition_by` from (((`cases` `c` left join `case_state_transitions` `cst` on((`c`.`id` = `cst`.`case_id`))) left join `clients` `cl` on((`c`.`client_id` = `cl`.`id`))) left join `users` `u` on((`cst`.`created_by` = `u`.`id`))) order by `c`.`id`,`cst`.`created_at` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_customer_outstanding`
--

/*!50001 DROP VIEW IF EXISTS `v_customer_outstanding`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`vtria_user`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_customer_outstanding` AS select `c`.`id` AS `customer_id`,`c`.`company_name` AS `company_name`,coalesce(sum((case when (`i`.`status` in ('sent','overdue')) then (`i`.`total_amount` - coalesce(`pa`.`allocated_amount`,0)) else 0 end)),0) AS `current_outstanding`,coalesce(`ccl`.`credit_limit`,0) AS `credit_limit`,greatest((coalesce(`ccl`.`credit_limit`,0) - coalesce(sum((case when (`i`.`status` in ('sent','overdue')) then (`i`.`total_amount` - coalesce(`pa`.`allocated_amount`,0)) else 0 end)),0)),0) AS `available_credit`,(case when (coalesce(sum((case when (`i`.`status` in ('sent','overdue')) then (`i`.`total_amount` - coalesce(`pa`.`allocated_amount`,0)) else 0 end)),0) > coalesce(`ccl`.`credit_limit`,0)) then 'blocked' when (coalesce(sum((case when (`i`.`status` in ('sent','overdue')) then (`i`.`total_amount` - coalesce(`pa`.`allocated_amount`,0)) else 0 end)),0) > (coalesce(`ccl`.`credit_limit`,0) * 0.8)) then 'high' when (coalesce(sum((case when (`i`.`status` in ('sent','overdue')) then (`i`.`total_amount` - coalesce(`pa`.`allocated_amount`,0)) else 0 end)),0) > (coalesce(`ccl`.`credit_limit`,0) * 0.5)) then 'medium' else 'low' end) AS `risk_category`,coalesce(sum((case when ((`i`.`status` in ('sent','overdue')) and ((to_days(curdate()) - to_days(`i`.`invoice_date`)) <= 0)) then (`i`.`total_amount` - coalesce(`pa`.`allocated_amount`,0)) else 0 end)),0) AS `current_amount`,coalesce(sum((case when ((`i`.`status` in ('sent','overdue')) and ((to_days(curdate()) - to_days(`i`.`invoice_date`)) between 1 and 30)) then (`i`.`total_amount` - coalesce(`pa`.`allocated_amount`,0)) else 0 end)),0) AS `amount_1_30_days`,coalesce(sum((case when ((`i`.`status` in ('sent','overdue')) and ((to_days(curdate()) - to_days(`i`.`invoice_date`)) between 31 and 60)) then (`i`.`total_amount` - coalesce(`pa`.`allocated_amount`,0)) else 0 end)),0) AS `amount_31_60_days`,coalesce(sum((case when ((`i`.`status` in ('sent','overdue')) and ((to_days(curdate()) - to_days(`i`.`invoice_date`)) between 61 and 90)) then (`i`.`total_amount` - coalesce(`pa`.`allocated_amount`,0)) else 0 end)),0) AS `amount_61_90_days`,coalesce(sum((case when ((`i`.`status` in ('sent','overdue')) and ((to_days(curdate()) - to_days(`i`.`invoice_date`)) > 90)) then (`i`.`total_amount` - coalesce(`pa`.`allocated_amount`,0)) else 0 end)),0) AS `amount_above_90_days` from (((`clients` `c` left join `invoices` `i` on((`c`.`id` = `i`.`customer_id`))) left join (select `payment_allocations`.`invoice_id` AS `invoice_id`,sum(`payment_allocations`.`allocated_amount`) AS `allocated_amount` from `payment_allocations` group by `payment_allocations`.`invoice_id`) `pa` on((`i`.`id` = `pa`.`invoice_id`))) left join `customer_credit_limits` `ccl` on((`c`.`id` = `ccl`.`customer_id`))) group by `c`.`id`,`c`.`company_name`,`ccl`.`credit_limit` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_inventory_summary`
--

/*!50001 DROP VIEW IF EXISTS `v_inventory_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`vtria_user`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_inventory_summary` AS select `i`.`id` AS `id`,`i`.`item_code` AS `item_code`,`i`.`item_name` AS `item_name`,`i`.`item_type` AS `item_type`,`c`.`category_name` AS `category_name`,`u`.`unit_name` AS `unit_name`,`i`.`current_stock` AS `current_stock`,`i`.`reserved_stock` AS `reserved_stock`,`i`.`available_stock` AS `available_stock`,`i`.`minimum_stock` AS `minimum_stock`,`i`.`reorder_point` AS `reorder_point`,(case when (`i`.`current_stock` <= `i`.`reorder_point`) then 'Reorder Required' when (`i`.`current_stock` <= `i`.`minimum_stock`) then 'Low Stock' else 'Normal' end) AS `stock_status`,`i`.`standard_cost` AS `standard_cost`,`i`.`average_cost` AS `average_cost`,(`i`.`current_stock` * `i`.`average_cost`) AS `stock_value`,`i`.`is_active` AS `is_active` from ((`inventory_items` `i` left join `inventory_categories` `c` on((`i`.`category_id` = `c`.`id`))) left join `inventory_units` `u` on((`i`.`unit_id` = `u`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_reorder_report`
--

/*!50001 DROP VIEW IF EXISTS `v_reorder_report`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`vtria_user`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_reorder_report` AS select `i`.`id` AS `id`,`i`.`item_code` AS `item_code`,`i`.`item_name` AS `item_name`,`c`.`category_name` AS `category_name`,`i`.`current_stock` AS `current_stock`,`i`.`reorder_point` AS `reorder_point`,`i`.`reorder_quantity` AS `reorder_quantity`,(`i`.`reorder_point` - `i`.`current_stock`) AS `shortage_quantity`,`v`.`vendor_name` AS `preferred_vendor`,`iv`.`lead_time_days` AS `lead_time_days`,`iv`.`unit_cost` AS `vendor_cost` from (((`inventory_items` `i` left join `inventory_categories` `c` on((`i`.`category_id` = `c`.`id`))) left join `inventory_item_vendors` `iv` on(((`i`.`id` = `iv`.`item_id`) and (`iv`.`is_preferred` = true)))) left join `inventory_vendors` `v` on((`iv`.`vendor_id` = `v`.`id`))) where ((`i`.`current_stock` <= `i`.`reorder_point`) and (`i`.`is_active` = true)) order by (`i`.`reorder_point` - `i`.`current_stock`) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-13 10:46:43
